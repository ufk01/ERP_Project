package com.interline.logistics.library.common.enums;

import lombok.Getter;

@Getter
public enum JBusinessError {

    DATA_SAVED_ALREADY(1001,"This data has already been registered!"),
    PERMISSION_DENIED(1002, "User does not have permission for this operation"),
    DATA_NOT_FOUND(1003, "Requested data not found"),
    INVALID_TOKEN(1004, "Token is invalid or expired"),
    EMPTY_DATA_FOUND(1005, "Empty data found in data"),
    PROCESS_ERROR(1006, "Process error occurred"),
    LOGIN_DENIED(1007, "User cannot login" ),
    UNEXPECTED_ERROR(108, "Unexpected error"),
    PATH_ERROR(109, "Path error occurred"),
    USER_INFO_WRONG(1010, "User information must be control"),
    USER_NOT_LOGGED(1011, "User is not logged"),
    TOKEN_NOT_FOUND(1012, "Token not found"),
    INVALID_SUBJECT(1013, "Invalid subject"),
    INVALID_USERNAME_AND_PASSWORD(1014,"Invalid username and password"),
    INVALID_PERMISSION_CHECK(1015, "Permission ID is not valid!"),
    INVALID_ROLE_CHECK(1016, "Role ID is not valid!"),
    INVALID_USER_CHECK(1017, "User ID is not valid!"),
    NO_EXIST_PERMISSION(1018, "there is no permission"),
    NO_EXIST_ROLE(1019, "There is no role"),
    INVALID_SEA_DATA(1020, "Invalid sea data"),
    NOT_EXIST_SEA_DATA(1021, "Sea data is not exist!"),
    SEA_ID_CANNOT_FIND(1022, "Sea ID data cannot find"),
    ;

    private final int errorCode;
    private final String errorMessage;

    JBusinessError(int errorCode, String errorMessage) {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    @Override
    public String toString() {
        return errorCode + ": " + errorMessage;
    }





}
