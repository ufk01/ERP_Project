package com.interline.logistics.library.common.page;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class BasePaginationRequestDto {

    private int pageSize;
    private int pageNumber;

}
