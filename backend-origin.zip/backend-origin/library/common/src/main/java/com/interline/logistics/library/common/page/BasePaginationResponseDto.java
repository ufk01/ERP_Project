package com.interline.logistics.library.common.page;

import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.List;

@Data
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class BasePaginationResponseDto<T> {

    private List<T> content;
    private int totalPages;
    private long totalElements;

}
