package com.interline.logistics.library.jwt.enums;

import lombok.Getter;

@Getter
public enum TokenInfo {
    USERNAME("username", "Kullanıcı Adı"),
    PASSWORD("password", "Şifre"),
    NAME("name", "İsim"),
    SURNAME("surname", "Soyad"),
    EMAIL("email", "E-Posta"),
    SECRET_KEY("secret-key", "Gizli Anahtar"),
    EXPIRATION_TIME("signature", "İmza"),
    HEADER("token", "local-storage token"),
    ISSUER("security-service", "Token kullanma yetkisi veren servis"),
    SUBJECT("subject", "Token özel id"),
    ISSUED_AT("issuedAt", "Token oluşturulma tarihi"),
    FRONTEND_PERMISSION("frontend-permission", "Kullanıcı ön yüz yetkileri"),
    REMAINDER_TOKEN_EXP("token-remainder-time", "Token son kullanma tarihi")
    ;
    private final String name;
    private final String description;

    TokenInfo(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public static TokenInfo fromName(String name){
        for(TokenInfo tokenInfo: TokenInfo.values()){
            if(tokenInfo.getName().equals(name)){
                return tokenInfo;
            }
        }
        throw new IllegalArgumentException("Invalid Token Info: " + name);
    }

}
