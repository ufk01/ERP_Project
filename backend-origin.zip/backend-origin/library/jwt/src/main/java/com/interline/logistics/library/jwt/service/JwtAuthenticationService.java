package com.interline.logistics.library.jwt.service;

import com.interline.logistics.library.jwt.enums.TokenInfo;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;


@Service
public class JwtAuthenticationService {

    public String generateToken(String subject, String name, String surname, String email, String tokenSecretKey, Long expirationTime) {
        Map<String, Object> claims = new HashMap<>();
        claims.put(TokenInfo.NAME.getName(), name);
        claims.put(TokenInfo.SURNAME.getName(), surname);
        claims.put(TokenInfo.EMAIL.getName(), email);
        return createToken(claims, subject, tokenSecretKey, expirationTime);
    }

    private String createToken(Map<String, Object> claims, String subject, String tokenSecretKey, Long expirationTime) {
        final byte[] decodedKey = Base64.getDecoder().decode(tokenSecretKey);
        final SecretKey secretKey = Keys.hmacShaKeyFor(decodedKey);
        return Jwts.builder()
                .setClaims(claims)
                .setSubject(subject)
                .setIssuer(TokenInfo.ISSUER.getName())
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + expirationTime))
                .signWith(secretKey, SignatureAlgorithm.HS256)
                .compact();
    }

    public boolean validateToken(String token, String tokenSecretKey) {
        final String extractSubjectByToken = extractSubjectToken(token, tokenSecretKey);
        return  !isTokenExpired(token, tokenSecretKey);
    }

    public String extractSubjectToken(String token, String tokenSecretKey) {
        return extractAllClaims(token, tokenSecretKey).getSubject();
    }
    public String extractClaimFromToken(String token, String tokenSecretKey, String claimName){
        final TokenInfo tokenInfo = TokenInfo.fromName(claimName);
        return extractClaim(token, tokenSecretKey, claims -> claims.get(tokenInfo.getName(),String.class));
    }

    private Claims extractAllClaims(String token, String tokenSecretKey) {
        final byte[] decodedKey = Base64.getDecoder().decode(tokenSecretKey);
        final SecretKey secretKey = Keys.hmacShaKeyFor(decodedKey);
        return Jwts.parserBuilder().setSigningKey(secretKey).build().parseClaimsJws(token).getBody();
    }

    private <T> T extractClaim(String token, String tokenSecretKey, Function<Claims, T> claimsResolver){
        Claims claims = extractAllClaims(token, tokenSecretKey);
        return claimsResolver.apply(claims);

    }

    private boolean isTokenExpired(String token, String tokenSecretKey) {
        return extractAllClaims(token, tokenSecretKey).getExpiration().before(new Date());
    }


}
