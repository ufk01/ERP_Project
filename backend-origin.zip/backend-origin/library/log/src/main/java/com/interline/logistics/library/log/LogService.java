package com.interline.logistics.library.log;

import jakarta.servlet.http.HttpServletRequest;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;


@Aspect
@Component

public class LogService {

    private static final Logger logger = LogManager.getLogger(LogService.class);
    private static String clientIp = null;

    @Pointcut("execution(* com.interline.logistics..*(..))")
    public void allMethods() {
        // For All Methods
    }

    @Before("allMethods()")
    public void logBefore(JoinPoint joinPoint) {
        logger.debug("Method {}. ",
                joinPoint.getSignature().getName());
        System.out.println("Method called: " + joinPoint.getSignature().getName());
    }

    @AfterReturning(pointcut = "allMethods()", returning = "result")
    public void logAfterReturning(JoinPoint joinPoint, Object result) {
        final ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        if(attributes != null){
            HttpServletRequest request = attributes.getRequest();
            clientIp = request.getRemoteAddr();
        }
        logger.debug("Method {} returned from IP:{} with Result: {}. ",
                joinPoint.getSignature().getName(),
                result,
                clientIp);
        System.out.println("Method called: " + joinPoint.getSignature().getName() + " Method returned: " + result + " From IP: " + clientIp);
    }

    @AfterThrowing(pointcut = "allMethods()", throwing = "error")
    public void logAfterThrowing(JoinPoint joinPoint, Throwable error) {
        final ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        if(attributes != null){
            HttpServletRequest request = attributes.getRequest();
            clientIp = request.getRemoteAddr();
        }
        final String errorMessage = error.getMessage();
        logger.error("Method {} threw an expectation from IP:{}. Error: {}. ",
                joinPoint.getSignature().getName(),
                clientIp,
                errorMessage);
        System.out.println("Method called: " + joinPoint.getSignature().getName() + " Method threw: " + errorMessage + " From IP: " + clientIp);
    }
}
