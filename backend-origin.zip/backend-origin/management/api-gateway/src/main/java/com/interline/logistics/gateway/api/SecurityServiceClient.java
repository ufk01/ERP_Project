package com.interline.logistics.gateway.api;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;


@FeignClient(name = "security-service")
@CrossOrigin(origins = "*")
@Component
public interface SecurityServiceClient {


    @PostMapping("/api/authenticate/control")
    Boolean authenticateUserPermissions(@RequestParam("username") String username,
                                        @RequestParam("module") String module,
                                        @RequestParam("point") String point,
                                        @RequestParam("operation") String operation);
}
