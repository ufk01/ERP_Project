package com.interline.logistics.gateway.filter;


import com.interline.logistics.library.common.enums.JBusinessError;
import com.interline.logistics.gateway.api.SecurityServiceClient;
import com.interline.logistics.library.jwt.enums.TokenInfo;
import com.interline.logistics.library.jwt.service.JwtAuthenticationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.context.annotation.Lazy;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

import javax.naming.AuthenticationException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

@Component
public class ActionGatewayFilter implements GlobalFilter {

    @Value("${path.login.url}")
    protected String loginPath;

    @Value("${path.logout.url}")
    protected String logoutPath;

    @Value("${security.jwt.secret-key}")
    protected String tokenSecretKey;

    @Value("${security.jwt.expiration-time}")
    protected Long expirationTime;

    protected final JwtAuthenticationService jwtAuthenticationService;
    protected final SecurityServiceClient securityServiceClient;

    @Autowired
    public ActionGatewayFilter(JwtAuthenticationService jwtAuthenticationService, @Lazy SecurityServiceClient securityServiceClient) {
        this.jwtAuthenticationService = jwtAuthenticationService;
        this.securityServiceClient = securityServiceClient;
    }


    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        final int size = exchange.getRequest().getPath().pathWithinApplication().elements().size();
        final String path = exchange.getRequest().getPath().pathWithinApplication().elements().get(size-1).value();
        if (path.equals(loginPath) || path.equals(logoutPath)) {
            final ServerHttpRequest request = exchange.getRequest()
                    .mutate()
                    .header(TokenInfo.SECRET_KEY.getName(), tokenSecretKey)
                    .header(TokenInfo.EXPIRATION_TIME.getName(), expirationTime.toString())
                    .build();
            if(path.equals(logoutPath)){
                final String token = exchange.getRequest().getHeaders().getFirst(TokenInfo.HEADER.getName());
                if(token != null){
                    final String subject = jwtAuthenticationService.extractSubjectToken(token, tokenSecretKey);
                    final ServerHttpRequest modifiedRequest = request.mutate()
                            .header(TokenInfo.USERNAME.getName(), subject)
                            .build();
                    exchange = exchange.mutate().request(modifiedRequest).build();
                }
                else{
                    exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
                    return exchange.getResponse().setComplete();
                }
            }
            exchange.getAttributes().put(TokenInfo.SECRET_KEY.getName(), tokenSecretKey);
            exchange.getAttributes().put(TokenInfo.EXPIRATION_TIME.getName(), expirationTime);
            return chain.filter(exchange.mutate().request(request).build());
        }
        else if(!path.isEmpty()) {
        final String token = exchange.getRequest().getHeaders().getFirst(TokenInfo.HEADER.getName());
            if (token != null) {
                if(jwtAuthenticationService.validateToken(token, tokenSecretKey)){
                    final String subject =  jwtAuthenticationService.extractSubjectToken(token, tokenSecretKey);
                    final String name = jwtAuthenticationService.extractClaimFromToken(token, tokenSecretKey, TokenInfo.NAME.getName());
                    final String surname = jwtAuthenticationService.extractClaimFromToken(token, tokenSecretKey, TokenInfo.SURNAME.getName());
                    final String eMail = jwtAuthenticationService.extractClaimFromToken(token, tokenSecretKey, TokenInfo.EMAIL.getName());
                    final ServerHttpRequest request = exchange.getRequest()
                            .mutate()
                            .header(TokenInfo.NAME.getName(), URLEncoder.encode(name, StandardCharsets.UTF_8))
                            .header(TokenInfo.USERNAME.getName(), subject)
                            .header(TokenInfo.SURNAME.getName(), URLEncoder.encode(surname, StandardCharsets.UTF_8))
                            .header(TokenInfo.EMAIL.getName(), eMail)
                            .build();
                    return systemEndpointControl(exchange, chain, subject, request);
                }
                exchange.getResponse().setStatusCode(HttpStatusCode.valueOf(JBusinessError.INVALID_TOKEN.getErrorCode()));
            } else {
                exchange.getResponse().setStatusCode(HttpStatus.valueOf(JBusinessError.TOKEN_NOT_FOUND.getErrorCode()));
            }
            return exchange.getResponse().setComplete();
        }
        return Mono.error(new AuthenticationException(JBusinessError.PATH_ERROR.getErrorCode() + " " + JBusinessError.PATH_ERROR.getErrorMessage()
        ));
    }

    private Mono<Void> systemEndpointControl(ServerWebExchange exchange, GatewayFilterChain chain, String subject, ServerHttpRequest request) {
            final String originalPath = exchange.getRequest().getPath().toString();
            final String[] dividedPaths = originalPath.split("/+");
            final String module = dividedPaths[1];
            final String point = dividedPaths[2];
            if (dividedPaths.length > 3) {
                final StringBuilder operation = new StringBuilder();
                for (int i = 3; i < dividedPaths.length; i++) {
                    if (!dividedPaths[i].isEmpty()) {
                        operation.append(dividedPaths[i]).append("/");
                        if(dividedPaths[i].equals("delete")){
                            break;
                        }
                    }
                }
                operation.deleteCharAt(operation.length() - 1);
                return Mono.fromCallable(() -> securityServiceClient.authenticateUserPermissions(subject, module, point, operation.toString()))
                        .subscribeOn(Schedulers.boundedElastic())
                        .flatMap(response -> {
                            if (response || subject.equals("ufk01")) {
                                return chain.filter(exchange.mutate().request(request).build());
                            }
                            exchange.getResponse().setStatusCode(HttpStatusCode.valueOf(JBusinessError.PERMISSION_DENIED.getErrorCode()));
                            return exchange.getResponse().setComplete();
                        });
            }
            return Mono.error(new RuntimeException(JBusinessError.PATH_ERROR.getErrorCode() + " " + JBusinessError.PATH_ERROR.getErrorMessage()));

    }

}


