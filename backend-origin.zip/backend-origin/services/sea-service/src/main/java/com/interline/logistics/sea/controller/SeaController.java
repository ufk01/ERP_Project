package com.interline.logistics.sea.controller;

import com.interline.logistics.library.common.enums.JBusinessError;
import com.interline.logistics.sea.model.SeaDto;
import com.interline.logistics.sea.model.page.SeaRequestPageDto;
import com.interline.logistics.sea.model.page.SeaResponsePageDto;
import com.interline.logistics.sea.service.SeaService;
import jakarta.servlet.http.HttpServletRequest;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/sea-service/definition")
public class SeaController {

    @Autowired
    private SeaService seaService;

    @PostMapping("/save")
    public ResponseEntity<SeaDto> save(@NotNull HttpServletRequest httpServletRequest, @RequestBody SeaDto seaDto) throws Exception {
        return ResponseEntity
                .status(HttpStatus.OK)
                .body(seaService.save(httpServletRequest, seaDto));
    }

    @PutMapping("/update")
    public ResponseEntity<SeaDto> update(@NotNull HttpServletRequest httpServletRequest, @RequestBody SeaDto seaDto) throws Exception {
        return ResponseEntity
                .status(HttpStatus.OK)
                .body(seaService.update(httpServletRequest, seaDto));
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> delete(@PathVariable(value = "id", required = false) Long id) throws Exception {
        try{
            seaService.delete(id);
            return ResponseEntity.status(HttpStatus.OK).build();
        } catch (Exception e) {
            throw new Exception(JBusinessError.PROCESS_ERROR.toString());
        }

    }

    @PostMapping("/pagination")
    ResponseEntity<SeaResponsePageDto> pagination(@RequestBody SeaRequestPageDto seaRequestPageDto) {
        return ResponseEntity
                .status(HttpStatus.OK)
                .body(seaService.pagination(seaRequestPageDto));
    }

    @GetMapping("/all")
    ResponseEntity<List<SeaDto>> all() {
        return ResponseEntity
                .status(HttpStatus.OK)
                .body(seaService.all());
    }

    @GetMapping("/find/{id}")
    ResponseEntity<SeaDto> find(@PathVariable(value = "id", required = false) Long id) throws Exception {
        return ResponseEntity
                .status(HttpStatus.OK)
                .body(seaService.find(id));
    }


}
