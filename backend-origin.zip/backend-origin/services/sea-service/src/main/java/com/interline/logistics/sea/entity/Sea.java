package com.interline.logistics.sea.entity;

import com.interline.logistics.sea.enums.*;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;



import java.time.LocalDateTime;
@Getter
@Setter
@Table(name = "sea", schema = "sea_module" )
@Entity
@NoArgsConstructor
@AllArgsConstructor
public class Sea {

    @Id
    @SequenceGenerator(name = "sea_seq", sequenceName = "sea_seq", allocationSize = 1, schema = "sea_module")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "sea_seq")
    private Long id;

    @Column(name = "reference_no")
    private String refNo;

    @Column(name = "lcl_ftl")
    @Enumerated(EnumType.STRING)
    private LclAndFtl lclAndFtl;

    @Column(name = "work_approval_date")
    private LocalDateTime workApprovalDate;

    @Column(name = "inco")
    @Enumerated(EnumType.STRING)
    private Inco inco;

    @Column(name = "exporter")
    private String exporter;

    @Column(name = "customer_name")
    private String customerName;

    @Column(name = "agency")
    @Enumerated(EnumType.STRING)
    private Agency agency;

    @Column(name = "loading_country")
    @Enumerated(EnumType.STRING)
    private LoadingCountry loadingCountry;

    @Column(name = "port_arrival")
    @Enumerated(EnumType.STRING)
    private PortArrival portArrival;

    @Column(name = "port_departure")
    @Enumerated(EnumType.STRING)
    private PortDeparture portDeparture;

    @Column(name = "destination_city")
    @Enumerated(EnumType.STRING)
    private DestinationCity destinationCity;

    @Column(name = "etd")
    private LocalDateTime etd;

    @Column(name = "eta")
    private LocalDateTime eta;

    @Column(name = "number_of_containers")
    private Long numberOfContainers;

    @Column(name = "cbm")
    private Double cbm;

    @Column(name = "purchase_freight")
    private String purchaseFreight;

    @Column(name = "sales_freight")
    private String salesFreight;

    @Column(name = "situation")
    @Enumerated(EnumType.STRING)
    private Situation situation;

    @Column(name = "created_time")
    private LocalDateTime createdTime;

    @Column(name = "updated_time")
    private LocalDateTime updatedTime;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "last_modified_by")
    private String lastModifiedBy;

    @Column(name = "service")
    @Enumerated(EnumType.STRING)
    private Service service;

    @Column(name = "vessel")
    private String vessel;

    @Column(name = "pu_rd_ıw")
    private LocalDateTime puRdIw;

    @Column(name = "kg")
    private Double kg;

    @Column(name = "insurance")
    private String insurance;

    @Column(name = "rate")
    private String rate;

    @Column(name = "bl")
    private String bl;

}
