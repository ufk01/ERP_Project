package com.interline.logistics.sea.enums;

import lombok.Getter;

@Getter
public enum Agency {
    CTL("CTL"),
    HUNICORN("Hunicorn"),
    CARGOPIA("Cargopia"),
    UNIMAR("Unimar"),
    KHEE("KHEE"),
    DT_ASIA("DT-ASIA");

    private final String displayName;

    Agency(String displayName) {
        this.displayName = displayName;
    }

}
