package com.interline.logistics.sea.enums;

import lombok.Getter;

@Getter
public enum DestinationCity {
    TURKEY_ISTANBUL("Türkiye/İstanbul"),
    TURKEY_IZMIT("Türkiye/İzmit"),
    TURKEY_MERSIN("Türkiye/Mersin");

    private final String displayName;

    DestinationCity(String displayName) {
        this.displayName = displayName;
    }

}
