package com.interline.logistics.sea.enums;

public enum Inco {
    EXW,
    FOB,
    FCA,
    DAP,
    DDP

}
