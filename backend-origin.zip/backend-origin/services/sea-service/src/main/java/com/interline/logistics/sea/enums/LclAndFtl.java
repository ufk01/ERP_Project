package com.interline.logistics.sea.enums;

public enum LclAndFtl {
    LCL,
    FTL
}
