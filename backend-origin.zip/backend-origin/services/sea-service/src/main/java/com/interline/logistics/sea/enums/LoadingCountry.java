package com.interline.logistics.sea.enums;

import lombok.Getter;

@Getter
public enum LoadingCountry {
    AUSTRALIA("Australia"),
    BANGLADESH("Bangladesh"),
    CAMBODIA("Cambodia"),
    CHINA("China"),
    INDIA("India"),
    INDONESIA("Indonesia"),
    JAPAN("Japan"),
    MALAYSIA("Malaysia"),
    MAURITIUS("Mauritius"),
    NEW_ZELAND("New Zealand"),
    PAKISTAN("Pakistan"),
    PHILIPPINES("Philippines"),
    S_AFRICA("South Africa"),
    S_KOREA("South Korea"),
    SRI_LANKA("Sri Lanka"),
    TAIWAN("Taiwan"),
    THAILAND("Thailand"),
    UAE("United Arab Emirates"),
    USA("United States"),
    VIETNAM("Vietnam");

    private final String displayName;

    LoadingCountry(String displayName) {
        this.displayName = displayName;
    }

}
