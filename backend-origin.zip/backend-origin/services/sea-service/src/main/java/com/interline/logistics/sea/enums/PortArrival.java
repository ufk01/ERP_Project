package com.interline.logistics.sea.enums;

import lombok.Getter;

@Getter
public enum PortArrival {
    AMBARLI("Ambarlı"),
    IZMIT("İzmit"),
    MERSIN("Mersin");

    private final String displayName;

    PortArrival(String displayName) {
        this.displayName = displayName;
    }


    }
