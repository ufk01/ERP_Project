package com.interline.logistics.sea.enums;

import lombok.Getter;

@Getter
public enum Service {
    SUEZ("Suez"),
    CAPE_OF_GOOD_HOPE("Cape of Good Hope");

    private final String displayName;

    Service(String displayName) {
        this.displayName = displayName;
    }

}
