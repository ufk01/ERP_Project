package com.interline.logistics.sea.enums;

import lombok.Getter;

@Getter
public enum Situation {

    RESERVATION_PENDING("Rezervasyon bekleniyor"),
    WAITING_FOR_CARGO_ARRIVAL("Yükün depoya gelmesi bekleniyor"),
    WAITING_FOR_SHIPPER("Gönderici bekleniyor"),
    WAITING_FOR_SHIP_DEPARTURE("Gemi çıkışı bekleniyor"),
    IN_TRANSIT("Yolda"),
    SHIP_ARRIVED("Gemi geldi"),
    ORDINO_DELIVERED("Ordino teslimi yapıldı"),
    IN_WAREHOUSE("Antrepoda"),
    CANCELED("İptal Edildi");

    private final String displayName;

    Situation(String displayName) {
        this.displayName = displayName;
    }

}
