package com.interline.logistics.sea.mapper;

import com.interline.logistics.sea.entity.Sea;
import com.interline.logistics.sea.model.SeaDto;
import com.interline.logistics.sea.model.SeaPaginationDto;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;
import java.util.Set;

@Mapper
public interface SeaMapper {

    SeaMapper SeaMapper = Mappers.getMapper(SeaMapper.class);

    Sea seaDtoToSea(SeaDto seaDto);
    SeaDto seaToSeaDto(Sea sea);
    Set<Sea> seaDtoSetToSeaSet(Set<SeaDto> seaDtoSet);
    Set<SeaDto> seaSetToSeaDtoSet(Set<Sea> seaSet);
    List<SeaDto> seaListToSeaDtoList(List<Sea> seaList);
    List<SeaPaginationDto> seaListToSeaPaginationDtoList(List<Sea> seaList);
}
