package com.interline.logistics.sea.model;


import com.interline.logistics.sea.enums.*;
import jakarta.persistence.Column;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter
@Setter

public class SeaDto {

    private Long id;
    private String refNo;
    private LclAndFtl lclAndFtl;
    private LocalDateTime workApprovalDate;
    private Inco inco;
    private String exporter;
    private String customerName;
    private Agency agency;
    private LoadingCountry loadingCountry;
    private PortArrival portArrival;
    private PortDeparture portDeparture;
    private DestinationCity destinationCity;
    private LocalDateTime etd;
    private LocalDateTime eta;
    private Long numberOfContainers;
    private Double cbm;
    private String purchaseFreight;
    private String salesFreight;
    private Situation situation;
    private LocalDateTime createdTime;
    private LocalDateTime updatedTime;
    private String createdBy;
    private String lastModifiedBy;
    private Service service;
    private String vessel;
    private LocalDateTime puRdIw;
    private Double kg;
    private String insurance;
    private String rate;
    private String bl;



}
