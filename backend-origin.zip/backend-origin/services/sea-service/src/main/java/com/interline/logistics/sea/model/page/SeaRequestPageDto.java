package com.interline.logistics.sea.model.page;

import com.interline.logistics.library.common.page.BasePaginationRequestDto;
import com.interline.logistics.sea.enums.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;

@Getter
@Setter
public class SeaRequestPageDto extends BasePaginationRequestDto {

    private String refNo;
    private LclAndFtl lclAndFtl;
    private LocalDateTime workApprovalDate;
    private Inco inco;
    private String exporter;
    private String customerName;
    private Agency agency;
    private LoadingCountry loadingCountry;
    private PortArrival portArrival;
    private PortDeparture portDeparture;
    private DestinationCity destinationCity;
    private LocalDateTime etd;
    private LocalDateTime eta;
    private Long numberOfContainers;
    private Double cbm;
    private String purchaseFreight;
    private String salesFreight;
    private List<Situation> situation;
    private LocalDateTime updatedTime;
    private Service service;
    private String vessel;
    private LocalDateTime puRdIw;
    private Double kg;
    private String insurance;
    private String rate;
    private String bl;


}
