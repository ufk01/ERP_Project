package com.interline.logistics.sea.model.page;

import com.interline.logistics.library.common.page.BasePaginationResponseDto;
import com.interline.logistics.sea.model.SeaPaginationDto;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@Getter
@Setter
public class SeaResponsePageDto extends BasePaginationResponseDto<SeaPaginationDto> {



}
