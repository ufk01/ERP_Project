package com.interline.logistics.sea.repository;

import com.interline.logistics.sea.entity.Sea;
import com.interline.logistics.sea.enums.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface SeaRepository extends JpaRepository<Sea, Long> {

    @Query(
            """
            select s.refNo
            from Sea as s
            where (s.refNo = :refNo)
            """
    )
    Optional<String> findRefNo(@Param("refNo") String refNo);

    @Query("""
            select s
            from Sea as s
            where (:refNo is null or :refNo = '' or s.refNo like concat('%', :refNo, '%'))
              and (:lclAndFtl is null or s.lclAndFtl = :lclAndFtl)
              and (:inco is null or s.inco = :inco)
              and (:exporter is null or :exporter = '' or s.exporter like concat('%', :exporter, '%'))
              and (:customerName is null or :customerName = '' or s.customerName like concat('%', :customerName, '%'))
              and (:agency is null or s.agency = :agency)
              and (:loadingCountry is null or s.loadingCountry = :loadingCountry)
              and (:portArrival is null or s.portArrival = :portArrival)
              and (:portDeparture is null or s.portDeparture = :portDeparture)
              and (:destinationCity is null or s.destinationCity = :destinationCity)
              and (:numberOfContainers is null or s.numberOfContainers = :numberOfContainers)
              and (:cbm is null or s.cbm = :cbm)
              and (:purchaseFreight is null or :purchaseFreight = '' or s.purchaseFreight like concat('%', :purchaseFreight, '%'))
              and (:salesFreight is null or :salesFreight = '' or s.salesFreight like concat('%', :salesFreight, '%'))
              and (:situation is null or s.situation in :situation)
              and (:service is null or s.service = :service)
              and (s.workApprovalDate >= :workApprovalDate)
              and (s.etd >= :etd)
              and (s.eta >= :eta)
              and (s.updatedTime >= :updatedTime)
              and (:vessel is null or :vessel = '' or s.vessel like concat('%', :vessel, '%'))
              and (s.puRdIw >= :puRdIw)
              and (:kg is null or s.kg = :kg)
              and (:insurance is null or :insurance = '' or s.insurance like concat('%', :insurance, '%'))
              and (:rate is null or :rate = '' or s.rate like concat('%', :rate, '%'))
              and (:bl is null or :bl = '' or s.rate like concat('%', :bl, '%'))
            """)
    Page<Sea> findSeaPagination(@Param("refNo") String refNo,
                                @Param("lclAndFtl") LclAndFtl lclAndFtl,
                                @Param("inco") Inco inco,
                                @Param("exporter") String exporter,
                                @Param("customerName") String customerName,
                                @Param("agency")Agency agency,
                                @Param("loadingCountry") LoadingCountry loadingCountry,
                                @Param("portArrival")PortArrival portArrival,
                                @Param("portDeparture") PortDeparture portDeparture,
                                @Param("destinationCity") DestinationCity destinationCity,
                                @Param("numberOfContainers") Long numberOfContainers,
                                @Param("cbm") Double cbm,
                                @Param("purchaseFreight") String purchaseFreight,
                                @Param("salesFreight") String salesFreight,
                                @Param("situation") List<Situation> situation,
                                @Param("service") Service service,
                                @Param("workApprovalDate")LocalDateTime workApprovalDate,
                                @Param("etd") LocalDateTime etd,
                                @Param("eta") LocalDateTime eta,
                                @Param("updatedTime") LocalDateTime updatedTime,
                                @Param("vessel") String vessel,
                                @Param("puRdIw") LocalDateTime puRdIw,
                                @Param("kg") Double kg,
                                @Param("insurance") String insurance,
                                @Param("rate") String rate,
                                @Param("bl") String bl,
                                Pageable pageable);



}
