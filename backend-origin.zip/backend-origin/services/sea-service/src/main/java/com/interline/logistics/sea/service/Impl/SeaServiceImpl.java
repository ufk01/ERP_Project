package com.interline.logistics.sea.service.Impl;

import com.interline.logistics.library.common.enums.JBusinessError;
import com.interline.logistics.library.jwt.enums.TokenInfo;
import com.interline.logistics.sea.entity.Sea;
import com.interline.logistics.sea.mapper.SeaMapper;
import com.interline.logistics.sea.model.SeaDto;
import com.interline.logistics.sea.model.page.SeaRequestPageDto;
import com.interline.logistics.sea.model.page.SeaResponsePageDto;
import com.interline.logistics.sea.repository.SeaRepository;
import com.interline.logistics.sea.service.SeaService;
import jakarta.servlet.http.HttpServletRequest;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class SeaServiceImpl implements SeaService {

    private static SeaMapper seaMapper;
    final private SeaRepository seaRepository;

    public SeaServiceImpl(SeaRepository seaRepository){
        seaMapper = SeaMapper.SeaMapper;
        this.seaRepository = seaRepository;
    }

    @Override
    @Transactional
    public SeaDto save(@NotNull HttpServletRequest httpServletRequest, SeaDto seaDto) throws Exception {
        final Sea sea = seaMapper.seaDtoToSea(seaDto);
        Optional<String> optionalRefNo = seaRepository.findRefNo(sea.getRefNo());
        if(optionalRefNo.isEmpty()){
            final String username = httpServletRequest.getHeader(TokenInfo.USERNAME.getName());
            sea.setWorkApprovalDate(sea.getWorkApprovalDate() != null ? sea.getWorkApprovalDate() : LocalDateTime.of(1800,1, 1, 0, 0,0) );
            sea.setEta(sea.getEta() != null ? sea.getEta() : LocalDateTime.of(1800,1, 1, 0, 0,0) );
            sea.setEtd(sea.getEtd() != null ? sea.getEtd() : LocalDateTime.of(1800,1, 1, 0, 0,0) );
            sea.setPuRdIw(sea.getPuRdIw() != null ? sea.getPuRdIw() : LocalDateTime.of(1800, 1, 1,0, 0, 0) );
            sea.setCreatedBy(username);
            sea.setLastModifiedBy(username);
            sea.setCreatedTime(LocalDateTime.now());
            sea.setUpdatedTime(LocalDateTime.now());
            final Sea savedSea = seaRepository.save(sea);
            return seaMapper.seaToSeaDto(savedSea);
        }
        throw new Exception(JBusinessError.INVALID_SEA_DATA.getErrorCode() + " " + JBusinessError.INVALID_SEA_DATA.getErrorMessage());
    }

    @Override
    @Transactional
    public SeaDto update(@NotNull HttpServletRequest httpServletRequest, SeaDto seaDto) throws Exception {
        final Sea sea = seaMapper.seaDtoToSea(seaDto);
        Optional<Sea> optionalSea = seaRepository.findById(sea.getId());
        if(optionalSea.isPresent()){
            final Sea existSea = optionalSea.get();
            BeanUtils.copyProperties(sea, existSea, "createdBy", "createdTime", "id");
            final String username = httpServletRequest.getHeader(TokenInfo.USERNAME.getName());
            existSea.setWorkApprovalDate(existSea.getWorkApprovalDate() != null ? existSea.getWorkApprovalDate() : LocalDateTime.of(1800,1, 1, 0, 0,0) );
            existSea.setEta(sea.getEta() != null ? existSea.getEta() : LocalDateTime.of(1800,1, 1, 0, 0,0) );
            existSea.setEtd(sea.getEtd() != null ? existSea.getEtd() : LocalDateTime.of(1800,1, 1, 0, 0,0) );
            existSea.setPuRdIw(sea.getPuRdIw() != null ? sea.getPuRdIw() : LocalDateTime.of(1800, 1, 1,0, 0, 0) );
            existSea.setLastModifiedBy(username);
            existSea.setUpdatedTime(LocalDateTime.now());
            final Sea savedSea = seaRepository.save(existSea);
            return seaMapper.seaToSeaDto(savedSea);
        }
        throw new Exception(JBusinessError.DATA_NOT_FOUND.getErrorCode() + " " + JBusinessError.DATA_NOT_FOUND.getErrorMessage());
    }

    @Override
    @Transactional
    public void delete(Long id) throws Exception {
        final Sea sea = seaRepository.findById(id)
                .orElseThrow(() -> new Exception(JBusinessError.DATA_NOT_FOUND.getErrorCode() + " " + JBusinessError.DATA_NOT_FOUND.getErrorMessage()));
        seaRepository.delete(sea);
    }

    @Override
    public SeaResponsePageDto pagination(SeaRequestPageDto seaRequestPageDto) {
        seaRequestPageDto.setWorkApprovalDate(seaRequestPageDto.getWorkApprovalDate() != null ? seaRequestPageDto.getWorkApprovalDate() : LocalDateTime.of(1700,1, 1, 0, 0,0) );
        seaRequestPageDto.setEta(seaRequestPageDto.getEta() != null ? seaRequestPageDto.getEta() : LocalDateTime.of(1700,1, 1, 0, 0,0) );
        seaRequestPageDto.setEtd(seaRequestPageDto.getEtd() != null ? seaRequestPageDto.getEtd() : LocalDateTime.of(1700,1, 1, 0, 0,0) );
        seaRequestPageDto.setPuRdIw( seaRequestPageDto.getPuRdIw() != null ? seaRequestPageDto.getPuRdIw() : LocalDateTime.of(1700,1,1,0,0,0) );
        final Page<Sea> seaPage = seaRepository.findSeaPagination(
                seaRequestPageDto.getRefNo(), seaRequestPageDto.getLclAndFtl(),
                seaRequestPageDto.getInco(),seaRequestPageDto.getExporter(),
                seaRequestPageDto.getCustomerName(),seaRequestPageDto.getAgency(),
                seaRequestPageDto.getLoadingCountry(),seaRequestPageDto.getPortArrival(),
                seaRequestPageDto.getPortDeparture(), seaRequestPageDto.getDestinationCity(),
                seaRequestPageDto.getNumberOfContainers(), seaRequestPageDto.getCbm(),
                seaRequestPageDto.getPurchaseFreight(), seaRequestPageDto.getSalesFreight(),
                seaRequestPageDto.getSituation().isEmpty() ? null : seaRequestPageDto.getSituation(), seaRequestPageDto.getService(),
                seaRequestPageDto.getWorkApprovalDate(),
                seaRequestPageDto.getEtd(), seaRequestPageDto.getEta(),
                seaRequestPageDto.getUpdatedTime() != null ? seaRequestPageDto.getUpdatedTime() : LocalDateTime.of(1700, 1, 1,0,0,0),
                seaRequestPageDto.getVessel(), seaRequestPageDto.getPuRdIw(),
                seaRequestPageDto.getKg(), seaRequestPageDto.getInsurance(), seaRequestPageDto.getRate(), seaRequestPageDto.getBl(),
                PageRequest.of(seaRequestPageDto.getPageNumber(), seaRequestPageDto.getPageSize(), Sort.by(Sort.Order.desc("id")))
        );
        seaPage.forEach(page -> {
            page.setWorkApprovalDate(page.getWorkApprovalDate().isEqual(LocalDateTime.of(1800, 1, 1,0, 0, 0)) ? null : page.getWorkApprovalDate());
            page.setEta(page.getEta().isEqual(LocalDateTime.of(1800, 1, 1,0, 0, 0)) ? null : page.getEta());
            page.setEtd(page.getEtd().isEqual(LocalDateTime.of(1800, 1, 1,0, 0, 0)) ? null : page.getEtd());
            page.setPuRdIw(page.getPuRdIw().isEqual(LocalDateTime.of(1800, 1, 1, 0, 0)) ? null : page.getPuRdIw());
        });
        return SeaResponsePageDto.builder()
                .content(seaMapper.seaListToSeaPaginationDtoList(seaPage.getContent()))
                .totalElements(seaPage.getTotalElements())
                .totalPages(seaPage.getTotalPages())
                .build();

    }

    @Override
    public List<SeaDto> all() {
        final List<Sea> seaList = seaRepository.findAll();
        return seaMapper.seaListToSeaDtoList(seaList);
    }

    @Override
    public SeaDto find(Long id) throws Exception {
        Optional<Sea> optionalSea = seaRepository.findById(id);
        if(optionalSea.isPresent()){
            return seaMapper.seaToSeaDto(optionalSea.get());
        }
        throw new Exception(JBusinessError.DATA_NOT_FOUND.getErrorCode() + " " + JBusinessError.DATA_NOT_FOUND.getErrorMessage());
    }
}
