package com.interline.logistics.sea.service;

import com.interline.logistics.sea.model.SeaDto;
import com.interline.logistics.sea.model.page.SeaResponsePageDto;
import com.interline.logistics.sea.model.page.SeaRequestPageDto;
import jakarta.servlet.http.HttpServletRequest;
import org.jetbrains.annotations.NotNull;

import java.util.List;

public interface SeaService {

    SeaDto save(@NotNull HttpServletRequest httpServletRequest, SeaDto seaDto) throws Exception;
    SeaDto update(@NotNull HttpServletRequest httpServletRequest,  SeaDto seaDto) throws Exception;
    void delete(Long id) throws Exception;
    SeaResponsePageDto pagination(SeaRequestPageDto seaRequestPageDto);
    List<SeaDto> all();
    SeaDto find(Long id) throws Exception;

}
