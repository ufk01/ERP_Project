package com.interline.logistics.authorization.controller.api;


import com.interline.logistics.authorization.service.detail.UserDetailService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/authenticate")
public class GatewayAuthenticationController {

    private final UserDetailService userDetailService;

    public GatewayAuthenticationController(UserDetailService userDetailService) {
        this.userDetailService = userDetailService;
    }



    @PostMapping("/control")
    public Boolean checkUserPermissions(@RequestParam("username") String username,
                                                          @RequestParam("module") String module,
                                                          @RequestParam("point") String point,
                                                          @RequestParam("operation") String operation) {
        try {
            return userDetailService.checkUserPermissions(username, module, point, operation);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build().hasBody();
        }
    }

}
