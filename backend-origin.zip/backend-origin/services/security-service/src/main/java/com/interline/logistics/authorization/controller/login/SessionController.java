package com.interline.logistics.authorization.controller.login;

import com.interline.logistics.authorization.entity.userDetail.UserLoginDto;
import com.interline.logistics.authorization.service.detail.UserDetailService;
import com.interline.logistics.library.jwt.enums.TokenInfo;
import jakarta.servlet.http.HttpServletRequest;
import org.jetbrains.annotations.NotNull;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;

@RestController
@RequestMapping("/user-authorization-detail")

public class SessionController {

    private final UserDetailService userDetailService;

    public SessionController(UserDetailService userDetailService) {
        this.userDetailService = userDetailService;
    }

    @PostMapping("/login")
    public ResponseEntity<HashMap<String, String>> userLogin(@RequestBody UserLoginDto userLoginDto, HttpServletRequest httpServletRequest) {
        final String secretKey = String.valueOf(httpServletRequest.getHeaders(TokenInfo.SECRET_KEY.getName()).nextElement());
        final Long expirationTime = Long.valueOf(String.valueOf(httpServletRequest.getHeaders(TokenInfo.EXPIRATION_TIME.getName()).nextElement()));
        try{
            return userDetailService.login(userLoginDto.getUsername(), userLoginDto.getPassword(), secretKey, expirationTime);
        } catch (Exception e){
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PostMapping("/logout")
    public void userLogout(@NotNull HttpServletRequest httpServletRequest) throws Exception{
        try{
            userDetailService.logout(httpServletRequest);
        } catch (Exception e){
            throw new Exception(HttpStatus.INTERNAL_SERVER_ERROR.toString());
        }

    }
}
