package com.interline.logistics.authorization.controller.permission;

import com.interline.logistics.authorization.model.permission.PermissionDto;
import com.interline.logistics.authorization.model.permission.page.PermissionPageDto;
import com.interline.logistics.authorization.model.permission.page.PermissionRequestPageDto;
import com.interline.logistics.authorization.service.permission.PermissionService;
import com.interline.logistics.library.common.enums.JBusinessError;
import jakarta.servlet.http.HttpServletRequest;
import org.jetbrains.annotations.NotNull;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Set;


@RestController
@RequestMapping("/security-service/permission-authorization")
public class PermissionController {

    private final PermissionService permissionService;

    public PermissionController(PermissionService permissionService) {
        this.permissionService = permissionService;
    }

    @PostMapping("/save")
    public ResponseEntity<PermissionDto> savePermission(@RequestBody PermissionDto permissionDto,
                                                        @NotNull HttpServletRequest httpServletRequest) throws Exception {
        return ResponseEntity
                .status(HttpStatus.OK)
                .body(permissionService.savePermission(httpServletRequest, permissionDto));
    }

    @GetMapping("/get/{id}")
    public ResponseEntity<PermissionDto> getPermission(@PathVariable(value = "id", required = false) Long id) throws Exception {
        return ResponseEntity
                .status(HttpStatus.OK)
                .body(permissionService.getPermission(id));
    }
    @PutMapping("/update")
    public ResponseEntity<PermissionDto> updatePermission(@RequestBody PermissionDto permissionDto,
                                                          @NotNull HttpServletRequest httpServletRequest) throws Exception {
        return ResponseEntity
                .status(HttpStatus.OK)
                .body(permissionService.updatePermission(httpServletRequest, permissionDto));
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deletePermission(@PathVariable(value = "id", required = false) Long id) throws Exception {
        try {
            permissionService.deletePermission(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            throw new Exception(JBusinessError.PROCESS_ERROR.toString());
        }
    }

    @PostMapping("/pagination")
    public ResponseEntity<PermissionPageDto> getPermissionPagination(@RequestBody PermissionRequestPageDto permissionRequestPageDto) {
        return ResponseEntity
                .status(HttpStatus.OK)
                .body(permissionService.getPermissionsPage(permissionRequestPageDto));
    }

    @GetMapping("/all")
    public ResponseEntity<Set<String>> getAllPermissions() throws Exception {
        return ResponseEntity
                .status(HttpStatus.OK)
                .body(permissionService.getAllPermissions());
    }

    @GetMapping("/find")
    public ResponseEntity<Long> getPermissionId(@RequestParam(value = "name") String name,
                                                @RequestParam(value = "modulePermission") String modulePermission,
                                                @RequestParam(value = "pointPermission") String pointPermission,
                                                @RequestParam(value = "operationPermission") String operationPermission) throws Exception {
        return ResponseEntity
                .status(HttpStatus.OK)
                .body(permissionService.findPermissionId(name, modulePermission, pointPermission, operationPermission));
    }

}
