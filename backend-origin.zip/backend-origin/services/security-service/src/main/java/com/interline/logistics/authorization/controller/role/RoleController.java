package com.interline.logistics.authorization.controller.role;

import com.interline.logistics.authorization.model.role.RoleDto;
import com.interline.logistics.authorization.model.role.page.RolePageDto;
import com.interline.logistics.authorization.model.role.page.RoleRequestPageDto;
import com.interline.logistics.authorization.service.role.RoleService;
import com.interline.logistics.library.common.enums.JBusinessError;
import jakarta.servlet.http.HttpServletRequest;
import org.jetbrains.annotations.NotNull;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

@RestController
@RequestMapping("/security-service/role-authorization")
public class RoleController {

    final RoleService roleService;

    public RoleController(RoleService roleService) {
        this.roleService = roleService;
    }

    @PostMapping("/save")
    public ResponseEntity<RoleDto> saveRole(@RequestBody RoleDto roleDto,
                                            @NotNull HttpServletRequest httpServletRequest) throws Exception {
        return ResponseEntity
                .status(HttpStatus.OK)
                .body(roleService.saveRole(httpServletRequest, roleDto));
    }

    @PutMapping("/update")
    public ResponseEntity<RoleDto> updateRole(@RequestBody RoleDto roleDto,
                                              @NotNull HttpServletRequest httpServletRequest) throws Exception {
        return ResponseEntity
                .status(HttpStatus.OK)
                .body(roleService.updateRole(httpServletRequest,roleDto));
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> deleteRole(@PathVariable(value = "id", required = false) Long id) throws Exception {
        try{
            roleService.deleteRole(id);
            return ResponseEntity.noContent().build();
        }
        catch (Exception e){
            throw new RuntimeException(JBusinessError.PROCESS_ERROR.toString());
        }
    }

    @GetMapping("/get/{id}")
    public ResponseEntity<RoleDto> getRole(@PathVariable(value = "id", required = false) Long id) throws Exception {
        return ResponseEntity
                .status(HttpStatus.OK)
                .body(roleService.getRole(id));
    }

    @GetMapping("/all")
    public ResponseEntity<Set<RoleDto>> getAllRole() throws Exception {
        return ResponseEntity
                .status(HttpStatus.OK)
                .body(roleService.getAllRoles());
    }

    @PostMapping("/pagination")
    public ResponseEntity<RolePageDto> getRolePagination(@RequestBody RoleRequestPageDto roleRequestPageDto) throws Exception {
        return ResponseEntity
                .status(HttpStatus.OK)
                .body(roleService.getRolePagination(roleRequestPageDto));
    }

    @GetMapping("/find")
    public ResponseEntity<RoleDto> getRoleByUsername(@RequestParam("roleName") String roleName) throws Exception{
        return ResponseEntity
                .status(HttpStatus.OK)
                .body(roleService.getRoleByUsername(roleName));
    }

    @GetMapping("/find/roleNames")
    public ResponseEntity<Set<String>> getRoleNames() throws Exception {
        return ResponseEntity
                .status(HttpStatus.OK)
                .body(roleService.getRolesName());
    }




}
