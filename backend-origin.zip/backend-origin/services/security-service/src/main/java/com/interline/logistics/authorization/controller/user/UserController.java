package com.interline.logistics.authorization.controller.user;

import com.interline.logistics.authorization.model.user.UserDto;
import com.interline.logistics.authorization.model.user.page.UserPageDto;
import com.interline.logistics.authorization.model.user.page.UserRequestPageDto;
import com.interline.logistics.authorization.service.user.UserService;
import com.interline.logistics.library.common.enums.JBusinessError;
import jakarta.servlet.http.HttpServletRequest;
import org.jetbrains.annotations.NotNull;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

@RestController
@RequestMapping("/security-service/user-authorization")
public class UserController {

    final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/save")
    public ResponseEntity<UserDto> save(@RequestBody UserDto userDto,
                                        @NotNull HttpServletRequest httpServletRequest) throws Exception {
        return ResponseEntity
                .status(HttpStatus.OK)
                .body(userService.save(httpServletRequest, userDto));
    }

    @PutMapping("/update")
    public ResponseEntity<UserDto> update(@RequestBody UserDto userDto,
                                          @NotNull HttpServletRequest httpServletRequest) throws Exception {
     return ResponseEntity
             .status(HttpStatus.OK)
             .body(userService.update(httpServletRequest, userDto));
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Void> delete(@PathVariable(value = "id", required = false) Long id) throws Exception {
        try{
            userService.delete(id);
            return ResponseEntity.noContent().build();
        }
        catch (Exception e){
            return ResponseEntity.status(JBusinessError.PROCESS_ERROR.getErrorCode()).build();
        }
    }

    @GetMapping("/get/{id}")
    public ResponseEntity<UserDto> get(@PathVariable(value = "id", required = false) Long id) throws Exception {
        return ResponseEntity
                .status(HttpStatus.OK)
                .body(userService.getUser(id));
    }

    @GetMapping("/get/all")
    public ResponseEntity<Set<UserDto>> getAll() throws Exception {
        return ResponseEntity
                .status(HttpStatus.OK)
                .body(userService.getAllUsers());
    }

    @PostMapping("/pagination")
    public ResponseEntity<UserPageDto> getUserPagination(@RequestBody UserRequestPageDto userRequestPageDto){
        return ResponseEntity
                .status(HttpStatus.OK)
                .body(userService.getUserPagination(userRequestPageDto));
    }

    @GetMapping("/find")
    public ResponseEntity<UserDto> getUserByUsernameAndEmail(@RequestParam(value = "username", required = false) String username,
                                          @RequestParam(value = "email", required = false) String email) throws Exception{
        return ResponseEntity
                .status(HttpStatus.OK)
                .body(userService.getUserByUsernameAndEmail(username, email));
    }



}
