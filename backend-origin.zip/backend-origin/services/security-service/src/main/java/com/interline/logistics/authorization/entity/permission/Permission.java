package com.interline.logistics.authorization.entity.permission;


import com.interline.logistics.authorization.entity.role.Role;
import com.interline.logistics.authorization.entity.user.User;
import com.interline.logistics.authorization.enums.permission.Types;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;
import java.util.Set;

@Getter
@Setter
@Table(name = "permissions", schema = "profile")
@Entity
@NoArgsConstructor
@AllArgsConstructor
public class Permission {

    @Id
    @SequenceGenerator(name = "permissions_seq", sequenceName = "permissions_seq", allocationSize = 1, schema = "profile")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "permissions_seq")
    private Long id;


    @Column(name = "name")
    private String name;

    @Column(name = "module")
    private String modulePermission;

    @Column(name = "operation")
    private String operationPermission;

    @Column(name = "point")
    private String pointPermission;

    @Column(name = "description")
    private String description;

    @CreationTimestamp
    @Column(name = "created_time", updatable = false)
    private LocalDateTime createdTime;

    @UpdateTimestamp
    @Column(name = "updated_time")
    private LocalDateTime updatedTime;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "updated_by")
    private String updatedBy;

    @Column(name = "side_type")
    @Enumerated(EnumType.STRING)
    private Types sideType;

    @ManyToMany(mappedBy = "rolePermissions")
    private Set<Role> permissionRoles;

    @ManyToMany(mappedBy = "userPermissions")
    private Set<User> permissionUsers;










}
