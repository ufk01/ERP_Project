package com.interline.logistics.authorization.entity.role;


import com.interline.logistics.authorization.entity.permission.Permission;
import com.interline.logistics.authorization.entity.user.User;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Getter
@Setter
@Table(name = "roles", schema = "profile")
@Entity
@NoArgsConstructor
@AllArgsConstructor
public class Role {

    @Id
    @SequenceGenerator(name = "roles_seq", sequenceName = "roles_seq", allocationSize = 1, schema = "profile")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "roles_seq")
    private Long id;

    @Column(name = "name")
    private String roleName;

    @Column(name = "description")
    private String description;

    @CreationTimestamp
    @Column(name = "created_time", updatable = false)
    private LocalDateTime createdTime;

    @UpdateTimestamp
    @Column(name = "updated_time")
    private LocalDateTime updatedTime;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "updated_by")
    private String updatedBy;

    @ManyToMany(fetch = FetchType.EAGER, cascade = {CascadeType.DETACH, CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH})
    @JoinTable(
            name = "rolePermissions",
            schema = "profile",
            joinColumns = @JoinColumn(name = "role_id"),
            inverseJoinColumns = @JoinColumn(name = "permission_id")
    )
    private Set<Permission> rolePermissions = new HashSet<>();

    @ManyToMany(mappedBy = "userRoles")
    private Set<User> roleUsers = new HashSet<>();
}
