package com.interline.logistics.authorization.entity.userDetail;

import lombok.*;

import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserLoginDto implements Serializable {

    private String username;
    private String password;
}
