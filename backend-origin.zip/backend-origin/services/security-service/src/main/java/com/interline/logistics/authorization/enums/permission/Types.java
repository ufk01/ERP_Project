package com.interline.logistics.authorization.enums.permission;


public enum Types {
    FRONTEND,
    BACKEND;


}


