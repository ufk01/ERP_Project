package com.interline.logistics.authorization.mapper.permission;

import com.interline.logistics.authorization.model.permission.PermissionDto;

import com.interline.logistics.authorization.entity.permission.Permission;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;
import java.util.Set;

@Mapper
public interface PermissionMapper {

    PermissionMapper permissionMapper = Mappers.getMapper(PermissionMapper.class);

    PermissionDto permissionToPermissionDto(Permission permission);
    Permission permissionDtoToPermission(PermissionDto permissionDto);
    Set<Permission> permissionSetDtoToPermissionSet(Set<PermissionDto> permissionDtoList);
    Set<PermissionDto> permissionSetToPermissionDtoSet(Set<Permission> permissionSet);
    List<PermissionDto> permissionListToPermissionPaginationDtoList(List<Permission> permissionList);
}
