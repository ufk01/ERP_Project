package com.interline.logistics.authorization.mapper.role;

import com.interline.logistics.authorization.entity.role.Role;
import com.interline.logistics.authorization.model.role.RoleDto;
import com.interline.logistics.authorization.model.role.RolePaginationDto;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;
import java.util.Set;

@Mapper
public interface RoleMapper {

     RoleMapper roleMapper = Mappers.getMapper(RoleMapper.class);

    Role roleDtoToRole(RoleDto roleDto);
    RoleDto roleToRoleDto(Role role);
    Set<Role> roleDtoSetToRoleSet(Set<RoleDto> roleDtoSet);
    Set<RoleDto> roleSetToRoleDtoSet(Set<Role> roleSet);
    List<RolePaginationDto> roleListToPaginationDtoList(List<Role> roleList);

}
