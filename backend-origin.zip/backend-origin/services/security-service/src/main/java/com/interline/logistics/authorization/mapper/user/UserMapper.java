package com.interline.logistics.authorization.mapper.user;

import com.interline.logistics.authorization.entity.user.User;
import com.interline.logistics.authorization.model.user.UserDto;
import com.interline.logistics.authorization.model.user.UserPaginationDto;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;
import java.util.Set;

@Mapper
public interface UserMapper {

    UserMapper userMapper = Mappers.getMapper(UserMapper.class);

    User userDtoToUser(UserDto userDto);
    UserDto userToUserDto(User user);
    Set<User> userDtoSetToUserSet(Set<UserDto> userDtoSet);
    Set<UserDto> userSetToUserDtoSet(Set<User> userSet);
    List<UserPaginationDto> userListToUserPaginationDtoList(List<User> userList);

}
