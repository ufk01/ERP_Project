package com.interline.logistics.authorization.model.permission;

import com.interline.logistics.authorization.enums.permission.Types;
import lombok.*;


@Getter
@Setter
public class PermissionDto {
    private Long id;
    private String name;
    private String modulePermission;
    private String operationPermission;
    private String pointPermission;
    private String description;
    private Types sideType;
}
