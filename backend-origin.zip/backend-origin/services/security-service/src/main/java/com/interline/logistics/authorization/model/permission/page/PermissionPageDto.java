package com.interline.logistics.authorization.model.permission.page;

import com.interline.logistics.authorization.model.permission.PermissionDto;
import com.interline.logistics.library.common.page.BasePaginationResponseDto;
import lombok.*;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@Getter
@Setter
public class PermissionPageDto extends BasePaginationResponseDto<PermissionDto> {}
