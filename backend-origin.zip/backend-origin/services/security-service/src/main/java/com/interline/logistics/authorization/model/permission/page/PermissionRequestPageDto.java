package com.interline.logistics.authorization.model.permission.page;

import com.interline.logistics.authorization.enums.permission.Types;
import com.interline.logistics.library.common.page.BasePaginationRequestDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PermissionRequestPageDto extends BasePaginationRequestDto {

    private String name;
    private String description;
    private String modulePermission;
    private String operationPermission;
    private String pointPermission;
    private Types sideType;


}
