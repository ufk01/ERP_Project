package com.interline.logistics.authorization.model.role;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class RolePaginationDto {

    private Long id;
    private String roleName;
    private String description;
}
