package com.interline.logistics.authorization.model.role.page;

import com.interline.logistics.authorization.model.role.RolePaginationDto;
import com.interline.logistics.library.common.page.BasePaginationResponseDto;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@Getter
@Setter
public class RolePageDto extends BasePaginationResponseDto<RolePaginationDto> {}
