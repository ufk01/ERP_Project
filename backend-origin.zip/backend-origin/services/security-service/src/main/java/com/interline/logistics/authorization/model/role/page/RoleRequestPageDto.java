package com.interline.logistics.authorization.model.role.page;

import com.interline.logistics.library.common.page.BasePaginationRequestDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RoleRequestPageDto extends BasePaginationRequestDto {

    private String roleName;
    private String description;
}
