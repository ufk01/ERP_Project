package com.interline.logistics.authorization.model.user;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserDto {

    private Long id;
    private String name;
    private String surname;
    private String username;
    private String password;
    private String email;
    private LocalDateTime lastLogin;
    private List<String> rolesName;
    private List<String> permissionsName;

}
