package com.interline.logistics.authorization.model.user;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class UserPaginationDto {

    private Long id;
    private String name;
    private String username;
    private String surname;
    private String email;
    private String lastLogin;
}
