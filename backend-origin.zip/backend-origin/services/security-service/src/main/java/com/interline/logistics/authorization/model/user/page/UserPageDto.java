package com.interline.logistics.authorization.model.user.page;

import com.interline.logistics.authorization.model.user.UserPaginationDto;
import com.interline.logistics.library.common.page.BasePaginationResponseDto;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@Getter
@Setter
public class UserPageDto extends BasePaginationResponseDto<UserPaginationDto> {
}
