package com.interline.logistics.authorization.model.user.page;

import com.interline.logistics.library.common.page.BasePaginationRequestDto;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserRequestPageDto extends BasePaginationRequestDto {

    private String name;
    private String surname;
    private String email;
    private String username;
}
