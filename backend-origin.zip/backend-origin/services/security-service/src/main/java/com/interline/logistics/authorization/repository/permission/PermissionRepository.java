package com.interline.logistics.authorization.repository.permission;

import com.interline.logistics.authorization.entity.permission.Permission;
import com.interline.logistics.authorization.enums.permission.Types;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.Set;

@Repository
public interface PermissionRepository extends JpaRepository<Permission, Long> {

    @Query("""
        select p
        from Permission as p
        where (p.name like concat('%', :name, '%') or :name is null or :name = '')and
              (p.description like concat('%', :description, '%') or :description is null or :description = '')and
              (p.modulePermission like concat('%', :modulePermission, '%') or :modulePermission is null or :modulePermission = '')and
              (p.pointPermission like concat('%', :pointPermission, '%') or :pointPermission is null or :pointPermission = '') and
              (p.operationPermission like concat('%', :operationPermission, '%') or :operationPermission is null or :operationPermission = '')and
              (p.sideType = :sideType or :sideType is null)
        """)
    Page<Permission> findPermissionPagination(@Param("name") String name,
                                              @Param("description") String description,
                                              @Param("modulePermission") String modulePermission,
                                              @Param("pointPermission") String pointPermission,
                                              @Param("operationPermission") String operationPermission,
                                              @Param("sideType") Types sideType,
                                              Pageable pageable);

    Optional<Permission> findByModulePermissionAndPointPermissionAndOperationPermissionAndSideType(String modulePermission,String pointPermission, String operationPermission, Types sideType);

    @Query("""
            select p.id
            from Permission as p
            where (p.name = :name)and
                  (p.modulePermission = :modulePermission)and
                  (p.pointPermission = :pointPermission)and
                  (p.operationPermission = :operationPermission)
            """)
    Optional<Long> getFormIdByNameAndPermissions(@Param("name") String name,
                                                 @Param("modulePermission") String modulePermission,
                                                 @Param("pointPermission") String pointPermission,
                                                 @Param("operationPermission") String operationPermission);


    Optional<Permission> findByNameAndId(String name, Long id);

    @Query("""
           select p
           from Permission as p
           where (p.name = trim(:name))
        """)
    Optional<Permission> findByPermissionWithPermissionName(String name);


    @Query("""
         select p.name
         from Permission as p
         where(p.name is not null)
         """)
    Optional<Set<String>> getPermissionNames();





}
