package com.interline.logistics.authorization.repository.role;

import com.interline.logistics.authorization.entity.role.Role;
import com.interline.logistics.authorization.model.role.RoleDto;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.Set;

@Repository
public interface RoleRepository extends JpaRepository<Role, Long> {

    @Query("""
            select r
            from Role as r
            inner join r.rolePermissions as rp
            where rp.id = :permissionId
            """)
    Optional<Set<Role>> findRolesByPermissionId(@Param("permissionId") Long permissionId);

    @Query("""
        select r
        from Role as r
        where (r.roleName like concat('%', :roleName, '%') or :roleName is null or :roleName = '') and
              (r.description like concat('%', :description, '%') or :description is null or :description = '')
        """)
    Page<Role> findRolePagination(@Param(value = "roleName") String roleName,
                                  @Param(value = "description") String description,
                                  Pageable pageable);


    Optional<Role> findByRoleName(String roleName);


    @Query("""
            select r.roleName
            from Role as r
            where (r.roleName is not null)
            """)
    Optional<Set<String>> getRolesName();

}
