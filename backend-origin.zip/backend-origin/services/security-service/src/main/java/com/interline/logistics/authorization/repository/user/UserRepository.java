package com.interline.logistics.authorization.repository.user;

import com.interline.logistics.authorization.entity.user.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.Set;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    @Query("""
        select u
        from User as u
        inner join u.userRoles as ur
        where ur.id = :roleId
""")
    Optional<Set<User>> findUsersByRoleId(@Param("roleId") Long roleId);

    @Query("""
        select u
        from User as u
        inner join u.userPermissions as up
        where up.id = :permissionId
    """)
    Optional<Set<User>> findUsersByPermissionId(@Param("permissionId") Long permissionId);


    @Query("""
        select u
        from User as u
        where (u.name like concat('%', :name, '%') or :name is null or :name = '') and
              (u.username like concat('%', :username, '%') or :username is null or :username = '') and
              (u.surname like concat('%', :surname, '%') or :surname is null or :surname = '') and
              (u.email like concat('%', :email, '%') or :email is null or :email = '')
    """)
    Page<User> getUserPagination(@Param("name") String name,
                                 @Param("username") String username,
                                 @Param("surname") String surname,
                                 @Param("email") String email,
                                 Pageable pageable);



    Optional<User> findByUsername(@Param("username") String username);

    Optional<User> findByNameAndEmail(String name, String email);

    Optional<User> findByNameAndId(String name, Long id);

    @Query("""
        select u.status
        from User as u
        where (u.username = trim(:username) and u.username is not null)
""")
    Optional<Boolean>findUsersStatusByUsername(@Param("username") String username);


    @Query("""
         select u
         from User as u
         where(u.username = :username)and
              (u.email = :email)
    """)
    Optional<User> findIdByUsernameAndEmail(@Param("username") String username,
                                            @Param("email") String email);


}
