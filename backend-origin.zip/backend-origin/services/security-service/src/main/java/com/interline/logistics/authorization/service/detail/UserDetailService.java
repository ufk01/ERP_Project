package com.interline.logistics.authorization.service.detail;

import jakarta.servlet.http.HttpServletRequest;
import org.jetbrains.annotations.NotNull;
import org.springframework.http.ResponseEntity;

import java.util.HashMap;


public interface UserDetailService {

    ResponseEntity<HashMap<String, String>> login(String username, String password, String secretKey, Long expirationTime);
    void logout(@NotNull HttpServletRequest httpServletRequest) throws Exception;
    Boolean checkUserPermissions(String username, String module, String point, String operation);
}
