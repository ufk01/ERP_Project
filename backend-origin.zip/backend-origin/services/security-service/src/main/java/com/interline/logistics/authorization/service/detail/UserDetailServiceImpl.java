package com.interline.logistics.authorization.service.detail;

import com.interline.logistics.authorization.entity.permission.Permission;
import com.interline.logistics.authorization.entity.user.User;
import com.interline.logistics.authorization.enums.permission.Types;
import com.interline.logistics.authorization.repository.user.UserRepository;
import com.interline.logistics.library.common.enums.JBusinessError;
import com.interline.logistics.library.jwt.enums.TokenInfo;
import com.interline.logistics.library.jwt.service.JwtAuthenticationService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.transaction.Transactional;
import org.jetbrains.annotations.NotNull;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class UserDetailServiceImpl implements UserDetailService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtAuthenticationService jwtAuthenticationService;


    public UserDetailServiceImpl(UserRepository userRepository, JwtAuthenticationService jwtAuthenticationService) {
        this.userRepository = userRepository;
        this.jwtAuthenticationService = jwtAuthenticationService;
        this.passwordEncoder = new BCryptPasswordEncoder();
    }

    @Override
    @Transactional
    public ResponseEntity<HashMap<String, String>> login(String username, String password, String secretKey, Long expirationTime) {
        final AtomicReference<String> atomicReference = new AtomicReference<>();
        final Optional<User> optionalUser = userRepository.findByUsername(username);
        if(optionalUser.isPresent()) {
            final User user = optionalUser.get();
            if (passwordEncoder.matches(password, user.getPassword())) {
                Set<Permission> frontendPermissions = Stream.concat(
                                user.getUserRoles().stream()
                                        .flatMap(role -> role.getRolePermissions().stream()),
                                user.getUserPermissions().stream()
                        )
                        .filter(permission -> permission.getSideType().equals(Types.FRONTEND))
                        .collect(Collectors.toSet());
                if(!frontendPermissions.isEmpty()){
               String frontendUrls = frontendPermissions.stream()
                        .map(permission -> {
                            return permission.getModulePermission()
                                    .concat(".")
                                    .concat(permission.getPointPermission())
                                    .concat(".")
                                    .concat(permission.getOperationPermission());
                        })
                       .collect(Collectors.joining(","));
               atomicReference.set(frontendUrls);
               }
               final String generatedToken  = jwtAuthenticationService.generateToken(
                       Objects.requireNonNull(user.getUsername()),
                       Objects.requireNonNull(user.getName()),
                       Objects.requireNonNull(user.getSurname()),
                       Objects.requireNonNull(user.getEmail()),
                       secretKey,
                       expirationTime
               );
                user.setStatus(true);
                user.setLastLogin(LocalDateTime.now());
                userRepository.save(user);
                return ResponseEntity
                        .status(HttpStatus.OK)
                        .body(new HashMap<String, String>() {{
                            put(TokenInfo.HEADER.getName(), generatedToken);
                            put(TokenInfo.FRONTEND_PERMISSION.getName(), atomicReference.get());
                            put(TokenInfo.REMAINDER_TOKEN_EXP.getName(), calcRemainingTime(expirationTime).toString());
                        }});
            }
            return ResponseEntity.status(JBusinessError.INVALID_USERNAME_AND_PASSWORD.getErrorCode()).build();
        }
        return ResponseEntity.status(JBusinessError.LOGIN_DENIED.getErrorCode()).build();
    }

    @Override
    @Transactional
    public void logout(@NotNull HttpServletRequest httpServletRequest) throws Exception {
        final String username = httpServletRequest.getHeader(TokenInfo.USERNAME.getName());
        final Optional<User> optionalUser = userRepository.findByUsername(username);
        if(optionalUser.isPresent()){
            final User user = optionalUser.get();
            user.setStatus(false);
            userRepository.save(user);
            return;
        }
        throw new Exception(JBusinessError.UNEXPECTED_ERROR.getErrorCode() + " " + JBusinessError.UNEXPECTED_ERROR.getErrorMessage());
    }

    @Override
    public Boolean checkUserPermissions(String username, String module, String point, String operation) {
        final Optional<User> optionalUserByUsername = userRepository.findByUsername(username);
        if (optionalUserByUsername.isPresent()) {
            User user = optionalUserByUsername.get();
            boolean hasRolePermission = user.getUserRoles().stream()
                    .flatMap(role -> role.getRolePermissions().stream())
                    .anyMatch(permission -> hasPermission(permission, module, point, operation, Types.BACKEND));
            if (!hasRolePermission) {
                return user.getUserPermissions().stream()
                        .anyMatch(permission -> hasPermission(permission, module, point, operation, Types.BACKEND));
            }
            return true;
        }
        return false;
    }


    private boolean hasPermission(Permission permission, String module, String point, String operation, Types type) {
        return permission.getModulePermission().equals(module) &&
                permission.getOperationPermission().equals(operation) &&
                permission.getPointPermission().equals(point) &&
                permission.getSideType().equals(type);
    }

    private LocalDateTime calcRemainingTime(Long expirationTime){
        final LocalDateTime now = LocalDateTime.now();
        final Duration duration = Duration.ofMillis(expirationTime);
        return now.plus(duration);

    }


}
