package com.interline.logistics.authorization.service.permission;

import com.interline.logistics.authorization.model.permission.PermissionDto;
import com.interline.logistics.authorization.model.permission.page.PermissionPageDto;
import com.interline.logistics.authorization.model.permission.page.PermissionRequestPageDto;
import jakarta.servlet.http.HttpServletRequest;

import java.util.Set;

public interface PermissionService {

    PermissionDto savePermission(HttpServletRequest httpServletRequest, PermissionDto permissionDto) throws Exception;
    void deletePermission(Long id) throws Exception;
    PermissionDto updatePermission(HttpServletRequest httpServletRequest,PermissionDto permissionDto) throws Exception;
    PermissionPageDto getPermissionsPage(PermissionRequestPageDto permissionRequestPageDto);
    PermissionDto getPermission(Long id) throws Exception;
    Set<String> getAllPermissions() throws Exception;
    Long findPermissionId(String name, String modulePermission, String pointPermission, String operationPermission) throws Exception;


}
