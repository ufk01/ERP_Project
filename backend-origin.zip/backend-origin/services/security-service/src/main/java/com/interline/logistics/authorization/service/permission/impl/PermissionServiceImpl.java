package com.interline.logistics.authorization.service.permission.impl;

import com.interline.logistics.authorization.mapper.permission.PermissionMapper;
import com.interline.logistics.authorization.model.permission.PermissionDto;
import com.interline.logistics.authorization.model.permission.page.PermissionPageDto;
import com.interline.logistics.authorization.model.permission.page.PermissionRequestPageDto;
import com.interline.logistics.authorization.service.permission.PermissionService;
import com.interline.logistics.authorization.service.role.RoleService;
import com.interline.logistics.authorization.service.user.UserService;
import com.interline.logistics.library.common.enums.JBusinessError;
import com.interline.logistics.authorization.entity.permission.Permission;
import com.interline.logistics.authorization.repository.permission.PermissionRepository;
import com.interline.logistics.library.jwt.enums.TokenInfo;
import jakarta.servlet.http.HttpServletRequest;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;
import java.util.Set;

@Service
public class PermissionServiceImpl implements PermissionService {
    private static PermissionMapper permissionMapper;
    private final PermissionRepository permissionRepository;
    private final RoleService roleService;
    private final UserService userService;


    public PermissionServiceImpl(PermissionRepository permissionRepository, RoleService roleService, UserService userService) {
        this.permissionRepository = permissionRepository;
        this.roleService = roleService;
        this.userService = userService;
        permissionMapper = PermissionMapper.permissionMapper;
    }

    @Override
    @Transactional
    public PermissionDto savePermission(@NotNull HttpServletRequest httpServletRequest, PermissionDto permissionDto) throws Exception {
        if(!checkEmpty(permissionDto)) {
            final Permission permission = permissionMapper.permissionDtoToPermission(permissionDto);
            Optional<Permission> optionalPermission = permissionRepository.findByModulePermissionAndPointPermissionAndOperationPermissionAndSideType(
                    permission.getModulePermission(),
                    permission.getPointPermission(),
                    permission.getOperationPermission(),
                    permission.getSideType()
            );
            if(optionalPermission.isEmpty()) {
                final String username = httpServletRequest.getHeader(TokenInfo.USERNAME.getName());
                permission.setCreatedBy(username);
                permission.setUpdatedBy(username);
                permission.setCreatedTime(LocalDateTime.now());
                permission.setUpdatedTime(LocalDateTime.now());
                Permission permissionSaved = permissionRepository.save(permission);
                return permissionMapper.permissionToPermissionDto(permissionSaved);
            }
            throw new Exception(JBusinessError.DATA_SAVED_ALREADY.toString());
        }
        throw new Exception(JBusinessError.EMPTY_DATA_FOUND.toString());
    }

    @Override
    @Transactional
    public void deletePermission(Long id) throws Exception{
        Optional<Permission> optionalPermission = permissionRepository.findById(id);
        if(optionalPermission.isPresent()){
            final Permission permission = optionalPermission.get();
            userService.deletePermissionsFromUser(permission.getId());
            roleService.deletePermissionsFromRole(id);
            permissionRepository.delete(permission);
            return;
        }
        throw new Exception(JBusinessError.DATA_NOT_FOUND.toString());
    }

    @Override
    @Transactional
    public PermissionDto updatePermission(@NotNull HttpServletRequest httpServletRequest, PermissionDto permissionDto) throws Exception {
        if(!checkEmpty(permissionDto)) {
            final Permission permission = permissionMapper.permissionDtoToPermission(permissionDto);
            Optional<Permission> optionalPermission = permissionRepository.findById(permission.getId());
            if(optionalPermission.isPresent()){
                Permission existPermission = optionalPermission.get();
                BeanUtils.copyProperties(permission, existPermission,  "createdBy", "createdTime", "id");
                final String username = httpServletRequest.getHeader(TokenInfo.USERNAME.getName());
                existPermission.setUpdatedBy(username);
                existPermission.setUpdatedTime(LocalDateTime.now());
                permissionRepository.save(existPermission);
                return permissionMapper.permissionToPermissionDto(existPermission);
            }
            throw new Exception(JBusinessError.DATA_NOT_FOUND.toString());
        }
       throw new Exception(JBusinessError.EMPTY_DATA_FOUND.toString());
    }

    @Override
    public PermissionPageDto getPermissionsPage(PermissionRequestPageDto permissionRequestPageDto) {
        Page<Permission> permissionPage = permissionRepository.findPermissionPagination(
                permissionRequestPageDto.getName(),
                permissionRequestPageDto.getDescription(),
                permissionRequestPageDto.getModulePermission(),
                permissionRequestPageDto.getPointPermission(),
                permissionRequestPageDto.getOperationPermission(),
                permissionRequestPageDto.getSideType(),
                PageRequest.of(permissionRequestPageDto.getPageNumber(), permissionRequestPageDto.getPageSize(), Sort.by(Sort.Order.desc("createdTime")))
        );
        return PermissionPageDto.builder()
                .content(permissionMapper.permissionListToPermissionPaginationDtoList(permissionPage.getContent()))
                .totalPages(permissionPage.getTotalPages())
                .totalElements(permissionPage.getTotalElements())
                .build();

    }

    @Override
    public PermissionDto getPermission(Long id) throws Exception {
        Optional<Permission> optionalPermission = permissionRepository.findById(id);
        if(optionalPermission.isPresent()){
            return permissionMapper.permissionToPermissionDto(optionalPermission.get());
        }
        throw new Exception(JBusinessError.DATA_NOT_FOUND.toString());
    }

    @Override
    public Set<String> getAllPermissions() throws Exception {
        return permissionRepository.getPermissionNames().orElseThrow(() ->
                new Exception(JBusinessError.NO_EXIST_PERMISSION.getErrorCode() + " " + JBusinessError.NO_EXIST_PERMISSION.getErrorMessage()));
    }

    @Override
    public Long findPermissionId(String name, String moduleOperation, String pointPermission, String operationPermission) throws Exception {
        Optional<Long> optionalPermissionId = permissionRepository.getFormIdByNameAndPermissions(
                name,
                moduleOperation,
                pointPermission,
                operationPermission
        );
        return optionalPermissionId.orElseThrow(() ->
                new Exception(JBusinessError.INVALID_PERMISSION_CHECK.getErrorCode() + " " + JBusinessError.INVALID_PERMISSION_CHECK.getErrorMessage()));
    }

    private Boolean checkEmpty(PermissionDto permissionDto) {
        return permissionDto.getModulePermission() == null ||
                permissionDto.getOperationPermission() == null ||
                permissionDto.getPointPermission() == null ||
                permissionDto.getSideType() == null;
    }


}
