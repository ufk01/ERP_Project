package com.interline.logistics.authorization.service.role;

import com.interline.logistics.authorization.model.role.RoleDto;
import com.interline.logistics.authorization.model.role.page.RolePageDto;
import com.interline.logistics.authorization.model.role.page.RoleRequestPageDto;
import jakarta.servlet.http.HttpServletRequest;
import org.jetbrains.annotations.NotNull;

import java.util.Set;

public interface RoleService {

    void deletePermissionsFromRole(Long permissionId) throws Exception;
    RoleDto saveRole(@NotNull HttpServletRequest httpServletRequest, RoleDto roleDto) throws Exception;
    RoleDto updateRole(@NotNull HttpServletRequest httpServletRequest,RoleDto roleDto) throws Exception;
    void deleteRole(Long roleId) throws Exception;
    RoleDto getRole(Long roleId) throws Exception;
    Set<RoleDto> getAllRoles() throws Exception;
    RolePageDto getRolePagination(RoleRequestPageDto roleRequestPageDto);
    RoleDto getRoleByUsername(String roleName) throws Exception;
    Set<String> getRolesName() throws Exception;

}
