package com.interline.logistics.authorization.service.role.impl;

import com.interline.logistics.authorization.entity.permission.Permission;
import com.interline.logistics.authorization.entity.role.Role;
import com.interline.logistics.authorization.mapper.role.RoleMapper;
import com.interline.logistics.authorization.model.role.RoleDto;
import com.interline.logistics.authorization.model.role.page.RolePageDto;
import com.interline.logistics.authorization.model.role.page.RoleRequestPageDto;
import com.interline.logistics.authorization.repository.permission.PermissionRepository;
import com.interline.logistics.authorization.repository.role.RoleRepository;
import com.interline.logistics.authorization.service.role.RoleService;
import com.interline.logistics.authorization.service.user.UserService;
import com.interline.logistics.library.common.enums.JBusinessError;
import com.interline.logistics.library.jwt.enums.TokenInfo;
import jakarta.servlet.http.HttpServletRequest;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import java.util.*;
import java.util.stream.Collectors;

@Service
public class RoleServiceImpl implements RoleService {

    final RoleRepository roleRepository;
    final PermissionRepository permissionRepository;
    final RoleMapper roleMapper;
    final UserService userService;

    public RoleServiceImpl(RoleRepository roleRepository, PermissionRepository permissionRepository, UserService userService) {
        this.roleRepository = roleRepository;
        this.permissionRepository = permissionRepository;
        this.roleMapper = RoleMapper.roleMapper;
        this.userService = userService;
    }

    @Override
    @Transactional
    public void deletePermissionsFromRole(Long permissionId){
        Optional<Set<Role>> getOptionalRolesByPermissionId = roleRepository.findRolesByPermissionId(permissionId);
        if (getOptionalRolesByPermissionId.isPresent()) {
            Set<Role> roles = getOptionalRolesByPermissionId.get();
            for (Role role : roles) {
                role.getRolePermissions().removeIf(rolePermission -> rolePermission.getId().equals(permissionId));
                roleRepository.save(role);
            }
        }
    }


    @Override
    @Transactional
    public RoleDto saveRole(@NotNull HttpServletRequest httpServletRequest, RoleDto roleDto) throws Exception {
       if(!checkEmpty(roleDto)){
           final Role role = roleMapper.roleDtoToRole(roleDto);
           Optional<Role> optionalRole = roleRepository.findByRoleName(role.getRoleName());
           if(optionalRole.isEmpty()){
               final String username = httpServletRequest.getHeader(TokenInfo.USERNAME.getName());
               role.setCreatedBy(username);
               role.setUpdatedBy(username);
                   if(role.getRolePermissions().isEmpty()){
                       role.setRolePermissions(new HashSet<>());
                   }
                   HashSet<Permission> permissions = new HashSet<>();
                   HashSet<String> permissionNames = new HashSet<>();
                   for(String permissionName : roleDto.getPermissionName()){
                       Optional<Permission> permissionOptional = permissionRepository.findByPermissionWithPermissionName(permissionName);
                       permissionOptional.ifPresent(permissions::add);
                       permissionNames.add(permissionName);
                   }
               role.setRolePermissions(permissions);
               final Role roleSaved = roleRepository.save(role);
               final RoleDto finalRoleDto = roleMapper.roleToRoleDto(roleSaved);
               finalRoleDto.setPermissionName(new ArrayList<>(permissionNames));
               return finalRoleDto;
           }
           throw new Exception(JBusinessError.DATA_SAVED_ALREADY.toString());
       }
        throw new Exception(JBusinessError.DATA_NOT_FOUND.toString());
    }

    @Override
    @Transactional
    public RoleDto updateRole(@NotNull HttpServletRequest httpServletRequest,RoleDto roleDto) throws Exception {
        if(!checkEmpty(roleDto)){
            Role role = roleMapper.roleDtoToRole(roleDto);
            Optional<Role> roleOptional = roleRepository.findById(role.getId());
            if(roleOptional.isPresent()){
                final String username = httpServletRequest.getHeader(TokenInfo.USERNAME.getName());
                Role existRole = roleOptional.get();
                BeanUtils.copyProperties(role, existRole, "createdBy", "createdTime", "id");
                existRole.setUpdatedBy(username);
                if(existRole.getRolePermissions().isEmpty()){
                    existRole.setRolePermissions(new HashSet<>());
                }
                HashSet<Permission> permissions = new HashSet<>();
                HashSet<String> permissionNames = new HashSet<>();
                for(String permissionName : roleDto.getPermissionName()){
                    Optional<Permission> permissionOptional = permissionRepository.findByPermissionWithPermissionName(permissionName);
                    permissionOptional.ifPresent(permissions::add);
                    permissionNames.add(permissionName);
                }
                existRole.setRolePermissions(permissions);
                final Role roleSaved = roleRepository.save(existRole);
                final RoleDto finalRoleDto = roleMapper.roleToRoleDto(roleSaved);
                finalRoleDto.setPermissionName(new ArrayList<>(permissionNames));
                return finalRoleDto;
            }
            throw new Exception(JBusinessError.DATA_NOT_FOUND.toString());
        }
        throw new Exception(JBusinessError.EMPTY_DATA_FOUND.toString());
    }

    @Override
    @Transactional
    public void deleteRole(Long roleId) throws Exception {
        Optional<Role> optionalRole = roleRepository.findById(roleId);
        if(optionalRole.isPresent()){
            Role existRole = optionalRole.get();
            userService.deleteRolesFromUser(roleId);
            existRole.setRolePermissions(null);
            roleRepository.delete(existRole);
            return;
        }
        throw new Exception(JBusinessError.DATA_NOT_FOUND.toString());
    }

    @Override
    public RolePageDto getRolePagination(RoleRequestPageDto roleRequestPageDto) {
        Page<Role> rolePage = roleRepository.findRolePagination(
                roleRequestPageDto.getRoleName(),
                roleRequestPageDto.getDescription(),
                PageRequest.of(roleRequestPageDto.getPageNumber(), roleRequestPageDto.getPageSize(), Sort.by(Sort.Order.desc("createdTime")))
        );
        return RolePageDto.builder()
                .content(roleMapper.roleListToPaginationDtoList(rolePage.getContent()))
                .totalPages(rolePage.getTotalPages())
                .totalElements(rolePage.getTotalElements())
                .build();
    }

    @Override
    public RoleDto getRoleByUsername(String username) throws Exception {
        Optional<Role> optionalRole = roleRepository.findByRoleName(username);
        if(optionalRole.isPresent()){
            final Role role = optionalRole.get();
            final RoleDto roleDto = roleMapper.roleToRoleDto(role);
            List<String> rolePermissionList = role.getRolePermissions().stream()
                    .map(permissionName -> Objects.requireNonNull(permissionName.getName()))
                    .collect(Collectors.toList());
            roleDto.setPermissionName(rolePermissionList);
            return roleDto;
        }
        throw new Exception(JBusinessError.INVALID_ROLE_CHECK.getErrorCode() + " " + JBusinessError.INVALID_ROLE_CHECK.getErrorMessage());
    }

    @Override
    public Set<String> getRolesName() throws Exception {
        return roleRepository.getRolesName().orElseThrow(() ->
                new Exception((JBusinessError.NO_EXIST_ROLE.getErrorCode() + " " + JBusinessError.NO_EXIST_ROLE.getErrorMessage())));
    }

    @Override
    public RoleDto getRole(Long roleId) throws Exception {
        Optional<Role> optionalRole = roleRepository.findById(roleId);
        if(optionalRole.isPresent()){
            final Role role = optionalRole.get();
            List<String> permissionName = role.getRolePermissions().stream()
                    .map(Permission::getName)
                    .toList();
            final RoleDto roleDto = roleMapper.roleToRoleDto(role);
            roleDto.setPermissionName(permissionName);
            return roleDto;
        }
        throw new Exception((JBusinessError.NO_EXIST_ROLE.getErrorCode() + " " + JBusinessError.NO_EXIST_ROLE.getErrorMessage()));
    }

    @Override
    public Set<RoleDto> getAllRoles() throws Exception {
        return roleMapper.roleSetToRoleDtoSet(new HashSet<>(roleRepository.findAll()));
    }

    private Boolean checkEmpty(RoleDto roleDto) {
        return roleDto.getRoleName() == null ||
                roleDto.getDescription() == null;
    }

}
