package com.interline.logistics.authorization.service.user;

import com.interline.logistics.authorization.model.user.UserDto;
import com.interline.logistics.authorization.model.user.page.UserPageDto;
import com.interline.logistics.authorization.model.user.page.UserRequestPageDto;
import jakarta.servlet.http.HttpServletRequest;
import org.jetbrains.annotations.NotNull;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.Set;

@Service
public interface UserService {

    UserDto save(@NotNull HttpServletRequest httpServletRequest, UserDto userDto) throws Exception;
    UserDto update(@NotNull HttpServletRequest httpServletRequest, UserDto userDto) throws Exception;
    void delete(Long userId) throws Exception;
    void deletePermissionsFromUser(Long permissionId) throws Exception;
    void deleteRolesFromUser(Long roleId);
    UserDto getUser(Long userId) throws Exception;
    Set<UserDto> getAllUsers();
    UserPageDto getUserPagination(UserRequestPageDto userRequestPageDto);
    UserDto getUserByUsernameAndEmail(String username, String eMail) throws Exception;


}
