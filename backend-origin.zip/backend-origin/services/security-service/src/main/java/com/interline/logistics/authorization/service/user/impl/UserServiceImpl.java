package com.interline.logistics.authorization.service.user.impl;

import com.interline.logistics.authorization.entity.permission.Permission;
import com.interline.logistics.authorization.entity.role.Role;
import com.interline.logistics.authorization.entity.user.User;
import com.interline.logistics.authorization.mapper.user.UserMapper;
import com.interline.logistics.authorization.model.role.RoleDto;
import com.interline.logistics.authorization.model.user.UserDto;
import com.interline.logistics.authorization.model.user.page.UserPageDto;
import com.interline.logistics.authorization.model.user.page.UserRequestPageDto;
import com.interline.logistics.authorization.repository.permission.PermissionRepository;
import com.interline.logistics.authorization.repository.role.RoleRepository;
import com.interline.logistics.authorization.repository.user.UserRepository;
import com.interline.logistics.authorization.service.user.UserService;
import com.interline.logistics.library.common.enums.JBusinessError;
import com.interline.logistics.library.jwt.enums.TokenInfo;
import jakarta.servlet.http.HttpServletRequest;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.*;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final UserMapper userMapper;
    private final RoleRepository roleRepository;
    private final PermissionRepository permissionRepository;
    private final BCryptPasswordEncoder bCryptPasswordEncoder;


    public UserServiceImpl(UserRepository userRepository, RoleRepository roleRepository, PermissionRepository permissionRepository) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.permissionRepository = permissionRepository;
        this.bCryptPasswordEncoder = new BCryptPasswordEncoder();
        this.userMapper = UserMapper.userMapper;
    }

    @Override
    @Transactional
    public UserDto save(@NotNull HttpServletRequest httpServletRequest, UserDto userDto) throws Exception {
        if(!checkEmpty(userDto)){
            final User user = userMapper.userDtoToUser(userDto);
            Optional<User> optionalUser = userRepository.findByNameAndEmail(userDto.getName(), user.getEmail());
            if(optionalUser.isEmpty()){
                final String username = httpServletRequest.getHeader(TokenInfo.USERNAME.getName());
                user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
                user.setCreatedBy(username);
                user.setUpdatedBy(username);
                user.setCreatedTime(LocalDateTime.now());
                user.setUpdatedTime(LocalDateTime.now());
                user.setStatus(false);
                if(user.getUserRoles().isEmpty()){
                    user.setUserRoles(new HashSet<>());
                }
                if(user.getUserPermissions().isEmpty()){
                    user.setUserPermissions(new HashSet<>());
                }
                HashSet<Role> roles = new HashSet<>();
                HashSet<String> roleNames = new HashSet<>();
                for(String roleName : userDto.getRolesName()){
                    Optional<Role> optionalRole = roleRepository.findByRoleName(roleName);
                    optionalRole.ifPresent(roles::add);
                    roleNames.add(roleName);
                }
                user.setUserRoles(roles);
                HashSet<Permission> permissions = new HashSet<>();
                HashSet<String> permissionNames = new HashSet<>();
                for(String permissionName : userDto.getPermissionsName()){
                    Optional<Permission> optionalPermission = permissionRepository.findByPermissionWithPermissionName(permissionName);
                    optionalPermission.ifPresent(permissions::add);
                    permissionNames.add(permissionName);
                }
                user.setUserPermissions(permissions);
                user.setStatus(false);
                final User userSaved = userRepository.save(user);
                final UserDto finalUserDto = userMapper.userToUserDto(userSaved);
                finalUserDto.setRolesName(new ArrayList<>(roleNames));
                finalUserDto.setPermissionsName(new ArrayList<>(permissionNames));
                return finalUserDto;
            }
            throw new Exception(JBusinessError.DATA_SAVED_ALREADY.toString());
        }
        throw new Exception(JBusinessError.EMPTY_DATA_FOUND.toString());
    }

    @Override
    @Transactional
    public UserDto update(@NotNull HttpServletRequest httpServletRequest, UserDto userDto) throws Exception {
        if(!checkEmpty(userDto)){
            User user = userMapper.userDtoToUser(userDto);
            Optional<User> userOptional = userRepository.findById(user.getId());
            if(userOptional.isPresent()){
                final String username = httpServletRequest.getHeader(TokenInfo.USERNAME.getName());
                User existUser = userOptional.get();
                BeanUtils.copyProperties(user, existUser, "createdBy", "createdTime", "id", "password");
                existUser.setUpdatedBy(username);
                existUser.setUpdatedTime(LocalDateTime.now());
                if(existUser.getUserRoles().isEmpty()){
                    existUser.setUserRoles(new HashSet<>());
                }
                HashSet<Role> roles = new HashSet<>();
                HashSet<String> roleNames = new HashSet<>();
                for(String roleName : userDto.getRolesName()){
                    Optional<Role> optionalRole = roleRepository.findByRoleName(roleName);
                    optionalRole.ifPresent(roles::add);
                    roleNames.add(roleName);
                }
                existUser.setUserRoles(roles);
                HashSet<Permission> permissions = new HashSet<>();
                HashSet<String> permissionNames = new HashSet<>();
                for(String permissionName : userDto.getPermissionsName()){
                    Optional<Permission> optionalPermission = permissionRepository.findByPermissionWithPermissionName(permissionName);
                    optionalPermission.ifPresent(permissions::add);
                    permissionNames.add(permissionName);
                }
                existUser.setUserPermissions(permissions);
                final UserDto finalUserDto = userMapper.userToUserDto(existUser);
                finalUserDto.setRolesName(new ArrayList<>(roleNames));
                finalUserDto.setPermissionsName(new ArrayList<>(permissionNames));
                return finalUserDto;

            }
            throw new Exception(JBusinessError.DATA_NOT_FOUND.toString());
        }
        throw new Exception(JBusinessError.EMPTY_DATA_FOUND.toString());
    }

    @Override
    @Transactional
    public void delete(Long userId) throws Exception {
        Optional<User> optionalUser = userRepository.findById(userId);
        if(optionalUser.isPresent()){
            User existUser = optionalUser.get();
            existUser.setUserRoles(null);
            existUser.setUserPermissions(null);
            userRepository.delete(existUser);
            return;
        }
        throw new Exception(JBusinessError.DATA_NOT_FOUND.toString());
    }

    @Override
    @Transactional
    public void deletePermissionsFromUser(Long permissionId){
        Optional<Set<User>> optionalUser = userRepository.findUsersByPermissionId(permissionId);
        if(optionalUser.isPresent()){
            Set<User> users = optionalUser.get();
            for(User user : users){
                user.getUserPermissions().removeIf(userPermission -> userPermission.getId().equals(permissionId));
                for (Role role : user.getUserRoles()) {
                    role.getRolePermissions().removeIf(rolePermission -> rolePermission.getId().equals(permissionId));
                }
            }
            userRepository.saveAll(users);
        }
    }

    @Override
    @Transactional
    public void deleteRolesFromUser(Long roleId) {
        Optional<Set<User>> optionalUser = userRepository.findUsersByRoleId(roleId);
        if(optionalUser.isPresent()){
            Set<User> users = optionalUser.get();
            for (User user : users) {
                user.getUserRoles().removeIf(role -> role.getId().equals(roleId));
            }
            userRepository.saveAll(users);
        }
    }

    @Override
    public UserDto getUser(Long userId) throws Exception {
        Optional<User> optionalUser = userRepository.findById(userId);
        if(optionalUser.isPresent()){
            final User user = optionalUser.get();
            List<String> roleNameList = user.getUserRoles().stream()
                    .map(Role::getRoleName)
                    .toList();
            List<String> permissionNameList = user.getUserPermissions().stream()
                    .map(Permission::getName)
                    .toList();
            final UserDto userDto = userMapper.userToUserDto(user);
            userDto.setRolesName(roleNameList);
            userDto.setPermissionsName(permissionNameList);
            return userDto;
        }
        throw new Exception(JBusinessError.INVALID_USER_CHECK.getErrorCode() + " " + JBusinessError.INVALID_USER_CHECK.getErrorMessage());
    }

    @Override
    public Set<UserDto> getAllUsers() {
        return userMapper.userSetToUserDtoSet(new HashSet<>(userRepository.findAll()));
    }

    @Override
    public UserPageDto getUserPagination(UserRequestPageDto userRequestPageDto) {
        Page<User> userPage = userRepository.getUserPagination(
                userRequestPageDto.getName(),
                userRequestPageDto.getUsername(),
                userRequestPageDto.getSurname(),
                userRequestPageDto.getEmail(),
                PageRequest.of(userRequestPageDto.getPageNumber(), userRequestPageDto.getPageSize(), Sort.by(Sort.Order.desc("lastLogin")))
        );
        return UserPageDto.builder()
                .content(userMapper.userListToUserPaginationDtoList(userPage.getContent()))
                .totalElements(userPage.getTotalElements())
                .totalPages(userPage.getTotalPages())
                .build();
    }

    @Override
    public UserDto getUserByUsernameAndEmail(String username, String eMail) throws Exception {
        Optional<User> optionalUser = userRepository.findIdByUsernameAndEmail(username, eMail);
        if(optionalUser.isPresent()){
            final User user = optionalUser.get();
            final UserDto userDto = userMapper.userToUserDto(user);
            List<String> roleNameList = user.getUserRoles().stream()
                    .map(Role::getRoleName)
                    .toList();
            List<String> permissionNameList = user.getUserPermissions().stream()
                    .map(Permission::getName)
                    .toList();
            userDto.setRolesName(roleNameList);
            userDto.setPermissionsName(permissionNameList);
            return userDto;
        }
        throw new Exception(JBusinessError.INVALID_USER_CHECK.getErrorCode() + " " + JBusinessError.INVALID_USER_CHECK.getErrorMessage());
    }


    private Boolean checkEmpty(UserDto userDto){
        return userDto.getUsername() == null ||
                userDto.getPassword() == null ||
                userDto.getEmail() == null ||
                userDto.getName() == null;
    }
}
