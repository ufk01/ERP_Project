INSERT INTO profile.role_permissions (role_id,permission_id) VALUES
	 (20,9),
	 (20,4),
	 (20,10),
	 (25,52),
	 (25,60),
	 (25,48),
	 (24,59),
	 (24,47),
	 (26,49),
	 (26,61);
INSERT INTO profile.role_permissions (role_id,permission_id) VALUES
	 (30,62),
	 (30,56),
	 (23,48),
	 (23,62),
	 (23,56),
	 (23,52),
	 (23,51),
	 (23,49),
	 (23,58),
	 (23,61);
INSERT INTO profile.role_permissions (role_id,permission_id) VALUES
	 (23,47),
	 (23,50),
	 (23,59),
	 (23,60),
	 (1,5),
	 (1,2),
	 (31,50),
	 (31,58),
	 (1,33),
	 (1,43);
INSERT INTO profile.role_permissions (role_id,permission_id) VALUES
	 (1,41),
	 (1,37),
	 (1,28),
	 (1,15),
	 (1,25),
	 (1,1),
	 (1,31),
	 (1,7),
	 (1,40),
	 (1,26);
INSERT INTO profile.role_permissions (role_id,permission_id) VALUES
	 (1,17),
	 (1,36),
	 (1,8),
	 (1,22),
	 (1,3),
	 (1,39),
	 (1,24),
	 (1,42),
	 (1,32),
	 (1,23);
INSERT INTO profile.role_permissions (role_id,permission_id) VALUES
	 (1,20),
	 (1,46),
	 (1,16),
	 (1,44),
	 (1,27),
	 (1,6),
	 (1,34),
	 (1,30),
	 (1,21),
	 (1,45);
INSERT INTO profile.role_permissions (role_id,permission_id) VALUES
	 (1,57),
	 (1,29),
	 (1,18),
	 (1,35);
