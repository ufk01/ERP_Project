INSERT INTO profile.roles (id,created_by,created_time,description,name,updated_by,updated_time) VALUES
	 (1,'ufk01','2024-10-23 10:52:32.041055','Sadece developerlar''ın kullanabileceği Admin Kontrol Paneli yetkilerini içeren rol','Admin Role','ufk01','2025-01-26 19:23:03.22098'),
	 (25,'ufk01','2024-12-15 18:45:04.88165','Deniz Modulü güncelleme yetkisini içerir.','Sea Module Update Role','ufk01','2025-02-04 22:55:40.974085'),
	 (24,'ufk01','2024-12-15 18:44:34.872076','Deniz modulü kaydetme yetkisini içerir.','Sea Module Save Role','ufk01','2025-02-04 23:02:32.335497'),
	 (26,'ufk01','2024-12-15 18:47:14.027756','Deniz Modulü silme yetkisi içerir.','Sea Module Delete Role','ufk01','2025-02-04 23:03:41.967032'),
	 (30,'ufk01','2025-01-26 19:25:58.674227','Frontend yetkileri arasında, Deniz Modülleri adı altındaki sayfalara erişim için gereken temel roller','Sea Module Default Role','ufk01','2025-02-04 23:04:04.342825'),
	 (23,'ufk01','2024-12-15 18:43:17.821851','Deniz Modulüne ait tüm yetkileri içerir.','Sea Module All Roles','ufk01','2025-02-04 23:04:14.166096'),
	 (31,'ufk01','2025-02-04 23:05:07.898064','Deniz Modulünü sadece görünteleme yetkilerini içerir.','Sea Module View Role','ufk01','2025-03-01 17:26:30.866068'),
	 (20,'ufk01','2024-11-23 11:46:44.188643','Bütün kullanıcıların sahip olması gereken yetkileri içeren rol','Default Role','ibo01','2024-11-23 23:31:57.789955');
