create sequence profile.permissions_seq start with 1 increment by 1;
create sequence profile.roles_seq start with 1 increment by 1;
create sequence profile.users_seq start with 1 increment by 1;
create sequence sea_module.sea_seq start with 1 increment by 1
