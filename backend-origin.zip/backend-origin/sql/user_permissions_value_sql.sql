INSERT INTO profile.user_permissions (user_id,permission_id) VALUES
	 (13,35),
	 (13,57),
	 (13,40),
	 (13,5),
	 (13,6);
