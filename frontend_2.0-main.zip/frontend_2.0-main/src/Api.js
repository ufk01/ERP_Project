import axios from 'axios';



const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL,
},{
    headers: {
      'Content-Type': 'application/json',
    },
    withCredentials: true,
});

api.interceptors.request.use((config) => {
    const token = localStorage.getItem("interline-token");
    if(token){
        config.headers.token = token;
    }
    return config;
});

api.interceptors.response.use(
  (response) => {
    return response;
  },
  (error) => {
    if (error.response) {
      sessionStorage.clear();
      localStorage.clear();
      window.location.href = "/login";
      alert("Beklenmedik bir durum ile karşılaşıldı. Lütfen yöneticiniz ile iletişime geçiniz.");
    }

    return Promise.reject(error);
  }
);

export default api;
