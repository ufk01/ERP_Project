

import React from 'react';

export const metadata = {
    title: 'LogiFlow',
    description: 'Logistic ERP System',
    icons: {
        icon: '/public/next.svg'
    }
};

export default function SimpleLayout({ children }) {
    return (
        
        <>
            {children}
        </>
    );
}
