/* eslint-disable @next/next/no-img-element */
'use client';
import { useRouter } from 'next/navigation';
import React, { useContext, useState } from 'react';
import { Button } from 'primereact/button';
import { Password } from 'primereact/password';
import { LayoutContext } from '../../../layout/context/LayoutContext';
import { InputText } from 'primereact/inputtext';
import { classNames } from 'primereact/utils';
import api from '../../../Api'
import { ProgressSpinner } from 'primereact/progressspinner';
import { Message } from 'primereact/message';
        
const LoginPage = () => {

    const router                    = useRouter();
    const { layoutConfig }          = useContext(LayoutContext);
    const [password, setPassword]   = useState('');
    const [username, setUsername]   = useState('');
    const[loading, setLoading] = useState(false);
    const [error, setError] = useState(false);
    const [onClicked, setOnClicked] = useState(false)


    const containerClassName = classNames('surface-ground flex align-items-center justify-content-center min-h-screen min-w-screen overflow-hidden', { 'p-input-filled': layoutConfig.inputStyle === 'filled' });

   
    const handleSubmit = async () => {
        setOnClicked(true);
        setLoading(true);
        if (!username || !password) {
            setError(true);
            setLoading(false);
            return;
        }
        setError(false);
        const data = {
            username: username,
            password: password,
        };
        
        try {
            const response = await api.post(
                process.env.NEXT_PUBLIC_LOGIN_PATH, data
            );
            localStorage.setItem("interline-token", response.data["token"]);
            localStorage.setItem("frontend-permissions", response.data["frontend-permission"]);
            localStorage.setItem("expiration-token", response.data["token-remainder-time"]);
            localStorage.setItem("isLogged", true);
            router.push('/dashboard');
        } catch (reason) {
            console.log(process.env);
            alert("reason => " + reason);
            setLoading(false);
        } finally {
            setOnClicked(false);
        }
    };

    
    return (
        <div className={containerClassName} style={{ 
            backgroundImage: 'url("/images/login_final.jpg")',
            backgroundSize: 'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition: 'center',
            height: '100vh'
            }}>
            <div className="flex flex-column align-items-center justify-content-center">
                <div
                    style={{
                        borderRadius: '55px',
                        padding: '0.5rem',
                    }}
                >
                    <div className="w-full surface-card py-6 px-5 sm:px-8" style={{ borderRadius: '53px', opacity: '0.91'}}>
                        <div className="text-center ">
                            <img src="/images/logo_transparent.png" alt="Image" height="350"         
                            style={{ marginBottom: '0', marginBottom: '-50px' }}
                            />
                        </div>

                        <div>
                            <label htmlFor="username" className="block text-900 text-lg font-medium mb-2">
                                Kullanıcı Adı     
                                {!username && onClicked &&(
                                <Message severity="error" 
                                text="Kullanıcı Adı Boş Bırakılamaz!"     
                                style={{ height: '22px', margin: '2px', paddingLeft: '10px'}} />
                                )}               
                            </label>
                            <InputText 
                                id="username" 
                                type="text" 
                                placeholder="Kullanıcı Adı" 
                                className="w-full md:w-30rem mb-5" style={{ padding: '1rem' }} 
                                value={username} 
                                onChange={(e) => setUsername(e.target.value)}
                            />
                            <label htmlFor="password" className="block text-900 font-medium text-lg mb-2">
                                Şifre    
                                {!password && onClicked &&(
                                <Message severity="error" 
                                text="Şifre Boş Bırakılamaz!"     
                                style={{ height: '22px', margin: '2px', paddingLeft: '10px'}} />
                                )}  
                            </label>
                            <Password 
                                inputId="password" 
                                value={password} 
                                onChange={(e) => setPassword(e.target.value)}
                                placeholder="Şifre" 
                                toggleMask
                                inputClassName="w-full p-3 md:w-30rem"
                                feedback={false}
                            />                     
                            <>
                                <div className="flex align-items-center justify-content-between mb-5 gap-5"></div>
                                <Button
                                    className="w-full p-3 text-xl flex align-items-center justify-content-center"
                                    onClick={handleSubmit}
                                    disabled={loading}
                                >
                                    {loading ? (
                                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                                            Giriş Yapılıyor...
                                            <ProgressSpinner 
                                                style={{ width: '24px', height: '24px', marginLeft: '10px' }} 
                                                strokeWidth="8"  
                                                
                                            />
                                        </div>
                                    ) : (
                                        "Giriş Yap"
                                    )}
                                </Button>
                            </>



                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default LoginPage;
