'use client'
import { InputText } from 'primereact/inputtext';
import React, { useContext, useEffect, useState, useRef } from 'react';
import { GlobalContext } from '../../../components/api_context/GlobalContext';
import { Panel } from 'primereact/panel';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import api from '../../../Api';
import { Button } from 'primereact/button';
import { Dropdown } from 'primereact/dropdown';
import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog';
import { Toast } from 'primereact/toast'; // Toast bildirimleri için
import { Dialog } from 'primereact/dialog';



const PermissionPage = () => {
    
    const toast = useRef(null);
    const { hasPermission, directToErrorPage} = useContext(GlobalContext);
    const [first, setFirst] = useState(0);
    const [rows, setRows] = useState(5);
    const [visibleDeletePopUp, setVisibleDeletePopUp] = useState(false);
    const [visibleSavePopUp, setVisibleSavePopUp] = useState(false);
    const [visibleUpdatePopUp, setVisibleUpdatePopUp] = useState(false);
    const [selectedRow, setSelectedRow] = useState(null);
    const [viewTable, setViewTable] = useState(false);
    const [responseData, setResponseData] = useState({ content: [], totalPages: null, totalElements: null });
    const [processStarted, setProcessStarted] = useState(false);
    const sideTypes = [
      { name: 'Frontend', value: 'FRONTEND'},
      { name: 'Backend', value: 'BACKEND'}
    ];
    const [query, setQuery] = useState({
        name: '',
        modulePermission:'',
        operationPermission: '',
        pointPermission: '',
        description: '',
        sideType: null,
        pageSize: rows,
        pageNumber: first
    });
    const [formData, setFormData] = useState({
        id: '',
        name:'',
        modulePermission: '',
        operationPermission: '',
        pointPermission: '',
        description: '',
        sideType: null
    });
    const authorizationList= {
        view: "admin.permission.view",
        update: "admin.permission.update",
        delete: "admin.permission.delete",
        save: "admin.permission.save"        
    };

    const accept = async (rowData) => {
      if(toast.current){
      deleteForm(rowData.id, rowData.name);
      setVisibleDeletePopUp(false);
      toast.current.show({ severity: 'success', summary: 'Başarıyla Silindi!', detail: rowData.name.toUpperCase() +  " Başarıyla silindi!", life: 3000});
      setSelectedRow(null);
      }
    }
    const reject = (rowData) => {
      if(toast.current){
        setVisibleDeletePopUp(false);
        toast.current.show({ severity: 'warn', summary: 'İptal Edildi', detail: rowData.name.toUpperCase() +  ' Silme işlemi iptal eildi!', life: 3000 });
        setSelectedRow(null); 
      }
    }
    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setQuery((prevQuery) => ({
          ...prevQuery,
          [name]: value === '' ? null : value, 
        }));
      };
      const handleFormChange = async (e) => {
        const { name, value } = e.target;
         setFormData((prevFormData) => ({
          ...prevFormData,
          [name]: value,
        }));
      };

    const handlePaginationChange = async (e) => {
        if (query.pageSize !== e.rows) {  
            query.pageSize = e.rows; 
            setRows(e.rows); 
        }
        if (query.pageNumber !== e.first / e.rows){
          query.pageNumber = e.first / e.rows;
          setFirst(e.first);
        }
        await getPagination();
    };
      
      function clearInputFields() {
        setQuery({
          name: '',
          modulePermission: '',
          operationPermission: '',
          pointPermission: '',
          description: '',
          sideType: null,
          pageSize: rows,  
          pageNumber: 0
        });
      };
      
    
      function paginationDataToFormData(id, name, module, point, operation, sideType, description){
        setFormData({
          id: id,
          name: name,
          modulePermission: module,
          pointPermission: point,
          operationPermission: operation,
          sideType: sideType,
          description: description
        })
      };
    
      const closeModal = () => {
        setVisibleSavePopUp(false);
        setVisibleUpdatePopUp(false);
        setFormData({
          id: '',
          name: '',
          modulePermission: '',
          operationPermission: '',
          pointPermission: '',
          description: '',
          sideType: null,
        });
        setSelectedRow(null);
      };
    
      const openUpdateModal = async (rowData) => {
          setSelectedRow(rowData);
          paginationDataToFormData(rowData.id, rowData.name, rowData.modulePermission, rowData.pointPermission, rowData.operationPermission, rowData.sideType, rowData.description);
          setVisibleUpdatePopUp(true);
      }
    
      
    
      async function getPagination(updatedQuery){
        setProcessStarted(true);
        await api 
          .post(process.env.NEXT_PUBLIC_PAGINATION_PATH, updatedQuery || query )
          .then((response) => {
            if (response.data.content.length !== 0) {
              setResponseData(response.data);
              setViewTable(true);
              setProcessStarted(false);
            } else {
              setViewTable(false); 
              setProcessStarted(false);
            }
          })
          .catch((reason) => {
            alert(reason);
          });
        };
    
        function submitForm(){
          api
            .post(process.env.NEXT_PUBLIC_PERMISSION_SAVE_PATH, formData)
            .then((response) => {
                closeModal();
                clearInputFields();
                getPagination();
              }).catch((reason) => {
                alert(reason);
              })
        };
    
        function updateForm(){
          api
            .put(process.env.NEXT_PUBLIC_PERMISSION_UPDATE_PATH, formData
            ).then((response) => {
              closeModal();
              clearInputFields();
              getPagination();
            }).catch((reason) => {
              alert(reason);
            })
        }
    
         function deleteForm(getId){
              api
              .delete(process.env.NEXT_PUBLIC_PERMISSION_DELETE_PATH
                .concat("/")
                .concat(getId)
              )
              .then((response) => {
                closeModal();
                clearInputFields();
                getPagination();           
              })
              .catch((reason) => {
                  alert(reason);
              });
           
        }
  
        useEffect(() => {
          if(!hasPermission(authorizationList.view)){
            directToErrorPage()
          }
          api
          .post(process.env.NEXT_PUBLIC_PAGINATION_PATH, {
            name: '',
            modulePermission: '',
            operationPermission: '', 
            pointPermission: '',
            description: '',
            sideType: null,
            pageSize: rows,
            pageNumber: first,
          })
          .then((response) => {
            if (response.data.content.length !== 0) {
              setResponseData(response.data);
              setViewTable(true);
            } else {
              setViewTable(false); 
            }
          })
          .catch((reason) => {
            alert(reason);
          });
        }, [authorizationList.view, directToErrorPage, hasPermission]);


    return (
        <>
          <Panel header="Yetki Kontrol Paneli" className="flex flex-column">
              <div className="card flex flex-column gap-3">
                  <div className="flex md:flex-row gap-3">
                      <div className="p-inputgroup flex-1">
                          <InputText 
                          value={query.name}
                          name="name" 
                          placeholder="Name"
                          onChange={handleInputChange} />
                      </div>
                      <div className="p-inputgroup flex-1">
                          <InputText
                          value={query.description}
                          name="description"
                          placeholder="Description"
                          onChange={handleInputChange} />
                      </div>
                      <div className="p-inputgroup flex-1">
                        <Dropdown 
                        value={query.sideType} 
                        name="sideType"
                        onChange={handleInputChange} 
                        options={sideTypes} optionLabel='name'
                        placeholder='Side Type' showClear />
                      </div>
                  </div>

                  <div className="flex md:flex-row gap-3">
                      <div className="p-inputgroup flex-1">
                          <InputText
                          value={query.modulePermission}
                          name="modulePermission"
                          onChange={handleInputChange}
                          placeholder="Module Permission" />
                      </div>
                      <div className="p-inputgroup flex-1">
                          <InputText 
                          value={query.pointPermission}
                          name="pointPermission"
                          onChange={handleInputChange}
                          placeholder="Point Permission" />
                      </div>
                      <div className="p-inputgroup flex-1">
                          <InputText
                          value={query.operationPermission}
                          name="operationPermission"
                          onChange={handleInputChange}
                          placeholder="Operation Permission" />
                      </div>
                  </div>
                  <div className="flex flex-wrap justify-content-end gap-3" >
                    <Button label="Temizle" severity='danger' disabled={processStarted} onClick={() => clearInputFields()} />
                    <Button label="Sorgula" severity='success' disabled={processStarted} onClick={() => getPagination()} /> 
                  </div>
              </div>
          </Panel>
          {viewTable && (
          <Panel className="flex flex-column" style={{ paddingTop: '15px'}}>
              <div className="card">
                  <DataTable lazy value={responseData.content} selection={selectedRow} paginator rows={rows} first={first} totalRecords={responseData.totalElements} rowsPerPageOptions={[5, 10, 25, 50]} 
                  tableStyle={{ minWidth: '20rem'}} showGridlines stripedRows  onPage={handlePaginationChange}  >
                      <Column field='name' header="Name" alignHeader='center' headerStyle={{ minWidth: '10rem'}}></Column>    
                      <Column field='description' header="Description" alignHeader='center' headerStyle={{ minWidth: '20rem'}} ></Column>    
                      <Column field='sideType' header="Side Type" headerStyle={{ minWidth: '7rem'}} alignHeader='center' className='text-center' ></Column>    
                      <Column field='modulePermission' header="Module Permission" headerStyle={{ minWidth: '12rem'}} className='text-center' alignHeader='center' ></Column>    
                      <Column field='pointPermission' header="Point Permission" headerStyle={{ minWidth: '10rem'}} className='text-center' alignHeader='center'></Column>    
                      <Column field='operationPermission' header="Operation Permission" headerStyle={{ minWidth: '13rem'}} className='text-center' alignHeader='center'></Column> 
                      {(hasPermission(authorizationList.save) || hasPermission(authorizationList.update) || hasPermission(authorizationList.delete)) && (   
                      <Column 
                          header={() => (
                            <>
                            {hasPermission(authorizationList.save) && (
                            <Button
                              icon="pi pi-plus"
                              onClick={() => {
                                setSelectedRow(selectedRow);
                                setVisibleSavePopUp(true)
                              }}
                              className="p-button-info"
                              />
                            )}
                            </>
                          )} 

                          body={(rowData) => (
                            <>
                            {hasPermission(authorizationList.update) && (
                              <div style={{ display: 'flex', paddingBottom: '3px'}}>
                                <Button 
                                      icon="pi pi-pencil" 
                                      onClick={() => openUpdateModal(rowData)} 
                                      className="p-button-secondary p-mr-2 "
                                  />
                              </div>
                              )}
                              {hasPermission(authorizationList.delete) && (
                              <div> 
                                <Button 
                                      icon="pi pi-trash" 
                                      onClick={() => {
                                        setSelectedRow(rowData);
                                        setVisibleDeletePopUp(true)
                                        }}
                                      className="p-button-contrast"
                                />      
                              </div>
                              )}
                            </>
                          )}
                      ></Column>
                    )}
            
                  </DataTable>     

                  {/* Delete Pop-up */}
                      <Toast ref={toast} />
                      <ConfirmDialog
                          visible={visibleDeletePopUp}
                          onHide={!visibleDeletePopUp}
                          message="Bu işlem geri alınamaz!"
                          header="Yetkiyi silmek istediğinize emin misiniz?"
                          icon="pi pi-exclamation-triangle"
                          accept={() => accept(selectedRow)}  
                          reject={() => reject(selectedRow)}  
                          acceptLabel='Evet'
                          rejectLabel='Vazgeç'
                      />
                    

                  {/* Save - Update Pop-Up */}
                      <Dialog
                        header={visibleSavePopUp ? "Yeni Yetki Kontrol Oluşturma Formu" : "Yetki Kontrol Düzenleme Formu"}
                        visible={visibleSavePopUp || visibleUpdatePopUp}
                        style={{ width: '80rem', height: '45rem'}}
                        onHide={() => {
                          if(!visibleSavePopUp && !visibleUpdatePopUp){
                            return;                    
                          }
                          setVisibleSavePopUp(false);
                          setVisibleUpdatePopUp(false);
                          closeModal();
                        }}>
                          <div className='card flex flex-column justify-content-center gap-3 '>
                            <div className="flex flex-column ">
                              <label htmlFor="name">Name</label>
                                <InputText 
                                  value={formData.name}
                                  name="name" 
                                  placeholder="Name"
                                  onChange={handleFormChange} />
                            </div>
                            <div className="flex flex-column">
                              <label htmlFor="description">Description</label>
                                <InputText
                                  value={formData.description}
                                  name="description"
                                  placeholder='Description'
                                  onChange={handleFormChange} />
                            </div>
                            <div className="flex flex-column">
                              <label htmlFor="sideType">Side Type</label>
                                <Dropdown 
                                  value={formData.sideType} 
                                  name="sideType"
                                  onChange={handleFormChange} 
                                  options={sideTypes} optionLabel='name'
                                  placeholder='Side Type' showClear />
                            </div>
                            <div className="flex flex-column">
                              <label htmlFor="modulePermission">Module Permission</label>
                                <InputText
                                value={formData.modulePermission}
                                name="modulePermission"
                                onChange={handleFormChange}
                                placeholder="Module Permission" />
                            </div>
                            <div className="flex flex-column">
                              <label htmlFor="pointPermission">Point Permission</label>
                                <InputText 
                                value={formData.pointPermission}
                                name="pointPermission"
                                onChange={handleFormChange}
                                placeholder="Point Permission" />
                            </div>
                            <div className="flex flex-column">
                              <label htmlFor="operationPermission">Operation Permission</label>
                                <InputText
                                value={formData.operationPermission}
                                name="operationPermission"
                                onChange={handleFormChange}
                                placeholder="Operation Permission" />
                            </div>
                            <div className="flex flex-wrap justify-content-end gap-3" >
                              <Button label="İptal" severity='danger' disabled={processStarted} onClick={() => closeModal()} />
                              <Button label="Kaydet" severity='success' disabled={processStarted} onClick={() => {if(visibleSavePopUp) submitForm(); else updateForm();}} /> 
                            </div>
                          </div>
                        </Dialog>
                  


                      
              </div>
          </Panel>
          )}
          {!viewTable && (
            <Panel className='flex flex-column justify-content-center ' style={{ paddingTop: '15px', height: '10vh' }}>
              <p className='m-0 text-center'>VERİ YOK!</p>
            </Panel>
          )}
        </>
    )
}

export default PermissionPage;
