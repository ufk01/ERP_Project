'use client'
import { InputText } from 'primereact/inputtext';
import React, { useContext, useEffect, useState, useRef } from 'react';
import { GlobalContext } from '../../../components/api_context/GlobalContext';
import { Panel } from 'primereact/panel';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import api from '../../../Api';
import { Button } from 'primereact/button';
import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog';
import { Toast } from 'primereact/toast'; // Toast bildirimleri için
import { Dialog } from 'primereact/dialog';
import { TreeSelect } from 'primereact/treeselect';
        


const RolePage = () => {
    
    const toast = useRef(null);
    const { hasPermission, directToErrorPage} = useContext(GlobalContext);
    const [first, setFirst] = useState(0);
    const [rows, setRows] = useState(5);
    const [visibleDeletePopUp, setVisibleDeletePopUp] = useState(false);
    const [visibleSavePopUp, setVisibleSavePopUp] = useState(false);
    const [visibleUpdatePopUp, setVisibleUpdatePopUp] = useState(false);
    const [selectedRow, setSelectedRow] = useState(null);
    const [viewTable, setViewTable] = useState(false);
    const [responseData, setResponseData] = useState({ content: [], totalPages: null, totalElements: null});
    const [processStarted, setProcessStarted] = useState(false);
    const [permissionNodeList, setPermissionNodeList] = useState([]);
    const [selectedNodeKeys, setSelectedNodeKeys] = useState(null);
    const [query, setQuery] = useState({
        id: '',
        roleName: '',
        description: '',
        pageSize: rows,
        pageNumber: first
        });
    const [formData, setFormData] = useState({
        id: '',
        roleName: '',
        description: '',
        permissionName: []
    })
    const authorizationList = {
        view: "admin.role.view",
        update: "admin.role.update",
        delete: "admin.role.delete",
        save: "admin.role.save"
    };

    const accept = (rowData) => {
        if(toast.current){
            deleteForm(rowData.id, rowData.name);
            setVisibleDeletePopUp(false);
            toast.current.show({ severity: 'success', summary: 'Başarıyla Silindi!', detail: rowData.roleName.toUpperCase() + " Başarıyla Silindi!", life: 3000});
            setSelectedRow(null);
        }
    }
    
    const reject = (rowData) => {
        if(toast.current) {
            setVisibleDeletePopUp(false);
            toast.current.show({ severity: 'warn', summary: 'İptal Edildi', detail: rowData.roleName.toUpperCase() +  ' Silme işlemi iptal eildi!', life: 3000 });
            setSelectedRow(null);
        }
    }
  
    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setQuery((prevQuery) => ({
            ...prevQuery,
            [name]: value === '' ? null : value, 
        }));
    };

    const handleFormChange = async (e) => {
        const { name, value } = e.target;
        setFormData((prevFormData) => ({
            ...prevFormData,
            [name]: value,
        }));
    };

    const handlePaginationChange = async(e) => {
        if (query.pageSize !== e.rows) {  
            query.pageSize = e.rows; 
            setRows(e.rows); 
        }
        if (query.pageNumber !== e.first / e.rows){
          query.pageNumber = e.first / e.rows;
          setFirst(e.first);
        }
        
        await getPagination();
    };

    function clearInputFields() {
        setQuery({
            id: '',
            roleName: '',
            description: '',
            pageSize: rows,
            pageNumber: 0
        })
    }

    const closeModal = () => {
        setVisibleSavePopUp(false);
        setVisibleUpdatePopUp(false);
        setFormData({
            id: '',
            roleName: '',
            description: '',
            permissionName: []
        });
        setSelectedRow(null);
        setSelectedNodeKeys(null);
        setPermissionNodeList([]);
    };

    const openUpdateModal = async (rowData) => {
        setSelectedRow(rowData);
        getAllPermissions();
        await getRoleById(rowData.id);
        setVisibleUpdatePopUp(true);
    }

    async function getPagination(updateQuery){
        setProcessStarted(true);
         await api
            .post(process.env.NEXT_PUBLIC_ROLE_PAGINATION_PATH, updateQuery || query)
            .then((response) => {
                if(response.data.content.length !== 0){
                    setResponseData(response.data);
                    setViewTable(true);
                    setProcessStarted(false);
                }
                else {
                    setViewTable(false);
                    setProcessStarted(false);
                }
            })
            .catch((reason) => {
                alert(reason);
            })
    }

    function submitForm(){
        formData.permissionName = [];
        if(selectedNodeKeys){
           for(let element in selectedNodeKeys){
                if(element){
                    formData.permissionName.push(element);
                }
            }
        }
        api
            .post(process.env.NEXT_PUBLIC_ROLE_SAVE_PATH, formData)
            .then((response) => {
                closeModal();
                clearInputFields();
                getPagination();
            })
            .catch((reason) => {
                alert(reason);
            })
    }

    function updateForm(){
        debugger;
        formData.permissionName = [];
        if(selectedNodeKeys){
            for(let element in selectedNodeKeys) {
                if(element){
                    formData.permissionName.push(element);
                }
            }
        }
        api
            .put(process.env.NEXT_PUBLIC_ROLE_UPDATE_PATH, formData)
            .then((response) => {
                closeModal();
                clearInputFields();
                getPagination();
            })
            .catch((reason) => {
                alert(reason);
            })
    }

    function deleteForm(getId){
        api
            .delete(process.env.NEXT_PUBLIC_ROLE_DELETE_PATH
                .concat("/")
                .concat(getId)
            )
            .then((response) => {
                closeModal();
                clearInputFields();
                getPagination();
            })
            .catch((reason) => {
                alert(reason)
            })
    }

    function getAllPermissions(){
        api
            .get(process.env.NEXT_PUBLIC_PERMISSION_FIND_ALL_PATH)
            .then((response) => {
                if(response.data){
                    response.data.forEach((element, index) => {
                        const label = element;
                        const treeElement = {
                            key: label,
                            label: label
                        }
                        permissionNodeList.push(treeElement);
                    });
                }     
            })
            .catch((reason) => {
                alert(reason);
            })
    }

    async function getRoleById(id){
        api
            .get(process.env.NEXT_PUBLIC_ROLE_GET_PATH
                .concat("/")
                .concat(id)
            )
            .then((response) => {
                if(response.data.permissionName){
                    const responseList = {};
                    response.data.permissionName.forEach(element => {
                        responseList[element] = {
                                checked: true,
                                partialChecked: false
                        };
                    });
                    setSelectedNodeKeys(responseList);
                    setFormData(response.data);
                }
            })
            .catch((reason) => {
                alert(reason);
            })
    }

    useEffect(() => {
        if(!hasPermission(authorizationList.view)){
            directToErrorPage();
        }
        api 
            .post(process.env.NEXT_PUBLIC_ROLE_PAGINATION_PATH, {
                roleName: "",
                description: "",
                pageSize: rows,
                pageNumber: first
            })
            .then((response) => {
                if(response.data.content.length !== 0){
                    setResponseData(response.data);
                    setViewTable(true);
                }
                else {
                    setViewTable(false);
                }
            })
            .catch((reason) => {
                alert(reason);
            })
    }, [authorizationList.view, directToErrorPage, hasPermission]);

    return (
        <>
            <Panel header="Rol Kontrol Paneli" className='flex flex-column'>
                <div className='card flex flex-column gap-3'>
                    <div className='flex md:flex-row gap-3'>
                        <div className='p-inputgroup flex-1'>
                            <InputText
                            value={query.roleName}
                            name="roleName"
                            placeholder='Role Name'
                            onChange={handleInputChange} />
                        </div>
                        <div className='p-inputgroup flex-1'>
                            <InputText
                            value={query.description}
                            name="description"
                            placeholder='Description'
                            onChange={handleInputChange} />
                        </div>
                    </div>
                    <div className='flex flex-wrap justify-content-end gap-3'>
                        <Button label="Temizle" severity='danger' disabled={processStarted} onClick={() => clearInputFields()} />
                        <Button label="Sorgula" severity='success' disabled={processStarted} onClick={() => getPagination()} />
                    </div>
                </div>
            </Panel>

            {viewTable && (
                <Panel className='flex flex-column' style={{paddingTop: '15px'}} >
                    <div className='card'>
                        <DataTable lazy value={responseData.content} selection={selectedRow} paginator rows={rows} first={first} totalRecords={responseData.totalElements} rowsPerPageOptions={[5, 10, 25, 50]}
                        tableStyle={{ minWidth: '20rem'}} showGridlines stripedRows onPage={handlePaginationChange}>
                            <Column field='roleName' header="Role Name" alignHeader='center' className='text-center'></Column>
                            <Column field='description' header="Description" alignHeader='center'  className='text-center'></Column>
                            {(hasPermission(authorizationList.save) || hasPermission(authorizationList.update) || hasPermission(authorizationList.delete)) && (
                            <Column alignHeader='center' bodyClassName="text-center"
                                header={() => (
                                    <>
                                        {hasPermission(authorizationList.save) && (
                                        <Button
                                            icon="pi pi-plus"
                                            onClick={() => {
                                                getAllPermissions();
                                                setSelectedRow(selectedRow)
                                                setVisibleSavePopUp(true)
                                            }}
                                            className="p-button-info"
                                            />
                                        )}
                                    </>

                                )}

                                body={(rowData) => (
                                    <>
                                    <div className='flex md:flex-column gap-1'>
                                        {hasPermission(authorizationList.update) && (
                                        <div>
                                            <Button
                                                icon="pi pi-pencil"
                                                onClick={() => openUpdateModal(rowData)}
                                                className="p-button-secondary p-mr-2"
                                                />
                                        </div>
                                        )}
                                        {hasPermission(authorizationList.delete) && (
                                        <div>
                                            <Button
                                                icon="pi pi-trash"
                                                onClick={() => {
                                                    setSelectedRow(rowData)
                                                    setVisibleDeletePopUp(true)
                                                }}
                                                className="p-button-contrast"
                                                />
                                        </div>
                                        )}
                                    </div>
                                    </>
                                )}
                            ></Column>
                            )}
                        </DataTable>


                        { /* Delete Pop-Up */}
                            <Toast ref={toast} />
                            <ConfirmDialog
                            visible={visibleDeletePopUp}
                            onHide={!visibleDeletePopUp}
                            message="Bu işlem geri alınamaz!"
                            header="Yetkiyi silmek istediğinize emin misiniz?"
                            icon="pi pi-exclamation-triangle"
                            accept={() => accept(selectedRow)}
                            reject={() => reject(selectedRow)}
                            acceptLabel="Evet"
                            rejectLabel="Vazgeç"
                            />

                        { /* Save - Update Pop-Up */ }
                        <Dialog
                            header={visibleSavePopUp ? "Yeni Rol Kontrol Oluşturma Formu" : "Rol Kontrol Düzenleme Formu"}
                            visible={visibleSavePopUp || visibleUpdatePopUp}
                            style={{ width: '80rem', height: '30rem'}}
                            onHide={() => {
                                if(!visibleSavePopUp && !visibleUpdatePopUp){
                                    return;
                                }
                                setVisibleSavePopUp(false);
                                setVisibleUpdatePopUp(false);
                                closeModal();
                            }}>
                                <div className='card flex flex-column justify-content-center gap-3'>
                                    <div className='flex flex-column'>
                                        <label htmlFor="roleName">Name</label>
                                        <InputText
                                            value={formData.roleName}
                                            name="roleName"
                                            placeholder='Role Name'
                                            onChange={handleFormChange} />
                                    </div>
                                    <div className='flex flex-column'>
                                        <label htmlFor='description'>Description</label>
                                        <InputText
                                            value={formData.description}
                                            name="description"
                                            placeholder="Description"
                                            onChange={handleFormChange} />
                                    </div>
                                    <div className='flex flex-column'>
                                        <label htmlFor='permissionList'>Permission List</label>
                                        <TreeSelect value={selectedNodeKeys} onChange={(e) => setSelectedNodeKeys(e.value)} options={permissionNodeList}
                                        filter metaKeySelection={false} className='w-full' selectionMode='checkbox' placeholder='Permission List'
                                        ></TreeSelect>
                                        
                                    </div>
                                    <div className='flex flex-wrap justify-content-end gap-3'>
                                        <Button label="İptal" severity='danger' disabled={processStarted} onClick={() => closeModal()} />
                                        <Button label="Kaydet" severity='success' disabled={processStarted} onClick={() => {if(visibleSavePopUp) submitForm(); else updateForm();}} />
                                    </div>

                                </div>


                        </Dialog>           


                    </div>
                </Panel>
            )}

            {!viewTable && (
                <Panel className='flex flex-column justify-content-center ' style={{ paddingTop: '15px', height: '10vh'}}>
                    <p className='m-o text-center'>VERİ YOK!</p>
                </Panel>
            )}           
        </>
    )






}

export default RolePage;