'use client'
import { InputText } from 'primereact/inputtext';
import React, { useContext, useEffect, useState, useRef } from 'react';
import { GlobalContext } from '../../../components/api_context/GlobalContext';
import { Panel } from 'primereact/panel';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import api from '../../../Api';
import { Button } from 'primereact/button';
import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog';
import { Toast } from 'primereact/toast'; // Toast bildirimleri için
import { Dialog } from 'primereact/dialog';
import { TreeSelect } from 'primereact/treeselect';
import * as util from '../../../components/utils/util';



    const UserPage = () => {

        const toast = useRef(null);
        const { hasPermission, directToErrorPage } = useContext(GlobalContext);
        const [first, setFirst] = useState(0);
        const [rows, setRows] = useState(5);
        const [visibleDeletePopUp, setVisibleDeletePopUp] = useState(false);
        const [visibleSavePopUp, setVisibleSavePopUp] = useState(false);
        const [visibleUpdatePopUp, setVisibleUpdatePopUp] = useState(false);
        const [selectedRow, setSelectedRow] = useState(null);
        const [viewTable, setViewTable] = useState(false);
        const [responseData, setResponseData] = useState({ content: [], totalPages: null, totalElements: null});
        const [processStarted, setProcessStarted] = useState(false);
        const [permissionNodeList, setPermissionNodeList] = useState([]);
        const [roleNodeList, setRoleNodeList] = useState([]);
        const [selectedPermissionNodeKeys, setSelectedPermissionNodeKeys] = useState(null);
        const [selectedRoleNodeKeys, setSelectedRoleNodeKeys] = useState(null);
        const [query, setQuery] = useState({
            id: '',
            username: '',
            name:'',
            surname: '',
            email: '',
            pageSize: rows,
            pageNumber: first
        });
        const [formData, setFormData] = useState({
            id: '',
            username: '',
            name: '',
            surname: '',
            email: '',
            password: '',
            rolesName: [],
            permissionsName: []
        });
        const authorizationList = {
            view: "admin.user.view",
            update: "admin.user.update",
            delete: "admin.user.delete",
            save: "admin.user.save"
        };

        const accept = (rowData) => {
            if(toast.current){
                deleteForm(rowData.id, rowData.name);
                setVisibleDeletePopUp(false);
                toast.current.show({ severity: 'success', summary: 'Başarıyla Silindi!', detail: rowData.username.toUpperCase() + " Kullanıcısı Başarıyla Silindi!", life: 3000});
                setSelectedRow(null);
            }
        }
        
        const reject = (rowData) => {
            if(toast.current) {
                setVisibleDeletePopUp(false);
                toast.current.show({ severity: 'warn', summary: 'İptal Edildi', detail: rowData.username.toUpperCase() +  ' Kullanıcısı Silme işlemi iptal eildi!', life: 3000 });
                setSelectedRow(null);
            }
        }

        function clearInputFields() {
            setQuery({
                id: '',
                username: '',
                name: '',
                surname: '',
                email: '',
                pageSize: rows,
                pagenumber: 0
            })
        }

        const closeModal = () => {
            setVisibleSavePopUp(false);
            setVisibleUpdatePopUp(false);
            setFormData({
                id: '',
                username: '',
                name: '',
                surname: '',
                email: '',
                password: '',
                rolesName: [],
                permissionsName: []
            });
            setSelectedRow(null);
            setSelectedPermissionNodeKeys(null);
            setSelectedRoleNodeKeys(null);
            setPermissionNodeList([]);
            setRoleNodeList([]);
        }

        const openUpdateModal = async(rowData) => {
            setSelectedRow(rowData);
            getAllPermissions();
            getAllRoles();
            await getUserById(rowData.id);
            setVisibleUpdatePopUp(true);
        }

        function formatDate(date){
            const day = String(date.getDate()).padStart(2, '0'); 
            const month = String(date.getMonth() + 1).padStart(2, '0'); 
            const year = date.getFullYear();
            const hours = String(date.getHours()).padStart(2, '0');
            const minutes = String(date.getMinutes()).padStart(2, '0'); 
            const seconds = String(date.getSeconds()).padStart(2, '0'); 
            const customFormat = `${day}/${month}/${year} ${hours}:${minutes}:${seconds}`;
            return customFormat;
        }

        async function getPagination(updateQuery) {
            setProcessStarted(true);
            await api 
                .post(process.env.NEXT_PUBLIC_USER_PAGINATION_PATH, updateQuery || query)
                .then((response) => {
                    if(response.data.content.length !== 0){
                        response.data.content.forEach(element => {
                            if(element.lastLogin) {
                                const date = new Date(element.lastLogin);
                                element.lastLogin = formatDate(date);
                            }
                        })
                        setResponseData(response.data);
                        setViewTable(true)
                        setProcessStarted(false);
                    }
                    else {
                        setViewTable(false);
                        setProcessStarted(false);
                    }
                })
                .catch((reason) => {
                    alert(reason);
                })
        }

        function submitForm() {
            formData.permissionsName = [];
            formData.rolesName = [];
            if(selectedPermissionNodeKeys){
                for(let element in selectedPermissionNodeKeys) {
                    if(element) {
                        formData.permissionsName.push(element);
                    }
                }
            }
            if(selectedRoleNodeKeys) {
                for(let element in selectedRoleNodeKeys) {
                    if(element) {
                        formData.rolesName.push(element);
                    }
                }
            }
            api
                .post(process.env.NEXT_PUBLIC_USER_SAVE_PATH, formData)
                .then((response) => {
                    closeModal();
                    clearInputFields();
                    getPagination();
                })
                .catch((reason) => {
                    alert(reason);
                })
        }

        function updateForm() {
            formData.permissionsName = [];
            formData.rolesName = [];
            if(selectedPermissionNodeKeys){
                for(let element in selectedPermissionNodeKeys) {
                    if(element) {
                        formData.permissionsName.push(element);
                    }
                }
            }
            if(selectedRoleNodeKeys) {
                for(let element in selectedRoleNodeKeys) {
                    if(element) {
                        formData.rolesName.push(element);
                    }
                }
            }
            api     
                .put(process.env.NEXT_PUBLIC_USER_UPDATE_PATH, formData)
                .then((response) => {
                    closeModal();
                    clearInputFields();
                    getPagination();
                })
                .catch((reason) => {
                    alert(reason);
                })
        }

        function deleteForm(getId) {
            api
                .delete(process.env.NEXT_PUBLIC_USER_DELETE_PATH
                    .concat("/")
                    .concat(getId)
                )
                .then((response) => {
                    closeModal();
                    clearInputFields();
                    getPagination();
                })
                .catch((reason) => {
                    alert(reason);
                })
        }

        function getAllPermissions(){
            api
                .get(process.env.NEXT_PUBLIC_PERMISSION_FIND_ALL_PATH)
                .then((response) => {
                    if(response.data) {
                        response.data.forEach(element => {
                            const label = element;
                            const treeElement = {
                                key: label,
                                label: label
                            };
                            permissionNodeList.push(treeElement);
                        })
                    }
                })
                .catch((reason) => {
                    alert(reason);
                })
        }

        function getAllRoles(){
            api
                .get(process.env.NEXT_PUBLIC_ROLE_FIND_NAMES)
                .then((response) => {
                    if(response.data) {
                        response.data.forEach(element => {
                            const label = element;
                            const treeElement = {
                                key: label,
                                label: label
                            };
                            roleNodeList.push(treeElement);
                        })
                    }
                })
                .catch((reason) => {
                    alert(reason);
                })
        }

        async function getUserById(id) {
            api
                .get(process.env.NEXT_PUBLIC_USER_GET_PATH
                    .concat("/")
                    .concat(id)
                )
                .then((response) => {
                    if(response.data) {
                        if(response.data.permissionsName) {
                            const responseList = {};
                            response.data.permissionsName.forEach(element => {
                                responseList[element] = {
                                    checked: true,
                                    partialChecked: false
                                };
                            });
                            setSelectedPermissionNodeKeys(responseList);
                        }
                        if(response.data.rolesName) {
                            const responseList = {};
                            response.data.rolesName.forEach(element => {
                                responseList[element] = {
                                    checked: true,
                                    partialChecked: false
                                };
                            });
                            setSelectedRoleNodeKeys(responseList);
                        }   
                    setFormData(response.data);            
                    }
                })
                .catch((reason) => {
                    alert(reason);
                })
        }

        useEffect(() => {
            if(!hasPermission(authorizationList.view)) {
                directToErrorPage();
            }
            api
                .post(process.env.NEXT_PUBLIC_USER_PAGINATION_PATH, {
                    username: '',
                    name: '',
                    surname : '',
                    email: '',
                    pageSize: rows,
                    pageNumber: first
                })
                .then((response) => {
                    if(response.data.content.length !== 0){
                        response.data.content.forEach(element => {
                            if(element.lastLogin) {
                                const date = new Date(element.lastLogin);
                                element.lastLogin = formatDate(date);
                            }
                        })
                        setResponseData(response.data);
                        setViewTable(true);
                    }
                    else {
                        setViewTable(false);
                    }
                })
                .catch((reason) => {
                    alert(reason);
                })

        }, [authorizationList.view, directToErrorPage, hasPermission]);
    

        return ( 
            <>
                <Panel header="Kullanıcı Kontrol Paneli" className='flex flex-column'>
                    <div className='card flex flex-column gap-3'>
                        <div className='flex md:flex-row gap-3'>
                            <div className='p-inputgroup flex-1'>
                                <InputText
                                    value={query.username}
                                    name="username"
                                    placeholder='Username'
                                    onChange={util.handleInputChange(setQuery)} />
                            </div>
                            <div className='p-inputgroup flex-1'>
                                <InputText
                                    value={query.name}
                                    name="name"
                                    placeholder='Name'
                                    onChange={util.handleInputChange(setQuery)} />
                            </div>
                            <div className='p-inputgroup flex-1'>
                                <InputText
                                    value={query.surname}
                                    name="surname"
                                    placeholder="Surname"
                                    onChange={util.handleInputChange(setQuery)} />
                            </div>
                        </div>

                            <div className='flex md:flex-row gap-3'>
                                <div className='p-inputgroup flex-1'>
                                    <InputText
                                        value={query.email}
                                        name= "email"
                                        placeholder='Email'
                                        onChange={util.handleInputChange(setQuery)} />
                                </div>
                            </div>
                            <div className='flex flex-wrap justify-content-end gap-3'>
                                <Button label="Temizle" severity='danger' disabled={processStarted} onClick={() => clearInputFields()} />
                                <Button label="Sorgula" severity='success' disabled={processStarted} onClick={() => getPagination()} />
                            </div>
                    </div>
                </Panel>

                {viewTable && (
                    <Panel className='flex flex-column' style= {{ paddingTop: '15px '}} >
                        <div className='card'>
                            <DataTable lazy value={responseData.content} selection={selectedRow} paginator rows={rows} first={first} totalRecords={responseData.totalElements}
                            rowsPerPageOptions={[5, 10, 25, 50]} tableStyle={{ minWidth: '20rem'}} showGridlines stripedRows onPage={util.handlePaginationChange(setQuery, setRows, setFirst, getPagination)} >
                                <Column field='username' header="Username" alignHeader='center' className='text-center'></Column>
                                <Column field='name' header="Name" alignHeader='center' className='text-center'></Column>
                                <Column field='surname' header="Surname" alignHeader='center' className='text-center'></Column>
                                <Column field='email' header="Email" alignHeader='center' className='text-center'></Column>
                                <Column field='lastLogin' header="Last Login" alignHeader='center' className='text-center'></Column>
                                {(hasPermission(authorizationList.save) || hasPermission(authorizationList.update) || hasPermission(authorizationList.delete)) && (
                                <Column alignHeader='center' bodyClassName="text-center"
                                    header={() => (
                                        <>
                                        {hasPermission(authorizationList.save) && (
                                            <Button
                                                icon="pi pi-plus"
                                                onClick={() => {
                                                    getAllPermissions();
                                                    getAllRoles();
                                                    setSelectedRow(selectedRow)
                                                    setVisibleSavePopUp(true)
                                                }}
                                                className='p-button-info'
                                                />
                                            )}
                                        </>
                                    )}

                                    body={(rowData) => (
                                        <>
                                            <div className='flex md:flex-column gap-1'>
                                                {hasPermission(authorizationList.update)  && (
                                                    <div>
                                                        <Button
                                                            icon="pi pi-pencil"
                                                            onClick={() => openUpdateModal(rowData)}
                                                            className='p-button-secondary p-mr-2'
                                                            />
                                                    </div>
                                                )}
                                                {hasPermission(authorizationList.delete) && (
                                                    <div>
                                                        <Button
                                                            icon="pi pi-trash"
                                                            onClick={() => {
                                                                setSelectedRow(rowData);
                                                                setVisibleDeletePopUp(true);
                                                            }}
                                                            className="p-button-contrast"
                                                            />
                                                    </div>
                                                )}
                                            </div>
                                        </>
                                    )}
                                    ></Column>
                                )}
                            </DataTable>

                            { /* Delete Pop-Up */}
                            <Toast ref={toast} />
                            <ConfirmDialog
                                visible={visibleDeletePopUp}
                                onHide={!visibleDeletePopUp}
                                message="Bu işlem geri alınamaz!"
                                header="Kullanıcıyı silmek istediğinize emin misiniz?"
                                icon="pi pi-exclamation-triangle"
                                accept={() => accept(selectedRow)}
                                reject={() => reject(selectedRow)}
                                />

                            
                            { /* Save - Update Pop-Up */}
                            <Dialog
                                header={visibleSavePopUp ? "Yeni Kullanıcı Kontrol Oluşturma Formu" : "Kullanıcı Kontrol Düzenleme Formu"}
                                visible={visibleSavePopUp || visibleUpdatePopUp}
                                style={{ width: '80rem', height: '60rem'}}
                                onHide={() => {
                                    if(!visibleSavePopUp && !visibleUpdatePopUp) {
                                        return;
                                    }
                                    setVisibleSavePopUp(false);
                                    setVisibleUpdatePopUp(false);
                                    closeModal();
                                }} >
                                    <div className='card flex flex-column justify-content-center gap-3'>
                                        <div className='flex flex-column'>
                                            <label htmlFor='username'>Username</label>
                                            <InputText
                                                value={formData.username}
                                                name="username"
                                                placeholder='Username'
                                                onChange={util.handleFormChange(setFormData)} />
                                        </div>
                                        <div className='flex flex-column'>
                                            <label htmlFor='name'>Name</label>
                                            <InputText
                                                value={formData.name}
                                                name="name"
                                                placeholder='Name'
                                                onChange={util.handleFormChange(setFormData)} />
                                        </div>
                                        <div className='flex flex-column'>
                                            <label htmlFor='surname'>Surname</label>
                                            <InputText
                                                value={formData.surname}
                                                name="surname"
                                                placeholder='Surname'
                                                onChange={util.handleFormChange(setFormData)} />
                                        </div>
                                        <div className='flex flex-column'>
                                            <label htmlFor='email'>Email</label>
                                            <InputText
                                                value={formData.email}
                                                name="email"
                                                placeholder='Email'
                                                onChange={util.handleFormChange(setFormData)} />
                                        </div>
                                        <div className='flex flex-column'>
                                            <label htmlFor='password'>Password</label>
                                            <InputText
                                                value={formData.password}
                                                name="password"
                                                placeholder='Password'
                                                disabled={!visibleSavePopUp}
                                                onChange={util.handleFormChange(setFormData)} />
                                        </div>
                                        <div className='flex flex-column'>
                                            <label htmlFor='roleList'>Role List</label>
                                            <TreeSelect 
                                            value={selectedRoleNodeKeys} 
                                            onChange={(e) => setSelectedRoleNodeKeys(e.value)} 
                                            options={roleNodeList}
                                            filter 
                                            metaKeySelection={false} 
                                            className='w-full' 
                                            selectionMode='checkbox' 
                                            placeholder='Role List'
                                            ></TreeSelect>
                                        </div>
                                        <div className='flex flex-column'>
                                            <label htmlFor='permissionList'>Permission List</label>
                                            <TreeSelect 
                                            value={selectedPermissionNodeKeys} 
                                            onChange={(e) => setSelectedPermissionNodeKeys(e.value)} 
                                            options={permissionNodeList}
                                            filter 
                                            metaKeySelection={false} 
                                            className='w-full' 
                                            selectionMode='checkbox' 
                                            placeholder='Permission List'
                                            ></TreeSelect>
                                        </div>                             
                                        <div className='flex flex-wrap justify-content-end gap-3'>
                                            <Button label="İptal" severity="danger" disabled={processStarted} onClick={() => closeModal()} />
                                            <Button label="Kaydet" severity='success' disabled={processStarted} onClick={() => {if(visibleSavePopUp) submitForm(); else updateForm();}} />
                                        </div>
                                    </div>
                                </Dialog>                
                        </div>
                    </Panel>
                )}

                {!viewTable && (
                    <Panel className='flex flex-column justify-content-center' style={{ paddingTop: '15px', height: '10vh'}}>
                        <p className='m-o text-center'>VERİ YOK!</p>
                    </Panel>
                )}


            </>
        )


    }

    export default UserPage; 