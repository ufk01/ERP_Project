import Layout from '../../layout/layout';

export const metadata = {
    title: 'LogiFlow',
    description: 'Logi Flow ERP System',
    robots: { index: false, follow: false },
    viewport: { initialScale: 1, width: 'device-width' },
    icons: {
        icon: '/public/next.svg'
    }
};

export default function AppLayout({ children }) {
    return <Layout>{children}</Layout>;
}
