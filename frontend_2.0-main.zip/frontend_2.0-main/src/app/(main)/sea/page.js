'use client'
import React, { useState, useEffect, useRef, useContext } from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import * as util from '../../../components/utils/util'
import api from '../../../Api'
import { GlobalContext } from '../../../components/api_context/GlobalContext.js';
import { Panel } from 'primereact/panel';
import { Calendar } from 'primereact/calendar';
import { InputText } from 'primereact/inputtext';
import { Dropdown } from 'primereact/dropdown';
import { Button } from 'primereact/button';
import { Accordion, AccordionTab } from 'primereact/accordion';
import { Toast } from 'primereact/toast';
import { ConfirmDialog } from 'primereact/confirmdialog';
import { TreeSelect } from 'primereact/treeselect';

const SeaPage = () => {
    const { hasPermission, directToErrorPage } = useContext(GlobalContext);
    const [first, setFirst]                                 = useState(0);
    const [rows, setRows]                                   = useState(10);
    const [seaDataList, setSeaDataList]                     = useState({ content: [], totalPages: null, totalElements: null});
    const [visibleDeletePopUp, setVisibleDeletePopUp]       = useState(false);
    const [visibleErrorPopUp, setVisibleErrorPopUp]         = useState(false);
    const [selectedSeaData, setSelectedSeaData]             = useState(null);
    const [seaDataForm, setSeaDataForm]                     = useState(false);
    const [editingRows, setEditingRows]                     = useState([{}]);
    const toast                                             = useRef(null);
    const toastError                                        = useRef(null);
    const [loading, setLoading]                             = useState(false);
    const [selectedRow, setSelectedRow]                     = useState(null);
    const [saveIsSaving, setSaveIsSaving]                   = useState(false);
    const [selectedSituationType, setSelectedSituationType] = useState(null);
    const [nextRefNo, setNextRefNo]                         = useState('REF-1');
    const [isAddedRow, setIsAddedRow]                       = useState(false);
    
    const lclAndFtlTypes = [
        { name: 'LCL', value: 'LCL'},
        { name: 'FTL', value: 'FTL' }
    ];
    const serviceTypes = [
        { name: 'Suez', value: 'SUEZ'},
        { name: 'Cape of Good Hope', value: 'CAPE_OF_GOOD_HOPE'}
    ]
    const incoTypes = [
        { name: 'EXW', value: 'EXW'},
        { name: 'FOB', value: 'FOB'},
        { name: 'FCA', value: 'FCA'},
        { name: 'DAP', value: 'DAP'},
        { name: 'DDP', value: 'DDP'},
    ];
    const agencyTypes = [
        { name: 'CTL', value: 'CTL'},
        { name: 'Hunicorn', value: 'HUNICORN'},
        { name: 'Cargopia', value : 'CARGOPIA'},
        { name: 'Unimar', value: 'UNIMAR'},
        { name: 'KHEE', value: 'KHEE'}
    ];
    const loadingCountryTypes = [
        { name: 'Australia', value: 'AUSTRALIA' },
        { name: 'Bangladesh', value: 'BANGLADESH' },
        { name: 'Cambodia', value: 'CAMBODIA' },
        { name: 'China', value: 'CHINA' },
        { name: 'India', value: 'INDIA' },
        { name: 'Indonesia', value: 'INDONESIA' },
        { name: 'Japan', value: 'JAPAN' },
        { name: 'Malaysia', value: 'MALAYSIA' },
        { name: 'Mauritius', value: 'MAURITIUS' },
        { name: 'New Zealand', value: 'NEW_ZELAND' },
        { name: 'Pakistan', value: 'PAKISTAN' },
        { name: 'Philippines', value: 'PHILIPPINES' },
        { name: 'South Africa', value: 'S_AFRICA' },
        { name: 'South Korea', value: 'S_KOREA' },
        { name: 'Sri Lanka', value: 'SRI_LANKA' },
        { name: 'Taiwan', value: 'TAIWAN' },
        { name: 'Thailand', value: 'THAILAND' },
        { name: 'United Arab Emirates', value: 'UAE' },
        { name: 'United States', value: 'USA' },
        { name: 'Vietnam', value: 'VIETNAM' }
    ];
    
    const portArrivalTypes = [
        { name: 'Ambarlı', value: 'AMBARLI'},
        { name: 'İzmirt', value: 'IZMIT'},
        { name: 'Mersin', value: 'MERSIN'}
    ];
    const destinationCityTypes = [
        { name: 'Türkiye/İstanbul', value: 'TURKEY_ISTANBUL'},
        { name: 'Türkiye/İzmit', value: 'TURKEY_IZMIT'},
        { name: 'Türkiye/Mersin', value: 'TURKEY_MERSIN'}  
    ];
    const portDepartureTypes = [
        { name: 'Chong Qing', value: 'CHONG_QING' },
        { name: 'Dalian', value: 'DALIAN' },
        { name: 'Foshan', value: 'FOSHAN' },
        { name: 'Fuzhou', value: 'FUZHOU' },
        { name: 'Guangzhou', value: 'GUANGZHOU' },
        { name: 'Hong Kong', value: 'HONG_KONG' },
        { name: 'Huangpu', value: 'HUANGPU' },
        { name: 'Jiangmen', value: 'JIANGMEN' },
        { name: 'Jinhua/Yiwu', value: 'JINHUA_YIWU' },
        { name: 'Lianyungang', value: 'LIANYUNGANG' },
        { name: 'Nanjing', value: 'NANJING' },
        { name: 'Ningbo', value: 'NINGBO' },
        { name: 'Qingdao', value: 'QINGDAO' },
        { name: 'Shanghai', value: 'SHANGHAI' },
        { name: 'Shantou', value: 'SHANTOU' },
        { name: 'Shaoxing', value: 'SHAOXING' },
        { name: 'Shenzhen', value: 'SHENZHEN' },
        { name: 'Shunde', value: 'SHUNDE' },
        { name: 'Singapore', value: 'SINGAPORE' },
        { name: 'Suzhou', value: 'SUZHOU' },
        { name: 'Tianjin', value: 'TIANJIN' },
        { name: 'Wenzhou', value: 'WENZHOU' },
        { name: 'Wuxi', value: 'WUXI' },
        { name: 'Xiamen', value: 'XIAMEN' },
        { name: 'Xingang', value: 'XINGANG' },
        { name: 'Zhongshan', value: 'ZHONGSHAN' },
        { name: 'Zhuhai', value: 'ZHUHAI' },
        { name: 'Ahmedabad', value: 'AHMEDABAD' },
        { name: 'Adelaide', value: 'ADELAIDE' },
        { name: 'Chittagong', value: 'CHITTAGONG' },
        { name: 'Phnom Penh', value: 'PHNOM_PENH' },
        { name: 'Belawan', value: 'BELAWAN' },
        { name: 'Pasir Gudang', value: 'PASIR_GUDANG' },
        { name: 'Port Louis', value: 'PORT_LOUIS' },
        { name: 'Yangon', value: 'YANGON' },
        { name: 'Auckland', value: 'AUCKLAND' },
        { name: 'Karachi', value: 'KARACHI' },
        { name: 'Cebu', value: 'CEBU' },
        { name: 'Cape Town', value: 'CAPE_TOWN' },
        { name: 'Busan', value: 'BUSAN' },
        { name: 'Colombo', value: 'COLOMBO' },
        { name: 'Kaohsiung', value: 'KAOHSIUNG' },
        { name: 'Bangkok', value: 'BANGKOK' },
        { name: 'Dubai / Jebel Ali', value: 'DUBAI_JEBEL_ALI' },
        { name: 'Atlanta / Savannah', value: 'ATLANTA_SAVANNAH' },
        { name: 'Da Nang', value: 'DANANG' },
        { name: 'Bangalore', value: 'BANGALORE' },
        { name: 'Brisbane', value: 'BRISBANE' },
        { name: 'Sihanoukville', value: 'SIHANOUKVILLE' },
        { name: 'Jakarta', value: 'JAKARTA' },
        { name: 'Penang', value: 'PENANG' },
        { name: 'Lyttleton', value: 'LYTTLETON' },
        { name: 'Manila', value: 'MANILA' },
        { name: 'Durban', value: 'DURBAN' },
        { name: 'Laem Chabang', value: 'LAEM_CHABANG' },
        { name: 'Baltimore', value: 'BALTIMORE' },
        { name: 'Haiphong', value: 'HAIPHONG' },
        { name: 'Calcutta', value: 'CALCUTTA' },
        { name: 'Freemantle', value: 'FREEMANTLE' },
        { name: 'Semarang', value: 'SEMARANG' },
        { name: 'Port Klang', value: 'PORT_KLANG' },
        { name: 'Johannesburg', value: 'JOHANNESBURG' },
        { name: 'Lat Krabang', value: 'LAT_KRABANG' },
        { name: 'Boston', value: 'BOSTON' },
        { name: 'Ho Chi Minh City', value: 'HO_CHI_MINH_CITY' },
        { name: 'Chennai', value: 'CHENNAI' },
        { name: 'Melbourne', value: 'MELBOURNE' },
        { name: 'Surabaya', value: 'SURABAYA' },
        { name: 'Port Elizabeth', value: 'PORT_ELIZABETH' },
        { name: 'Charleston', value: 'CHARLESTON' },
        { name: 'Cochin', value: 'COCHIN' },
        { name: 'Sydney', value: 'SYDNEY' },
        { name: 'Chicago', value: 'CHICAGO' },
        { name: 'Hyderabad', value: 'HYDERABAD' },
        { name: 'Cleveland', value: 'CLEVELAND' },
        { name: 'New Delhi', value: 'NEW_DELHI' },
        { name: 'Dallas', value: 'DALLAS' },
        { name: 'Nhava Sheva', value: 'NHAVA_SHEVA' },
        { name: 'Detroit', value: 'DETROIT' },
        { name: 'Tuticorin', value: 'TUTICORIN' },
        { name: 'Houston', value: 'HOUSTON' },
        { name: 'Indianapolis', value: 'INDIANAPOLIS' },
        { name: 'Los Angeles', value: 'LOS_ANGELES' },
        { name: 'Memphis', value: 'MEMPHIS' },
        { name: 'Miami', value: 'MIAMI' },
        { name: 'New York', value: 'NEW_YORK' },
        { name: 'Norfolk', value: 'NORFOLK' },
        { name: 'Oakland', value: 'OAKLAND' },
        { name: 'Philadelphia', value: 'PHILADELPHIA' },
    ];
    
    const situationTypes = [
        { key: 'RESERVATION_PENDING', name: 'Rezervasyon bekleniyor', value: 'RESERVATION_PENDING', label: 'Rezervasyon bekleniyor' },
        { key: 'WAITING_FOR_CARGO_ARRIVAL', name: 'Yükün depoya gelmesi bekleniyor', value: 'WAITING_FOR_CARGO_ARRIVAL', label: 'Yükün depoya gelmesi bekleniyor' },
        { key: 'WAITING_FOR_SHIPPER', name: 'Gönderici bekleniyor', value: 'WAITING_FOR_SHIPPER', label: 'Gönderici bekleniyor' },
        { key: 'WAITING_FOR_SHIP_DEPARTURE', name: 'Gemi çıkışı bekleniyor', value: 'WAITING_FOR_SHIP_DEPARTURE', label: 'Gemi çıkışı bekleniyor' },
        { key: 'IN_TRANSIT', name: 'Yolda', value: 'IN_TRANSIT', label: 'Yolda' },
        { key: 'SHIP_ARRIVED', name: 'Gemi geldi', value: 'SHIP_ARRIVED', label: 'Gemi geldi' },
        { key: 'ORDINO_DELIVERED', name: 'Ordino teslimi yapıldı', value: 'ORDINO_DELIVERED', label: 'Ordino teslimi yapıldı' },
        { key: 'IN_WAREHOUSE', name: 'Antrepoda', value: 'IN_WAREHOUSE', label: 'Antrepoda' },
        { key: 'CANCELED', name: 'İptal Edildi', value: 'CANCELED', label: 'İptal Edildi' },
    ];

    let emptySeaData = {
        id: `temp-${Math.random()}`,
        refNo: '',
        service: null,
        lclAndFtl: null,
        workApprovalDate: null,
        inco: null,
        exporter: '',
        customerName: '',
        agency: null,
        loadingCountry: null,
        portArrival: null,
        portDeparture: null,
        destinationCity: null,
        etd: null,
        eta: null,
        numberOfContainers: '',
        cbm: '',
        purchaseFreight: '',
        salesFreight: '',
        situation: null,
        vessel: null,
        puRdIw: null,
        kg: '',
        insurance: null,
        rate: null,
        bl: null

    };
    const [query, setQuery] = useState({
        id: '',
        refNo: '',
        lclAndFtl: null,
        service: null,
        workApprovalDate: null,
        inco: null,
        exporter: '',
        customerName: '',
        agency: null,
        loadingCountry: null,
        portArrival: null,
        portDeparture: null,
        destinationCity: null,
        etd: '',
        eta: '',
        numberOfContainers: '',
        cbm: '',
        purchaseFreight: '',
        salesFreight:'',
        situation: [],
        vessel: '',
        puRdIw: '',
        kg: '',
        insurance: '',
        rate: '',
        bl: '',
        updatedTime: null,
        pageSize: rows,
        pageNumber: first
    });
    const authorizationList = {
        view: 'sea.definition.view',
        update: 'sea.definition.update',
        delete: 'sea.definition.delete',
        save: 'sea.definition.save'
    };

    const bodyTemplate = (type, options) => (rowData) => {
        const selected = options.find(item => item.value === rowData[type]);
        return selected ? selected.name : rowData[type];
    }

    const dateBodyTemplate = (field) => (rowData) => {
        const dateValue = rowData[field];
        if (!dateValue) return '';

        const date = new Date(dateValue);
        return date.toLocaleString('tr-TR', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
        });
    };


    const accept = async (rowData) => {
        if(toast.current){
        const detail = (rowData.refNo)  ? rowData.refNo.toUpperCase()+ " Silme işlemi onaylandı!" : '- Silme işlemi onaylandı!';
        remove(rowData.id);
        setVisibleDeletePopUp(false);
        toast.current.show({ severity: 'success', summary: 'Başarıyla Silindi!', detail: detail, life: 3000});
        setSelectedRow(null);
        }
      }
      const reject = (rowData) => {
        if(toast.current){
            const detail = (rowData.refNo)  ? rowData.refNo.toUpperCase()+ " Silme işlemi iptal edildi!" : '- Silme işlemi iptal edildi!';
          setVisibleDeletePopUp(false);
          toast.current.show({ severity: 'warn', summary: 'İptal Edildi', detail: detail, life: 3000 });
          setSelectedRow(null); 
        }
      }

    const clearInputFields = () => {
        setQuery({
            id: 1,
            refNo: '',
            lclAndFtl: null,
            workApprovalDate: null,
            inco: null,
            exporter: '',
            customerName: '',
            agency: null,
            loadingCountry: null,
            portArrival: null,
            portDeparture: null,
            destinationCity: null,
            etd: null,
            eta: null,
            numberOfContainers: '',
            cbm: '',
            purchaseFreight: '',
            salesFreight: '',
            situation: [],
            vessel: '',
            puRdIw: null,
            kg: '',
            insurance: '',
            rate: '',
            bl: '',
            updatedTime: null,
            pageSize: rows,
            pageNumber: 0
        });
        setSelectedSituationType(null);
    }

    const onPage = async (e) => {
        if (query.pageSize !== e.rows) {  
            query.pageSize = e.rows; 
            setRows(e.rows); 
        }
        if (query.pageNumber !== e.first / e.rows){
          query.pageNumber = e.first / e.rows;
          setFirst(e.first);
        }
        await pagination();
    }

    const selectionChange = (event) => {
        const value = event.value;
        setSelectedSeaData(value);
    }

    const renderEditor = (props) => {
    if (!props.rowData || !props.field) {
        return null;
    }

    if (props.field === 'refNo' && nextRefNo && nextRefNo !== 'REF-1') {
        return (<span>{props.value}</span>);
    }

    const value = props.rowData[props.field] != null 
        ? String(props.rowData[props.field]) 
        : '';

        const type = props.field === 'numberOfContainers' || props.field === 'cbm' ? 'number' : 'text';

        return (
            <InputText
                type={type}
                value={value}
                onChange={(e) => {
                    const updatedValue = e.target.value;
                    setEditingRows((prevState) => ({
                        ...prevState,
                        [props.field]: updatedValue
                    }));
                    props.editorCallback(updatedValue);
                }}
                key={(props.rowIndex && props.field) ? (props.rowIndex + props.field) : ''}
            />
        );
    };


    const renderOptionEditor = (editorOptions, columnProps) => {
        return (
            <Dropdown
                value={editorOptions.value}
                options={columnProps.options}
                onChange={(e) => {
                    editorOptions.editorCallback(e.value);
                    setEditingRows((prevState) => ({
                        ...prevState,
                        [columnProps.field]: e.value
                    }));
                }}
                optionLabel="name"
                optionValue='value'
                className='w-full'
                filter
                showClear
            />
        );
    };


   const renderTimeEditor = (props) => {
    if (!props.rowData || !props.field) {
        return null; 
    }
    return (
        <Calendar
            value={props.value && props.value !== '' ? new Date(props.value) : null}
            onChange={(e) => {
                const isoDate = props.field === 'workApprovalDate' ? (e.value ? e.value.toISOString() : null)
                    : (e.value ? e.value.toISOString().split('T')[0] + 'T00:00:00Z' : null);    
                props.editorCallback(isoDate);
                setEditingRows((prevState) => ({
                    ...prevState,
                    [props.field]: isoDate
                }));
                seaDataList.content[props.rowIndex][props.field] = isoDate;
               
            }}
            showTime={props.field === 'workApprovalDate'}
            hourFormat={props.field === 'workApprovalDate' ? '24' : undefined}
            dateFormat="dd/mm/yy"
            className="w-full"
            key={(props.rowIndex && props.field) ? (props.rowIndex + props.field) : ''} 
        />
    );
};




    const handleAddRow = () => {
        setIsAddedRow(true);
        emptySeaData.refNo = nextRefNo;
        seaDataList.content.unshift(emptySeaData);
        setEditingRows(() => ({
            ...emptySeaData,
            [`${emptySeaData.id}`]: true
        }));
        setSaveIsSaving(true);
    }

    const onRowEditChange = (rowData) => {
        setSaveIsSaving(false);
        setEditingRows((prevState) => ({
            ...prevState,
            [`${rowData.id}`]: true
        }));
    }

    const onRowEditComplete = (e) => {
        let { newData } = e;
        for (let key in editingRows) {
            if (newData.hasOwnProperty(key)) {
            newData[key] = editingRows[key];
            }
        }

        setSeaDataForm({ ...newData });
        setEditingRows((prevState) => {
        const updatedRows = { ...prevState };
        delete updatedRows[newData.id];
        return updatedRows;
        });
    };


    const onRowSaveComplete = (rowData) => {
        rowData.id = null;
        setSaveIsSaving(true);
        if (!rowData) {
            setVisibleErrorPopUp(true);
            return;
        }
        for (let key in editingRows) {
            if (rowData.hasOwnProperty(key) && key !== 'id') {
            rowData[key] = editingRows[key];
            }
        }
        setSeaDataForm(rowData);
        setEditingRows((prevState) => {
            const updatedRows = { ...prevState };
            delete updatedRows[rowData.id]; 
            return updatedRows;
        });
        setIsAddedRow(false);
    };

    const findDynamicRefNo = (content) => {
        if (content.length > 0) {
            const lastItem = content[0];
            if (lastItem && lastItem.refNo) {
                const match = lastItem.refNo.match(/^([A-Za-z]+)(\d+)$/);
                if (!match) {
                    throw new Error("Geçersiz refNo formatı.");
                }
                const prefix = match[1];
                const number = match[2];
                const nextNumber = (parseInt(number, 10) + 1).toString().padStart(number.length, '0');

                return `${prefix}${nextNumber}`;
            } else if(seaDataList.content.length === 0) {
                return null; 
            }
        }
        return 'REF-1';
    }

    useEffect(() => {
        if (seaDataForm && Object.keys(seaDataForm).length > 0) {
            const saveOrUpdate = async () => {
            if (seaDataForm.id === null || seaDataForm.id === undefined) {
                await save();
            } else if (typeof seaDataForm.id === 'number') {
                await update();
            }
            setSaveIsSaving(false);
            };

            saveOrUpdate();
            pagination();
        }
    }, [seaDataForm]);

    const onRowSaveCancel = (rowData) => {
        if (saveIsSaving) {
            setSeaDataList((prevState) => ({
                ...prevState,
                content: prevState.content.slice(1)
            }));
        }
        setEditingRows((prevState) => {
            const updatedRows = { ...prevState };
            delete updatedRows[rowData.id]; 
            return updatedRows;
        });
        setIsAddedRow(false);
    }

    const pagination = async(updateQuery) => {
        setLoading(true);
         if(selectedSituationType){
            query.situation = [];
                for(let element in selectedSituationType) {
                    if(element) {
                        query.situation.push(element);
                    }
                }
            }
        await api
            .post(process.env.NEXT_PUBLIC_SEA_PAGINATION_PATH, updateQuery || query)
            .then((response) => {
                if(response.data.content.length !== 0) {
                    setSeaDataList(response.data);
                    setLoading(false);
                    const refNo = findDynamicRefNo(response.data.content);
                    setNextRefNo(refNo);
                    setIsAddedRow(false);
                }
                else {
                    setSeaDataList({ content: [], totalPages: 0, totalElements: 0 });
                    setLoading(false);
                }
            })
            .catch((reason) => {
                console.error("Pagination error => ", reason);
            })
    };

    const save = async() => {
        setLoading(true);
        await api
            .post(process.env.NEXT_PUBLIC_SEA_SAVE_PATH, seaDataForm)
            .then((response) => {
                if(response.data.length !== 0){ 
                    clearInputFields();
                    pagination();
                    setLoading(false);
                }
            })
            .catch((reason) => {
                console.error('Sea Save Method Error', reason);
                setLoading(false);
            })
    };

    const update = async() => {
        setLoading(true);
        await api
            .put(process.env.NEXT_PUBLIC_SEA_UPDATE_PATH, seaDataForm)
            .then((response) => {
                clearInputFields();
                pagination();
                setLoading(false);
            })
            .catch((reason) => {
                console.error("Sea Update Method Error ", reason);
                setLoading(false);
            })
    };

    const remove = async(id) => {
        setLoading(true);
        if (typeof id === 'string') {
            const index = seaDataList.content.findIndex(item => item.id === id);
            if (index !== -1) {
                seaDataList.content.splice(index, 1);
            }
        }
        else {
        await api
            .delete(process.env.NEXT_PUBLIC_SEA_DELETE
                .concat("/")
                .concat(id)
            )
            .then((response) => {
                clearInputFields();
                pagination();
                setLoading(false);
                setNextRefNo('REF-1')
            })
            .catch((reason) => {
                setLoading(false);
                console.error("Sea Delete Method Error ", reason);
            })
        }
    };

    const all = async() => {
        setLoading(true);
        await api
            .get(process.env.NEXT_PUBLIC_SEA_ALL_PATH)
            .then((response) => {
                if (response.data.length !== 0) {
                    setAllSeaDataList(response.data);
                }
                setLoading(false);
            })
            .catch((reason) => {
                console.error("Sea All Method Error ", reason);
            })
    };

    const find = async(id) => {
        setLoading(true);
        await api
            .get(process.env.NEXT_PUBLIC_SEA_FIND_PATH
                .concat("/")
                .concat(id)
            )
            .then((response) => {
                if(response.data.length !== 0) {
                    setSeaDataForm(response.data);
                }
                setLoading(false);
            })
            .catch((reason) => {
                console.error("Sea Find Method Error ", reason);
            })
    };

    useEffect(() => {
        setLoading(true);
        if(!hasPermission(authorizationList.view)) {
            directToErrorPage();
        }
        api
            .post(process.env.NEXT_PUBLIC_SEA_PAGINATION_PATH, {
                refNo: null,
                lclAndFtl: null,
                workApprovalDate: null,
                inco: null,
                exporter: '',
                customerName: '',
                agency: null,
                loadingCountry: null,
                portArrival: null,
                portDeparture: null,
                destinationCity: null,
                etd: null,
                eta: null,
                numberOfContainers: '',
                cbm: '',
                purchaseFreight: '',
                salesFreight: '',
                situation: [],
                updatedTime: null,
                vessel: null,
                puRdIw: null,
                kg: '',
                insurance: '',
                rate: '',
                bl: '',
                pageSize: rows,
                pageNumber: first
            })
            .then((response) => {
                if(response.data.content.length !== 0) {
                    setSeaDataList(response.data);
                    const refNo = findDynamicRefNo(response.data.content);
                    setNextRefNo(refNo);
                    setIsAddedRow(false);
                }
                setLoading(false);
            })
            .catch((reason) => {
                console.error("Sea Data First Pagination Error ", reason);
            })
    }, [authorizationList.view, directToErrorPage, hasPermission]);

    return(
        <>
        <Accordion activeIndex={0}>
            <AccordionTab header="Deniz Takip Formu">
                <Panel className='flex flex-column'>
                <div className='card flex flex-column gap-3'>
                    <div className='flex md:flex-row gap-6'>

                        <div className=" p-fluid flex-1">
                            <label htmlFor='updatedTime' className="font-bold block mb-2">Tarih:</label>
                            <Calendar
                                name = "updatedTime"
                                value = {query.updatedTime}
                                showTime
                                hourFormat='24'
                                onChange={util.handleInputChange(setQuery)} 
                            />
                        </div>
                        <div className='p-fluid flex-1'>
                            <label htmlFor='workApprovalDate' className="font-bold block mb-2">Approval Date:</label>
                            <Calendar
                                name = "workApprovalDate"
                                value = {query.workApprovalDate}
                                showTime
                                hourFormat='24'
                                onChange={util.handleInputChange(setQuery)} 
                            />
                        </div>
                        <div className='p-fluid flex-1'>
                            <label htmlFor='etd' className="font-bold block mb-2">ETD:</label>
                            <Calendar
                                name = "etd"
                                value = {query.etd}
                                showTime
                                dateFormat="dd/mm/yy"
                                onChange={util.handleInputChange(setQuery)} 
                            />
                        </div>
                        <div className='p-fluid flex-1'>
                            <label htmlFor='eta' className="font-bold block mb-2">ETA:</label>
                            <Calendar
                                name = "eta"
                                value = {query.eta}
                                showTime
                                dateFormat="dd/mm/yy"
                                onChange={util.handleInputChange(setQuery)}
                            />
                        </div>
                        <div className='p-fluid flex-1'>
                            <label htmlFor='refNo' className="font-bold block mb-2">Ref No:</label>
                            <InputText
                                name = "refNo"
                                value = {query.refNo}
                                onChange={util.handleInputChange(setQuery)}
                            />
                        </div>
                        <div className='p-fluid flex-1'>
                            <label htmlFor='puRdIw' className="font-bold block mb-2">PU/RD/IW:</label>
                            <Calendar
                                name = "puRdIw"
                                value = {query.puRdIw}
                                showTime
                                dateFormat="dd/mm/yy"
                                onChange={util.handleInputChange(setQuery)}
                            />
                        </div>                   
                    </div>    
                    
                    
                    <div className='flex md:flex-row gap-6'>
                        <div className='p-fluid flex-1'>
                            <label htmlFor='customerName' className="font-bold block mb-2">Customer:</label>
                            <InputText
                                name="customerName"
                                value = {query.customerName}
                                onChange={util.handleFormChange(setQuery)}
                            />
                        </div>
                        <div className='p-fluid flex-1'>
                            <label htmlFor='lclAndFtl' className='font-bold block mb-2'>LCL-FCL:</label>
                            <Dropdown
                                value={query.lclAndFtl}
                                name='lclAndFtl'
                                options={lclAndFtlTypes} 
                                optionLabel='name'
                                onChange={util.handleInputChange(setQuery)} 
                                showClear
                                filter
                            />
                        </div>
                        <div className='p-fluid flex-1'>
                            <label htmlFor='service' className='font-bold block mb-2'>Service:</label>
                            <Dropdown
                                value={query.service}
                                name='service'
                                options={serviceTypes}
                                optionLabel='name'
                                onChange={util.handleInputChange(setQuery)} 
                                showClear
                                filter
                            />
                        </div>
                        <div className='p-fluid flex-1'>
                            <label htmlFor='inco' className='font-bold block mb-2'>Inco:</label>
                            <Dropdown
                                value={query.inco}
                                name='inco'
                                options={incoTypes} 
                                optionLabel='name'
                                onChange={util.handleInputChange(setQuery)} 
                                showClear
                                filter
                            />
                        </div>
                        <div className='p-fluid flex-1'>
                            <label htmlFor='exporter' className='font-bold block mb-2'>Shipper:</label>
                            <InputText
                                name='exporter'
                                value={query.exporter}
                                onChange={util.handleInputChange(setQuery)}
                            />
                        </div>
                        <div className='p-fluid flex-1'>
                            <label htmlFor='vessel' className="font-bold block mb-2">Vessel:</label>
                            <InputText
                                name = "vessel"
                                value = {query.vessel}
                                onChange={util.handleInputChange(setQuery)}
                            />
                        </div>
                    
                    </div>

                    <div className='flex md:flex-row gap-6'>
                        
                        <div className='p-fluid flex-1'>
                            <label htmlFor='loadingCounter' className='font-bold block mb-2'>Loading Country:</label>
                            <Dropdown
                                value={query.loadingCountry}
                                name="loadingCountry"
                                options={loadingCountryTypes} optionLabel='name'
                                onChange={util.handleInputChange(setQuery)}
                                showClear 
                                filter
                            />
                        </div>
                        <div className='p-fluid flex-1'>
                            <label htmlFor='portArrival' className='font-bold block mb-2'>POD:</label>
                            <Dropdown   
                                value={query.portArrival}
                                name="portArrival"
                                options={portArrivalTypes} optionLabel='name'
                                onChange={util.handleInputChange(setQuery)}
                                showClear
                                filter
                            />
                        </div>
                        <div className='p-fluid flex-1'>
                            <label htmlFor='portDeparture' className='font-bold block mb-2'>POL:</label>
                            <Dropdown   
                                value={query.portDeparture}
                                name="portDeparture"
                                options={portDepartureTypes} optionLabel='name'
                                onChange={util.handleInputChange(setQuery)}
                                showClear
                                filter
                            />
                        </div>
                        <div className='p-fluid flex-1'>
                            <label htmlFor='destinationCity' className='font-bold block mb-2'>Destination City:</label>
                            <Dropdown
                                value={query.destinationCity}
                                name='destinationCity'
                                options={destinationCityTypes} optionLabel='name'
                                onChange={util.handleInputChange(setQuery)}
                                showClear
                                filter
                            />
                        </div>
                        <div className='p-fluid flex-1'>
                            <label htmlFor='numberOfContainers' className='font-bold block mb-2'>Number Of Container:</label>
                            <InputText
                                type='number'
                                value={query.numberOfContainers}
                                name='numberOfContainers'
                                onChange={util.handleInputChange(setQuery)}
                            />
                        </div>
                        <div className='p-fluid flex-1'>
                            <label htmlFor='kg' className='font-bold block mb-2'>KG:</label>
                            <InputText
                                type='number'
                                value={query.kg}
                                name='kg'
                                onChange={util.handleInputChange(setQuery)}
                            />
                        </div>

                    </div>

                    <div className='flex md:flex-row gap-6 mb-2'>

                        <div className='p-fluid flex-1'>
                            <label htmlFor='cbm' className='font-bold block mb-2'>CBM:</label>
                            <InputText
                                type='number'
                                value={query.cbm}
                                name='cbm'
                                onChange={util.handleInputChange(setQuery)}
                            />
                        </div>
                        <div className='p-fluid flex-1'>
                            <label htmlFor='purchaseFreight' className='font-bold block mb-2'>COST:</label>
                            <InputText
                                value={query.purchaseFreight}
                                name='purchaseFreight'
                                onChange={util.handleInputChange(setQuery)}
                            />
                        </div>
                        <div className='p-fluid flex-1'>
                            <label htmlFor='salesFreight' className='font-bold block mb-2'>Freight:</label>
                            <InputText
                                value={query.sales}
                                name='salesFreight'
                                onChange={util.handleInputChange(setQuery)}
                            />
                        </div>
                       
                        <div className='p-fluid flex-1'>
                            <label htmlFor='agency' className='font-bold block mb-2'>Agency:</label>
                            <Dropdown
                                value={query.agency}
                                name='agency'
                                options={agencyTypes} optionLabel='name'
                                onChange={util.handleInputChange(setQuery)}
                                showClear
                                filter
                            />
                        </div>

                        <div className='p-fluid flex-1'>
                            <label htmlFor='insurance' className='font-bold block mb-2'>Insurance:</label>
                            <InputText
                                value={query.insurance}
                                name='insurance'
                                onChange={util.handleInputChange(setQuery)}
                            />
                        </div>

                        <div className='p-fluid flex-1'>
                            <label htmlFor='rate' className='font-bold block mb-2'>Rate:</label>
                            <InputText
                                value={query.rate}
                                name='rate'
                                onChange={util.handleInputChange(setQuery)}
                            />
                        </div>
                    </div>
                    <div className="flex md:flex-row gap-6 mb-2">
                        <div className='p-fluid flex-1'>
                            <label htmlFor='situation' className='font-bold block mb-2'>Situation:</label>
                            <TreeSelect
                            value={selectedSituationType}
                            name='situation'
                            options={situationTypes} 
                            onChange={(e) => setSelectedSituationType(e.value)}
                            selectionMode='checkbox' 
                            metaKeySelection={false} 
                            filter
                            />
                        </div>
                        <div className='p-fluid '>
                            <label htmlFor='bl' className='font-bold block mb-2'>BL:</label>
                            <InputText
                                value={query.bl}
                                name='bl'
                                onChange={util.handleInputChange(setQuery)}
                            />
                        </div>

                        {/* Butonları saran div */}
                        <div className="flex gap-3 items-center">
                            <Button label="Temizle" severity='danger' disabled={loading} onClick={() => clearInputFields()} style={{ width: '120px', height: '50px', marginTop: '25px' }} />
                            <Button label="Sorgula" severity='success' disabled={loading} onClick={() => pagination()} style={{ width: '120px',  height: '50px', marginTop: '25px'  }} /> 
                        </div>
                    </div>

                    
                </div>
            </Panel>
            </AccordionTab>
        </Accordion>
      
            <Panel className='flex flex-column w-full' style= {{ paddingTop: '15px '}}>
                <div className='card'>
                    <DataTable scrollable scrollHeight='flex' value={seaDataList.content} dataKey='id' lazy paginator rowsPerPageOptions={[5, 10, 25, 50, 75, 100, 200]} editMode='row' onRowEditChange={onRowEditChange}
                        editingRows={editingRows} first={first} rows={rows} totalRecords={seaDataList.totalElements} onPage={onPage} onRowEditComplete={onRowEditComplete} 
                        selection={selectedSeaData} onSelectionChange={selectionChange} showGridlines stripedRows tableStyle={{ minWidth: '80rem' }}
                         > 
                            <Column rowEditor={true}  
                          header={() => (
                            <>
                            {hasPermission(authorizationList.save) && (
                            <Button
                              icon="pi pi-plus"
                              onClick={() => {handleAddRow();}}
                              className="p-button-info"
                              disabled={isAddedRow || loading}
                              />
                            )}
                            </>
                          )} 
                          
                          body={(rowData) => {
                            const isRowEditing = editingRows[rowData.id] || false;
                            return (
                                <>
                                {isRowEditing ? (
                                    <div style={{ display: 'flex', gap: '6px', paddingBottom: '3px' }}>
                                    {hasPermission(authorizationList.update) && (
                                        <Button 
                                        icon="pi pi-check"
                                        onClick={() => {
                                            if (typeof rowData.id === 'number') {
                                            onRowEditComplete({ newData: rowData, index: rowData.id });
                                            } else {
                                            onRowSaveComplete(rowData);
                                            }
                                        }}
                                        className="p-button-secondary p-button-sm-2"
                                        />
                                    )}
                                    {hasPermission(authorizationList.delete) && (
                                        <Button 
                                        icon="pi pi-times"
                                        onClick={() => onRowSaveCancel(rowData)}
                                        className="p-button-contrast p-button-sm-2"
                                        />
                                    )}
                                    </div>
                                ) : (
                                    <div style={{ display: 'flex', gap: '6px', paddingBottom: '3px' }}>
                                    {hasPermission(authorizationList.update) && (
                                        <Button 
                                        icon="pi pi-pencil"
                                        onClick={() => onRowEditChange(rowData)}
                                        className="p-button-secondary p-button-sm-2"
                                        disabled={loading || isAddedRow}
                                        />
                                    )}
                                    {hasPermission(authorizationList.delete) && (
                                        <Button 
                                        icon="pi pi-trash"
                                        onClick={() => {
                                            setSelectedRow(rowData);
                                            setVisibleDeletePopUp(true);
                                        }}
                                        className="p-button-contrast p-button-sm-2"
                                        disabled={loading || isAddedRow}

                                        />
                                    )}
                                    </div>
                                )}
                                </>
                            );
                            }}
                    
                      ></Column>
                        <Column field="refNo" header="REF NO" alignHeader='center' className='text-center' sortable disabled={nextRefNo !== 'REF-1'} headerStyle={{ minWidth: '120px' }}  editor={renderEditor}  ></Column>
                        <Column field="workApprovalDate" body={dateBodyTemplate('workApprovalDate')} header="APPROVAL DATE" alignHeader='center' className='text-center' sortable  headerStyle={{ minWidth: '180px' }} editor={renderTimeEditor}></Column>
                        <Column field="inco" header="INCO" alignHeader='center' className='text-center' sortable   editor={(editorOptions) => renderOptionEditor(editorOptions, { field: 'inco', options: incoTypes})}></Column>
                        <Column field="exporter" header="SHIPPER" alignHeader='center' className='text-center' sortable   editor={renderEditor}></Column>
                        <Column field="customerName" header="CUSTOMER" alignHeader='center' className='text-center' sortable Customer   editor={renderEditor}></Column>
                        <Column field="portDeparture" header="POL" body={bodyTemplate('portDeparture', portDepartureTypes)} alignHeader='center' className='text-center' sortable   editor={(editorOptions) => renderOptionEditor(editorOptions, {field: 'portDeparture', options: portDepartureTypes})}></Column>
                        <Column field="vessel" header="VESSEL" alignHeader='center' className='text-center' sortable   editor={renderEditor}></Column>
                        <Column field="portArrival" header="POD" body={bodyTemplate('portArrival', portArrivalTypes)} alignHeader='center' className='text-center' sortable   editor={(editorOptions) => renderOptionEditor(editorOptions, {field: 'portArrival', options: portArrivalTypes})}></Column>
                        <Column field="loadingCountry" header="LOADING COUNTRY" body={bodyTemplate('loadingCountry', loadingCountryTypes)} alignHeader='center' className='text-center' sortable  headerStyle={{ minWidth: '140px' }}  editor={(editorOptions) => renderOptionEditor(editorOptions, {field: 'loadingCountry', options: loadingCountryTypes})}></Column>
                        <Column field="destinationCity" header="DESTINATION CITY" body={bodyTemplate('destinationCity', destinationCityTypes)} alignHeader='center' className='text-center' sortable   editor={(editorOptions) => renderOptionEditor(editorOptions, {field: 'destinationCity', options: destinationCityTypes})}></Column> 
                        <Column field='service' header="SERVICE" body={bodyTemplate('service', serviceTypes)} alignHeader='center' className='text-center' sortable   editor={(editorOptions) => renderOptionEditor(editorOptions, { field: 'service', options: serviceTypes})}></Column>
                        <Column field="agency" header="AGENCY" body={bodyTemplate('agency', agencyTypes)} alignHeader='center' className='text-center' sortable   editor={(editorOptions) => renderOptionEditor(editorOptions, {field: 'agency', options: agencyTypes})}></Column>
                        <Column field="puRdIw" body={dateBodyTemplate('puRdIw')} header="PU/RD/IW" alignHeader='center' className='text-center' sortable  editor={renderTimeEditor}></Column>
                        <Column field="etd" header="ETD" body={dateBodyTemplate('etd')} alignHeader='center' className='text-center' sortable   editor={renderTimeEditor}></Column>
                        <Column field="eta" header="ETA" body={dateBodyTemplate('eta')} alignHeader='center' className='text-center' sortable   editor={renderTimeEditor}></Column>
                        <Column field="numberOfContainers" header="NUMBER OF CONTAINER" alignHeader='center' className='text-center' sortable headerStyle={{ minWidth: '150px' }}  editor={renderEditor}></Column>
                        <Column field="lclAndFtl" header="LCL-FCL" alignHeader='center' className='text-center' sortable headerStyle={{ minWidth: '120px' }} editor={(editorOptions) => renderOptionEditor(editorOptions, { field: 'lclAndFtl', options: lclAndFtlTypes})}></Column>
                        <Column field="cbm" header="CBM" alignHeader='center' className='text-center' sortable  editor={renderEditor}></Column>
                        <Column field="kg" header="KG" alignHeader='center' className='text-center' sortable  editor={renderEditor}></Column>
                        <Column field="situation" body={bodyTemplate('situation', situationTypes)} header="SITUATION" alignHeader='center' className='text-center' sortable   editor={(editorOptions) => renderOptionEditor(editorOptions, {field: 'situation', options: situationTypes})}></Column>
                        <Column field='insurance' header='INSURANCE' alignHeader='center' className='text-center' sortable   editor={renderEditor}></Column>
                        <Column field="purchaseFreight" header="PURCHASE FREIGHT" alignHeader='center' className='text-center' sortable   editor={renderEditor}></Column>
                        <Column field="salesFreight" header="SALES FREIGHT" alignHeader='center' className='text-center' sortable   editor={renderEditor}></Column>
                        <Column field='rate' header="RATE" alignHeader='center' className='text-center' sortable editor={renderEditor}></Column>
                        <Column field='bl' header="BL" alignHeader='center' className='text-center' sortable editor={renderEditor}></Column>
                        <Column field="createdTime" body={dateBodyTemplate('createdTime')} header="CREATED TIME" alignHeader='center' className='text-center' sortable   ></Column>
                        <Column field="updatedTime" body={dateBodyTemplate('updatedTime')} header="UPDATED TIME" alignHeader='center' className='text-center' sortable   ></Column>
                        <Column field="createdBy" header="CREATED BY" alignHeader='center' className='text-center' sortable   ></Column>
                        <Column field="lastModifiedBy" header="UPDATED BY" alignHeader='center' className='text-center' sortable  ></Column>
                    </DataTable>
                     {/* Delete Pop-up */}
                     <Toast ref={toast} />
                      <ConfirmDialog
                          visible={visibleDeletePopUp}
                          onHide={!visibleDeletePopUp}
                          message="Bu işlem geri alınamaz!"
                          header="Silmek istediğinize emin misiniz?"
                          icon="pi pi-exclamation-triangle"
                          accept={() => accept(selectedRow)}  
                          reject={() => reject(selectedRow)}  
                          acceptLabel='Evet'
                          rejectLabel='Vazgeç'
                      />
                    { /* Error Pop-Up */}
                    <Toast ref={toastError} />
                    <ConfirmDialog
                        visible={visibleErrorPopUp}
                        onHide={!visibleErrorPopUp}
                        header="UYARI"
                        message="Lütfen tüm gerekli alanları doldurduğunuzdan emin olun. Boş veri kaydedilemez."
                        footer={
                            <Button label="Kapat" icon="pi pi-times" onClick={() => {setVisibleErrorPopUp(false);}} />
                        }
                        style={{ width: '40rem'}}
                        
                     />
                    
                </div>
            </Panel>
        </>
    )
    
}

export default SeaPage;