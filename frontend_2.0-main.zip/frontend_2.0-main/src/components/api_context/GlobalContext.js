'use client'
import { useRouter } from 'next/navigation';
import React, { createContext, useEffect, useState, useCallback } from "react";
import Menu from '../../components/sidebar/Menu'

// Global Context
export const GlobalContext = createContext([]);

// GLobal Context Provider
export function GlobalContextProvider({ children }){

    const router = useRouter();
    const { pathname } = useRouter();
    const [expirationToken, setExpirationToken] = useState(null);

      
    const controlFrontendPermissionList = (frontendPermissionList) => {
        if(frontendPermissionList === undefined || frontendPermissionList === null){
            return false;
        }
        return true;
    }
    const hasPermission = (requiredPermission) => {
        const frontendPermissionList = localStorage.getItem("frontend-permissions") != null ? localStorage.getItem("frontend-permissions") : undefined;
        const val = controlFrontendPermissionList(frontendPermissionList);
        return val ? frontendPermissionList.includes(requiredPermission) : false;
    };
    const findPermission = useCallback((items, permissions) => {
        for (const item of items) {
            const el = item.items ? item.items : item.item;
            for(const subEl of el){
                if (subEl.to && permissions.includes(subEl.permission)) {
                    return true;
                }
                if (subEl.children && findPermission(subEl.children, permissions)) {
                    return true;
                }
            }
        }
        return false;
    }, [router]);
    const directToErrorPage = () => {
        router.push('/not-found');
    }

    useEffect(() => {
        if( !localStorage) {
            return;
        }
        const tokenTime = localStorage.getItem("expiration-token");
        if (tokenTime){
            setExpirationToken(tokenTime);
        }
        const frontendPermissionList = localStorage.getItem("frontend-permissions")
            ? localStorage.getItem("frontend-permissions")
            : undefined;
        const isLogged = localStorage.getItem("isLogged");
        if (!isLogged) {
            router.push("/login", { replace: true });
            return;
        }
        const isFindPermission = findPermission(Menu, frontendPermissionList);
        if (!isFindPermission) {
            router.push("/not-found", { replace: true });
            return;
        }
    }, [pathname, router, findPermission]);

    return (
        <div>
          <GlobalContext.Provider
            value={{
              hasPermission,
              directToErrorPage,
            }}
          >
            {children}
          </GlobalContext.Provider>
        </div>
      );
      

    
}
