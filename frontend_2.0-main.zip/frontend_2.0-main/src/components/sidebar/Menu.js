

const Menu = [
    {
        label: 'Dashboard',
        permission: 'general.dashboard.view',
        items: [{label: 'Anasayfa', icon: 'pi pi-fw pi-home', to: '/dashboard', permission: 'general.dashboard.view'}]
    },
    {
        label: 'Admin Operasyonları',
        permission: 'general.admin.view',
        items: [
            {
                label: 'Admin Kontrol Paneli',
                icon: 'pi pi-fw pi-bookmark',
                permission: 'admin.operation.header',
                items: [
                    {
                        label: 'Kullanıcı Kontrol Paneli',
                        icon: 'pi pi-fw pi-bookmark',
                        permission: 'admin.operation.user',
                        to: '/admin-operations-user'
                    },
                    {
                        label: 'Rol Kontrol Paneli',
                        icon: 'pi pi-fw pi-bookmark',
                        permission: 'admin.operation.role',
                        to: '/admin-operations-role'
                    },
                    {
                        label: 'Yetki Kontrol Paneli',
                        icon: 'pi pi-fw pi-bookmark',
                        permission: 'admin.operation.permission',
                        to: '/admin-operations-permission'
                    }
                ]
            }
        ]
    },
    {
        label: 'Deniz Modulü',
        permission: 'general.sea.view',
        item: [{label: 'Deniz', icon: 'pi pi-fw pi-bookmark', permission: 'sea.module.header', to: '/sea-module'}]
    }
]
export default Menu;
