import { useEffect } from "react";

export const handleInputChange = (setQuery) => (e) => {
    const { name, value } = e.target;
    setQuery((prevQuery) => ({
        ...prevQuery,
        [name]: value === '' ? null : value, 
    }));
};

export const handleFormChange = (setData) => (e) => {
    const { name, value } = e.target;
    setData((prevData) => ({
        ...prevData,
        [name]: value,
    }));
};

export const handlePaginationChange = (setQuery, setRows, setFirst, getPagination) => async (e) => {
    debugger;
    if (e.pageSize !== e.rows) {
        setRows(e.rows); 
    }
    if (e.pageNumber !== e.first / e.rows) {
        setFirst(e.first);
    }
    setQuery((prevQuery) => ({
        ...prevQuery,
        pageNumber: e.first / e.rows,
        pageSize: e.rows
    }));
    await getPagination();
};


