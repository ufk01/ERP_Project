export const ThemeService = {
    
    getTreeNodesData() {
        return [
            {
                key: '0',
                label: 'Tema Listesi',
                children: [
                    {
                        key: '0-0',
                        label: 'Arya',
                        data: 'Arya',
                        children: [
                            { key: 'arya-blue', label: 'Arya Blue' },
                            { key: 'arya-green', label: 'Arya Green' },
                            { key: 'arya-orange', label: 'Arya Orange' },
                            { key: 'arya-purple', label: 'Arya Purple' },
                        ]
                    },
                    {
                        key: '0-1',
                        label: 'Bootstrap',
                        data: 'Bootstrap',
                        children: [
                            { key: 'bootstrap4-blue-dark', label: 'Bootstrap Blue Dark' },
                            { key: 'bootstrap4-blue-light', label: 'Bootstrap Blue Light' },
                            { key: 'bootstrap4-purple-dark', label: 'Bootstrap Purple Dark' },
                            { key: 'bootstrap4-purple-light', label: 'Bootstrap Blue Light' },
                        ]
                    },
                    {
                        key: '0-2',
                        label: 'Fluent',
                        data: 'Fluent',
                        children: [
                            { key: 'fluent-light', label: 'Fluent Light' }
                        ]
                    },
                    {
                        key: '0-3',
                        label: 'Lara',
                        data: 'Lara',
                        children: [
                            { key: 'lara-dark-blue', label: 'Lara Dark Blue' },
                            { key: 'lara-dark-indigo', label: 'Lara Dark Indigo' },
                            { key: 'lara-dark-purple', label: 'Lara Dark Purple' },
                            { key: 'lara-dark-teal', label: 'Lara Dark Teal' },
                            { key: 'lara-light-blue', label: 'Lara Light Blue' },
                            { key: 'lara-light-indigo', label: 'Lara Light Indigo' },
                            { key: 'lara-light-purple', label: 'Lara Light Purple' },
                            { key: 'lara-light-teal', label: 'Lara Light Teal' }
                        ]
                    },
                    {
                        key: '0-4',
                        label: 'Luna',
                        data: 'Luna',
                        children: [
                            { key: 'luna-amber', label: 'Luna Amber' },
                            { key: 'luna-blue', label: 'Luna Blue' },
                            { key: 'luna-green', label: 'Luna Green' },
                            { key: 'luna-pink', label: 'Luna Pink' }
                        ]
                    },
                    {
                        key: '0-5',
                        label: 'MD',
                        data: 'MD',
                        children: [
                            { key: 'md-dark-deeppurple', label: 'MD Dark Purple' },
                            { key: 'md-dark-indigo', label: 'MD Dark Indigo' },
                            { key: 'md-light-deeppurple', label: 'MD Light Purple' },
                            { key: 'md-light-indigo', label: 'MD Light Indigo' },
                        ]
                    },
                    {
                        key: '0-6',
                        label: 'MDC',
                        data: 'MDC',
                        children: [
                            { key: 'mdc-dark-deeppurple', label: 'MDC Dark Purple' },
                            { key: 'mdc-dark-indigo', label: 'MDC Dark Indigo' },
                            { key: 'mdc-light-deeppurple', label: 'MDC Light Purple' },
                            { key: 'mdc-light-indigo', label: 'MDC Light Indigo' },
                        ]
                    },
                    {
                        key: '0-7',
                        label: 'Mira',
                        data: 'Mira',
                        children: [
                            { key: 'mira', label: 'Mira' },
                        ]
                    },
                    {
                        key: '0-8',
                        label: 'Nano',
                        data: 'Nano',
                        children: [
                            { key: 'nano', label: 'Nano' },
                        ]
                    },
                    {
                        key: '0-9',
                        label: 'Nova',
                        data: 'Nova',
                        children: [
                            { key: 'nova-accent', label: 'Nova Accent' },
                            { key: 'nova-alt', label: 'Nova Alt' },
                        ]
                    },
                    {
                        key: '0-10',
                        label: 'Rhea',
                        data: 'Rhea',
                        children: [
                            { key: 'rhea', label: 'Rhea' }
                        ]
                    },
                    {
                        key: '0-11',
                        label: 'Saga',
                        data: 'Saga',
                        children: [
                            { key: 'saga-blue', label: 'Saga Blue' },
                            { key: 'saga-green', label: 'Saga Green' },
                            { key: 'saga-orange', label: 'Saga Orange' },
                            { key: 'saga-purple', label: 'Saga Purple' }
                        ]
                    },
                    {
                        key: '0-12',
                        label: 'Soho',
                        data: 'Soho',
                        children: [
                            { key: 'soho-dark', label: 'Soho Dark' },
                            { key: 'soho-light', label: 'Soho Light' },
                        ]
                    },
                    {
                        key: '0-13',
                        label: 'Tailwind',
                        data: 'Tailwind',
                        children: [
                            { key: 'tailwind-light', label: 'Tailwind Light' }
                        ]
                    },
                    {
                        key: '0-14',
                        label: 'Vela',
                        data: 'Vela',
                        children: [
                            { key: 'vela-blue', label: 'Vela Blue' },
                            { key: 'vela-green', label: 'Vela Green' },
                            { key: 'vela-orange', label: 'Vela Orange' },
                            { key: 'vela-purple', label: 'Vela Purple' }
                        ]
                    },
                    {
                        key: '0-15',
                        label: 'Viva',
                        data: 'Viva',
                        children: [
                            { key: 'viva-dark', label: 'Viva Dark' },
                            { key: 'viva-light', label: 'Viva Light' },
                        ]
                    },
                ]
            }
        ];
    },

    getTreeNodes() {
        return Promise.resolve(this.getTreeNodesData());
    }
};
