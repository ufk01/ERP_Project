import React, { useContext } from 'react';
import { LayoutContext } from './context/LayoutContext';

const AppFooter = () => {
    
    const { layoutConfig } = useContext(LayoutContext);

    return (
        <div className="layout-footer">
            <span className="font-medium ml-2">2025 LogiFlow</span>
        </div>
    );
};

export default AppFooter;
