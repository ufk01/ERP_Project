import Link from 'next/link';
import { classNames } from 'primereact/utils';
import React, { forwardRef, useContext, useEffect, useImperativeHandle, useRef, useState } from 'react';
import { LayoutContext } from './context/LayoutContext';
import { PrimeReactContext } from 'primereact/api';
import { TreeSelect } from 'primereact/treeselect';
import { ThemeService } from '../constant/ThemeService';
import { Dialog } from 'primereact/dialog';
import { useRouter } from 'next/navigation';
import api from '../Api'

const AppTopbar = forwardRef((props, ref) => {

    const { layoutConfig, layoutState, onMenuToggle, showProfileSidebar, setLayoutConfig } = useContext(LayoutContext);
    
    const menubuttonRef         = useRef(null);
    const topbarmenuRef         = useRef(null);
    const topbarmenubuttonRef   = useRef(null);
    const topbarexitbuttonref   = useRef(null);
    const { changeTheme }       = useContext(PrimeReactContext);
    const [nodes, setNodes]     = useState(null);
    const [show, setShow]       = useState(false);
    const router                = useRouter();

    useEffect(() => {
        ThemeService.getTreeNodes().then((data) => setNodes(data));
    }, [])

    useEffect(() => {
        const theme = localStorage.getItem("userTheme");
        if (theme) {
            changeTheme(layoutConfig.theme, theme, 'theme-css', () => {
                setLayoutConfig((prevState) => ({ ...prevState, theme }));
            });
        }
    }, [])

    useImperativeHandle(ref, () => ({
        menubutton: menubuttonRef.current,
        topbarmenu: topbarmenuRef.current,
        topbarmenubutton: topbarmenubuttonRef.current,
        topbarexitbuttonref: topbarexitbuttonref.current
    }));

    const _changeTheme = (theme, colorScheme = "light") => {
        
        localStorage.setItem("userTheme", theme);

        changeTheme(layoutConfig.theme, theme, 'theme-css', () => {
            setLayoutConfig((prevState) => ({ ...prevState, theme, colorScheme }));
        });
    };

    const UserProfileDialog = () => {
        return (
            <Dialog header={<div style={{ textAlign: 'center', width: '100%' }}>Kullanıcı Ayarları</div>} 
             visible={show} style={{ width: '40vw' }} onHide={() => setShow(false)}>
                <div className="surface-1" style={{ marginTop: '-20px'}}>
                    <ul className="list-none p-0 m-0">
                        <li className="flex align-items-center py-3 px-2 border-top-1 border-300 flex-wrap">
                            <div className="text-500 w-6 md:w-2 font-medium">Kullanıcı Adı</div>
                            <div className="text-900 w-full md:w-8 md:flex-order-0 flex-order-1">ufk01</div>
                        </li>
                        <li className="flex align-items-center py-3 px-2 border-top-1 border-300 flex-wrap">
                            <div className="text-500 w-6 md:w-2 font-medium">E-Posta</div>
                            <div className="text-900 w-full md:w-8 md:flex-order-0 flex-order-1">ufukyilmaz0706@hotmail.com</div>
                        </li>
                        <li className="flex align-items-center py-3 px-2 border-top-1 border-300 flex-wrap">
                            <div className="text-500 w-6 md:w-2 font-medium">Firma Adı</div>
                            <div className="text-blue-500 text-lg  w-full md:w-8 md:flex-order-0 flex-order-1">INTERLINE</div>
                        </li>
                        <li className="flex align-items-center py-3 px-2 border-top-1 border-300 flex-wrap">
                            <div className="text-500 w-6 md:w-2 font-medium">Tema</div>
                            <TreeSelect 
                                value={layoutConfig.theme}
                                filter
                                onChange={(e) => _changeTheme(e.value, e.target.code)}
                                options={nodes} 
                                className="flex align-items-center"
                                placeholder={layoutConfig.theme}
                            />
                        </li>
                    </ul>
                </div>
            </Dialog>
        )
    }

    const handleLogout = () => {
        api
            .post(process.env.NEXT_PUBLIC_LOGOUT_PATH)
            .then((response) => {
              localStorage.clear();
              sessionStorage.clear(); 
              router.push("/login");
            })
            .catch((reason) => {
              alert(reason);
            })
    
    
      } 

    return (
        <div className="layout-topbar">
            <button ref={menubuttonRef} type="button" className="p-link layout-menu-button layout-topbar-button"  style = {{ left: '-35px'}} onClick={onMenuToggle}>
                <i className="pi pi-bars" />
            </button>

            <button ref={topbarmenubuttonRef} type="button" className="p-link layout-topbar-menu-button layout-topbar-button" onClick={showProfileSidebar}>
                <i className="pi pi-ellipsis-v" />
            </button>

            <div ref={topbarmenuRef} className={classNames('layout-topbar-menu', { 'layout-topbar-menu-mobile-active': layoutState.profileSidebarVisible })}>
                <button type="button" className="p-link layout-topbar-button" onClick={() => setShow(true)}>
                    <i className="pi pi-user"></i>
                    <span>Profile</span>
                </button>
                <button ref={topbarexitbuttonref} type="button" className="p-link layout-menu-button layout-topbar-button" onClick={handleLogout}>
                <i className="pi pi-sign-out" />
            </button>
            </div>
            <UserProfileDialog/>
            
            
        </div>
    );
});

AppTopbar.displayName = 'AppTopbar';

export default AppTopbar;
