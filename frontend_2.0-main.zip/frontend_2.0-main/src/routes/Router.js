import React, { useContext } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import Login from '../view/login/Login';
import Layout from '../components/layout/Layout'
import Dashboard from '../view/dashboard/Dashboard'
import Permission from '../view/admin/Permission'
import Role from '../view/admin/Role'
import User from '../view/admin/User'
import NotFound from "../view/not_found/NotFound";
import { GlobalContext } from "../components/api_context/GlobalContext";


const AppRouter = () => {

    const {hasPermission} = useContext(GlobalContext);



    return (
                <Routes>
                    <Route path="/login" element={<Login />} />
                    <Route path="/not-found" element={<NotFound />} />
                    <Route path="/" element={localStorage.getItem("isLogged")  ? <Layout /> : <Navigate to="/login" />} >
                            <Route index element={<Dashboard />} />
                            <Route path="/dashboard" element={hasPermission("general.dashboard.view") ? <Dashboard /> : <NotFound />} />
                            <Route path="/admin-operations-user" element={hasPermission("admin.operation.user") ? <User /> : <NotFound />}  />
                            <Route path="/admin-operations-role" element={hasPermission("admin.operation.role") ? <Role /> : <NotFound />}  />
                            <Route path="/admin-operations-permission" element={hasPermission("admin.operation.permission") ? <Permission /> : <NotFound />}  />

                    </Route>
                </Routes>
    );
};


export default AppRouter;